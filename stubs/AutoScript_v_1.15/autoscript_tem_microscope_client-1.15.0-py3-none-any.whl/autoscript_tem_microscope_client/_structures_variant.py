from typing import List, Optional, Union

import autoscript_tem_microscope_client._structures_shell as shell

__all__ = ["Variant"]


class Variant(shell.Variant):
    __slots__ = []

    def _is_bool(self):
        return self.value_bool is not None

    def _is_float(self):
        return self.value_double is not None

    def _is_int(self):
        return self.value_int is not None

    def _is_string(self):
        return self.value_string is not None

    @property
    def value(self) -> 'Union[None, bool, float, int, str]':
        """
        Returns the value of the variant as a boolean, float, int, or string.
        """
        if self._is_bool():
            return self.value_bool
        if self._is_float():
            return self.value_double
        if self._is_int():
            return self.value_int
        if self._is_string():
            return self.value_string

        return None

    def __repr__(self):
        return str(self.value)

    def __bool__(self):
        return bool(self.value)

    def __float__(self):
        return float(self.value)

    def __int__(self):
        return int(self.value)

    def __str__(self):
        return str(self.value)

    def __eq__(self, other):
        return self.value == other

    def __gt__(self, other):
        return self.value > other

    def __lt__(self, other):
        return self.value < other

    def __ne__(self, other):
        return self.value != other

    def __ge__(self, other):
        return self.value >= other

    def __le__(self, other):
        return self.value <= other

    def __add__(self, other):
        return self.value + other

    def __radd__(self, other):
        return other + self.value

    def __mul__(self, other):
        return self.value * other

    def __rmul__(self, other):
        return other * self.value

    def __sub__(self, other):
        return self.value - other

    def __rsub__(self, other):
        return other - self.value

    def __truediv__(self, other):
        return self.value / other

    def __rtruediv__(self, other):
        return other / self.value

    def __floordiv__(self, other):
        return self.value // other

    def __rfloordiv__(self, other):
        return other // self.value

    @classmethod
    def convert_from(cls, value) -> 'Optional[Variant]':
        if value is None or isinstance(value, Variant):
            return value

        instance = cls()

        if isinstance(value, bool):
            instance.value_bool = value
        if isinstance(value, float):
            instance.value_double = value
        elif isinstance(value, int):
            instance.value_int = value
        elif isinstance(value, str):
            instance.value_string = value
        else:
            raise TypeError(f"Cannot convert type {type(value).__name__} to Variant.")

        return instance

    @classmethod
    def convert_list_from(cls, value) -> 'Optional[List[Variant]]':
        if value is None or isinstance(value, list) and all(isinstance(item, Variant) for item in value):
            return value

        if isinstance(value, (list, tuple)):
            return [Variant.convert_from(item) for item in value]

        raise TypeError(f"Cannot convert type {type(value).__name__} to List[Variant].")
