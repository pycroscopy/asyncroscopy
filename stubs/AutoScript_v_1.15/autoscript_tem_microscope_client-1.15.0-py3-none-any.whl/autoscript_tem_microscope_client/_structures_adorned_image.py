import copy
import cv2
import numpy
import PIL.Image as PilImage
import PIL.TiffImagePlugin as PilTiff
from hashlib import sha1
from pathlib import Path
from typing import List, Optional, NamedTuple, Tuple

from autoscript_core.common import InvalidOperationException
from autoscript_core.serialization import ReprAttr
from ._structures_internal.image_loader import open_pil_image
from ._structures_metadata import AdornedImageMetadata
from . import _structures_shell as shell
from .enumerations import ImageDataEncoding


class _ImageExtensionInfo(NamedTuple):
    extension_aliases: List[str]
    add_tif_metadata: bool = False
    force_rgb_conversion: bool = False


class AdornedImage(shell.AdornedImage):
    __slots__ = []
    __INI_METADATA_TIFF_TAG = 34682
    __XML_METADATA_TIFF_TAG = 34683

    def __init__(self, data: numpy.ndarray = None, metadata: 'AdornedImageMetadata' = None):
        """
        Constructs a new AdornedImage.

        :param data: Data to construct the new AdornedImage from, in a form of numpy.ndarray.
        :param metadata: Metadata to assign to this instance of AdornedImage.
        """

        # Constructs the new AdornedImage from the given data where applicable.
        # This approach is intended for images created directly by user. Images
        # coming from the AutoScript Server get their members filled in directly
        # during deserialization.

        if metadata is not None:
            metadata = copy.deepcopy(metadata)

        if data is not None:
            if not isinstance(data, numpy.ndarray):
                raise ValueError("Cannot construct AdornedImage because the given data "
                                 "are not of numpy.ndarray type.")

            try:
                width, height, bit_depth, raw_encoding = self.__determine_image_properties(data)
                raw_data = self.__generate_raw_data(data, bit_depth)

                super().__init__(raw_data, width, height, raw_encoding, bit_depth, metadata)
            except Exception as ex:
                raise ValueError("Cannot construct AdornedImage because the given data "
                                 "are not in a compatible format.", ex)
        else:
            super().__init__(metadata=metadata)

    @property
    def encoding(self) -> int:
        """
        Encoding of the image. To explain this property use enumeration ImageDataEncoding.
        """

        self.__ensure_not_empty()

        if self.bit_depth == 24:
            # BGR is presented as RGB and a conversion is done on data property
            return ImageDataEncoding.RGB
        else:
            return self._raw_encoding

    @property
    def data(self) -> numpy.ndarray:
        """
        The data arranged either in 2D (for grayscale images) or 3D (for RGB images) numpy array.
        """

        self.__ensure_not_empty()

        if self.bit_depth == 8 and self._raw_encoding == ImageDataEncoding.UNSIGNED:
            raw_data_bytes = numpy.frombuffer(self._raw_data, dtype=numpy.uint8)
            data = numpy.reshape(raw_data_bytes, (self.height, self.width))
        elif self.bit_depth == 16 and self._raw_encoding == ImageDataEncoding.UNSIGNED:
            raw_data_bytes = numpy.frombuffer(self._raw_data, dtype=numpy.uint16)
            data = numpy.reshape(raw_data_bytes, (self.height, self.width))
        elif self.bit_depth == 16 and self._raw_encoding == ImageDataEncoding.SIGNED:
            raw_data_bytes = numpy.frombuffer(self._raw_data, dtype=numpy.int16)
            data = numpy.reshape(raw_data_bytes, (self.height, self.width))
        elif self.bit_depth == 32 and self._raw_encoding == ImageDataEncoding.SIGNED:
            raw_data_bytes = numpy.frombuffer(self._raw_data, dtype=numpy.int32)
            data = numpy.reshape(raw_data_bytes, (self.height, self.width))
        elif self.bit_depth == 24 and self._raw_encoding == ImageDataEncoding.BGR:
            raw_data_bytes = numpy.frombuffer(self._raw_data, dtype=numpy.uint8)
            bgr_data = numpy.reshape(raw_data_bytes, (self.height, self.width, 3))
            data = bgr_data[..., ::-1]  # this doesn't make a copy, it just creates a new view on the data (we need RGB)
        elif self.bit_depth == 24 and self._raw_encoding == ImageDataEncoding.RGB:
            raw_data_bytes = numpy.frombuffer(self._raw_data, dtype=numpy.uint8)
            data = numpy.reshape(raw_data_bytes, (self.height, self.width, 3))
        else:
            data = numpy.frombuffer(self._raw_data, dtype=numpy.uint8)

        return data

    @property
    def checksum(self) -> str:
        """
        Provides checksum of the raw_data.

        :return: checksum of the raw_data.
        """

        self.__ensure_not_empty()
        return sha1(self._raw_data).hexdigest()

    @property
    def thumbnail(self) -> 'AdornedImage':
        """
        Provides a thumbnail of this image. The thumbnail width is 512 pixels, the height is calculated to maintain the
        original aspect ratio. The thumbnail image will not have image metadata.

        :return: Thumbnail of this image as a new AdornedImage object.
        """

        self.__ensure_not_empty()

        if self.width < self.height:
            width = max(round(self.width * 512 / self.height), 1)
            thumbnail_size = (width, 512)
        else:
            height = max(round(self.height * 512 / self.width), 1)
            thumbnail_size = (512, height)

        # OpenCV does not support int32 array, retype to uint16
        if self.encoding == ImageDataEncoding.SIGNED and self.bit_depth == 32:
            data = self.data.clip(0).astype(numpy.uint16)
        else:
            data = self.data

        # PIL won't resize 16-bit grayscale images, ask OpenCV
        resized_data = cv2.resize(data, thumbnail_size)
        return AdornedImage(resized_data)

    _supported_save_extensions = [
        _ImageExtensionInfo([".tiff", ".tif"], add_tif_metadata=True),
        _ImageExtensionInfo([".bmp"], force_rgb_conversion=True),
        _ImageExtensionInfo([".png"]),
        _ImageExtensionInfo([".gif"], force_rgb_conversion=True)
    ]
    _default_save_extension = _supported_save_extensions[0]

    def _find_save_extension_info(self, extension):
        try:
            return [x for x in self._supported_save_extensions if extension in x.extension_aliases][0]
        except IndexError:
            raise ValueError(f"Image format '{extension}' is not supported.")

    def save(self, path: str):
        """
        Saves the image to the specified path. Supported formats: tiff, png, bmp, gif.
        :param path: Path of the file to be saved.
        """

        self.__ensure_not_empty()

        extension = self._get_extension_from_path(path)

        if not extension:
            extension_info = self._default_save_extension
            path += extension_info.extension_aliases[0]
        else:
            extension_info = self._find_save_extension_info(extension)

        if extension_info.force_rgb_conversion and self.encoding not in (ImageDataEncoding.RGB, ImageDataEncoding.BGR):
            # Normalize data and convert it into 8-bit
            normalized_data = normalize_data(self.data, outlier_threshold=None)
            normalized_data *= 255
            pil_image = PilImage.fromarray(normalized_data.astype(numpy.uint8)).convert("RGB")
        else:
            # PIL doesn't support int16 images and converts it automatically to int32
            pil_image = PilImage.fromarray(self.data)

        tiff_tags = self.__create_tiff_tags() if extension_info.add_tif_metadata else None
        pil_image.save(path, format=None, tiffinfo=tiff_tags)

    @staticmethod
    def _get_extension_from_path(path: str) -> str:
        return Path(path).suffix.lower()

    def __create_tiff_tags(self) -> PilTiff.ImageFileDirectory_v2:
        """
        Creates tiff metadata.
        :return: Metadata in PIL format.
        """

        tiff_tags = PilTiff.ImageFileDirectory_v2()
        self.__override_default_xml_string_encoding(tiff_tags)

        tiff_tags[PilTiff.IMAGEWIDTH] = self.width
        tiff_tags[PilTiff.IMAGELENGTH] = self.height
        tiff_tags[PilTiff.COMPRESSION] = 1  # raw
        tiff_tags[PilTiff.RESOLUTION_UNIT] = 3  # cm

        if self.bit_depth == 24:
            tiff_tags[PilTiff.BITSPERSAMPLE] = (8, 8, 8)
            tiff_tags[PilTiff.PHOTOMETRIC_INTERPRETATION] = 2  # RGB
        else:
            tiff_tags[PilTiff.BITSPERSAMPLE] = (self.bit_depth,)
            tiff_tags[PilTiff.PHOTOMETRIC_INTERPRETATION] = 1  # BlackIsZero

        if self.metadata is not None:
            if self.metadata.metadata_as_xml is not None:
                tiff_tags[AdornedImage.__XML_METADATA_TIFF_TAG] = self.metadata.metadata_as_xml

            if self.metadata.metadata_as_ini is not None:
                tiff_tags[AdornedImage.__INI_METADATA_TIFF_TAG] = self.metadata.metadata_as_ini

        return tiff_tags

    @staticmethod
    def __override_default_xml_string_encoding(tiff_tags: PilTiff.ImageFileDirectory_v2):
        """
        Overrides default string encoding for tiff tags to 'latin-1' (only for xml strings).
        PILL is following TIFF specs and encodes every string into ASCII.
        By overriding it we solve the encoding issues, but the resulting image doesn't follow TIFF specs.
        """

        def write_string(_, value):
            encoding = "latin-1" if value.startswith("<?xml") else "ascii"
            return b"" + value.encode(encoding, "replace") + b"\0"

        tiff_tags._write_dispatch[2] = write_string

    _supported_load_extensions = [".tiff", ".tif", ".png", ".bmp"]

    @staticmethod
    def load(path: str) -> 'AdornedImage':
        """
        Loads an image from a file. Supported formats: tiff, png, bmp.
        :param path: File path from which to load the image.
        :return: Loaded image.
        """

        extension = AdornedImage._get_extension_from_path(path)

        if extension not in AdornedImage._supported_load_extensions:
            raise ValueError(f"Image format extension '{extension}' is not supported.")

        # PIL doesn't support int16 images and converts it automatically to int32
        with open_pil_image(path) as pil_image:
            data = convert_pil_image_to_data(pil_image)
            return AdornedImage(data, AdornedImage.__create_metadata(pil_image))

    def __repr__(self):
        repr_attrs = [ReprAttr("width"), ReprAttr("height"), ReprAttr("bit_depth")]
        return self._generate_repr(repr_attrs)

    @staticmethod
    def __generate_raw_data(ndarray: numpy.ndarray, bit_depth: int) -> bytes:
        """
        Generates raw image data according to the given data in a form of numpy.ndarray and the given bit depth.
        Raw data are stored in neutral AutoScript form.

        :param ndarray: Data in a form of numpy.ndarray to serve as a data source.
        :param bit_depth: Bit depth of the given data.
        :return: Byte string representation of data.

        :raises ValueError: Raised when bit depth is not supported.
        """

        # Creates memory view of the given data compatible with neutral AutoScript form.
        if bit_depth == 8 or bit_depth == 16 or bit_depth == 32:
            # For 8-bit, 16-bit or 32-bit images, numpy.ndarray form is similar to neutral AutoScript form.
            compatible_memory_view = memoryview(ndarray)
        elif bit_depth == 24:
            # For 24-bit images, a conversion from RGB to BGR has to be made.
            compatible_memory_view = ndarray[..., ::-1]
        else:
            raise ValueError(f"Cannot generate raw data with bit depth = {bit_depth}.")

        # creates a copy of the compatible memory view
        return compatible_memory_view.tobytes()

    @staticmethod
    def __determine_image_properties(ndarray: numpy.ndarray) -> (int, int, int, int):
        """
        Determines image properties from the given numpy.ndarray.

        :param ndarray: numpy.ndarray to determine image dimensions from.
        :return: Width, height, bit depth and raw_encoding of the image.

        :raises Exception: Raised when dimensions can not be properly determined.
        """

        if ndarray.ndim == 2 and ndarray.dtype == numpy.uint8:
            return ndarray.shape[1], ndarray.shape[0], 8, ImageDataEncoding.UNSIGNED

        if ndarray.ndim == 2 and ndarray.dtype == numpy.uint16:
            return ndarray.shape[1], ndarray.shape[0], 16, ImageDataEncoding.UNSIGNED

        if ndarray.ndim == 2 and ndarray.dtype == numpy.int16:
            return ndarray.shape[1], ndarray.shape[0], 16, ImageDataEncoding.SIGNED

        if ndarray.ndim == 2 and ndarray.dtype == numpy.int32:
            return ndarray.shape[1], ndarray.shape[0], 32, ImageDataEncoding.SIGNED

        if ndarray.ndim == 3 and ndarray.shape[2] == 3 and ndarray.dtype == numpy.uint8:
            return ndarray.shape[1], ndarray.shape[0], 24, ImageDataEncoding.BGR

        raise ValueError("Cannot determine image dimensions from the given numpy.ndarray.")

    def __ensure_not_empty(self):
        if self._raw_data is None:
            raise InvalidOperationException("Adorned image object was not initialized with image data.")

    @staticmethod
    def __create_metadata(pil_image: PilImage) -> 'Optional[AdornedImageMetadata]':
        """
        Creates metadata from PIL image.
        """

        if not hasattr(pil_image, "tag_v2"):
            return

        if AdornedImage.__XML_METADATA_TIFF_TAG in pil_image.tag_v2:
            xml_metadata = pil_image.tag_v2[AdornedImage.__XML_METADATA_TIFF_TAG]
        else:
            xml_metadata = ""

        if AdornedImage.__INI_METADATA_TIFF_TAG in pil_image.tag_v2:
            ini_metadata = pil_image.tag_v2[AdornedImage.__INI_METADATA_TIFF_TAG]
        else:
            ini_metadata = None

        return AdornedImageMetadata.create_from_image_data(xml_metadata, ini_metadata)


def convert_pil_image_to_data(pil_image: PilImage) -> numpy.array:
    raw_data = pil_image.tobytes()

    # 8-bit pixels, grayscale
    if pil_image.mode == "L":
        raw_data_bytes = numpy.frombuffer(raw_data, dtype=numpy.uint8)
        return numpy.reshape(raw_data_bytes, (pil_image.height, pil_image.width))

    # 16-bit unsigned integer pixels
    elif pil_image.mode == "I;16":
        raw_data_bytes = numpy.frombuffer(raw_data, dtype=numpy.uint16)
        return numpy.reshape(raw_data_bytes, (pil_image.height, pil_image.width))

    # 32-bit signed integer pixels
    elif pil_image.mode == "I":
        raw_data_bytes = numpy.frombuffer(raw_data, dtype=numpy.int32)
        return numpy.reshape(raw_data_bytes, (pil_image.height, pil_image.width))

    # 3x8-bit pixels, true color
    elif pil_image.mode == "RGB":
        raw_data_bytes = numpy.frombuffer(raw_data, dtype=numpy.uint8)
        return numpy.reshape(raw_data_bytes, (pil_image.height, pil_image.width, 3))

    # the rest of the PIL supported types and bit depths, expected to be managed by the user
    else:
        return numpy.frombuffer(raw_data, dtype=numpy.uint8)


def normalize_data(data: numpy.array, outlier_threshold: Optional[float] = 0.999) -> numpy.array:
    """
    Normalizes the given array and into [0 - 1] range.

    Outliers are filtered based on the threshold value:
        - Uses numpy to calculate histogram of the data (with auto number of bins).
        - Calculates proportional area of each histogram bin (how big is the ratio of each bin to the whole histogram).
        - Calculates cumulative sum of the areas from each side of the histogram and stops when it reaches the
          threshold.
        - Reached histogram values are the new limit values.

    :param data: Data to be normalized. 2D array is expected.
    :param outlier_threshold: Threshold for outlier filtering. If None, the original data range is used.
        The value must be in (0.5, 1) interval.
    :return: Normalized data array.
    """

    if outlier_threshold is None:
        min_value = numpy.min(data)
        max_value = numpy.max(data)
    else:
        # Calculates new min and max values from the threshold and clips the data
        min_value, max_value = _get_data_range(data, outlier_threshold)
        data = numpy.clip(data, min_value, max_value)

    if max_value > min_value:
        value_range = max_value - min_value
        zero_shift = min_value
    else:
        # Handles empty images with only one value
        value_range = max_value if max_value > 0 else 1
        zero_shift = 0

    return (data - zero_shift) / value_range


def _get_data_range(data: numpy.array, outlier_threshold: float) -> Tuple[int, int]:
    if outlier_threshold <= 0.5 or outlier_threshold >= 1:
        raise ValueError("Outlier threshold must be in (0.5, 1) interval.")

    histogram = numpy.histogram(data, "auto")
    counts, values = histogram

    areas = counts / data.size
    reversed_areas = areas[::-1]

    minimum_index = -reversed_areas[reversed_areas.cumsum() <= outlier_threshold].size
    maximum_index = areas[areas.cumsum() <= outlier_threshold].size

    minimum = int(values[minimum_index])
    maximum = int(values[maximum_index])

    return minimum, maximum
