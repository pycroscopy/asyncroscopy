from lxml import etree
from typing import List
from typing import Optional, Union, Callable

from autoscript_core.serialization import ReprAttr
from ._structures_internal.indexer_tools import StageIndexer
from ._structures_primitives import StagePosition, Point, Rectangle, Unit, Limits, ValueAndType
from ._structures_internal.xml.metadata_custom_xml_tools import OrderingInfo, insert_value_to_element, \
    get_value_from_element, insert_element, create_custom_xml_property
from ._structures_internal.xml.metadata_xml_tools import XmlStructure, XmlError, create_xml_property, serialize, \
    deserialize, strip_element, check_property_value
from . import _structures_shell as shell
from ._tem_microscope_logging import Logging, LogDomain


__all__ = ["AdornedImageMetadataReferenceTransformation", "AdornedImageMetadataCustomProperty", "AdornedImageMetadataCustomProperties", 
           "AdornedImageMetadataCustomSection", "AdornedImageMetadataStagePosition", "AdornedImageMetadataAcquisition", "AdornedImageMetadataBinaryResult", 
           "AdornedImageMetadataCore", "AdornedImageMetadataScanningDetector", "AdornedImageMetadataAnalyticalDetector", 
           "AdornedImageMetadataImagingDetector", "AdornedImageMetadataEnergyFilterSettings", "AdornedImageMetadataGasInjectionSystemGas", 
           "AdornedImageMetadataGasInjectionSystem", "AdornedImageMetadataInstrument", "AdornedImageMetadataOpticsAperture", 
           "AdornedImageMetadataOpticsBeamModulator", "AdornedImageMetadataOptics", "AdornedImageMetadataSample", "AdornedImageMetadataScanSettings", 
           "AdornedImageMetadataStageSettings", "AdornedImageMetadataVacuumProperties", "AdornedImageMetadata"]


PointLike = Union[Point, list, tuple]
RectangleLike = Union[Rectangle, list, tuple]
UnitLike = Union[Unit, list, tuple]
ValueAndTypeLike = Union[ValueAndType, list, tuple]
AdornedImageMetadataStagePositionLike = Union["AdornedImageMetadataStagePosition", list, tuple]


class AdornedImageMetadataReferenceTransformation(XmlStructure):
    def __init__(self, m11: float = None, m12: float = None, m21: float = None, m22: float = None,
                 offset_x: float = None, offset_y: float = None, unit: str = None):
        self.m11 = m11
        self.m12 = m12
        self.m21 = m21
        self.m22 = m22
        self.offset_x = offset_x
        self.offset_y = offset_y
        self.unit = unit

    m11 = create_xml_property(float, "M11")
    m12 = create_xml_property(float, "M12")
    m21 = create_xml_property(float, "M21")
    m22 = create_xml_property(float, "M22")
    offset_x = create_xml_property(float, "OffsetX")
    offset_y = create_xml_property(float, "OffsetY")
    unit = create_xml_property(str, "Unit")


class AdornedImageMetadataOpticsBeamModulator(XmlStructure):
    def __init__(self, duty_cycle: float = None):
        self.duty_cycle = duty_cycle

    duty_cycle = create_xml_property(float, "DutyCycle")


class AdornedImageMetadataCustomProperty(XmlStructure):
    def __init__(self, name: str = None, value: str = None, type: str = None, raw_data_type: str = None):
        self.name = name
        self.value = value
        self.type = type
        self.raw_data_type = raw_data_type

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "CustomProperty"

    name = create_xml_property(str, "name", is_element=False)
    value = create_xml_property(str, "value", is_element=False)
    type = create_xml_property(str, "type", is_element=False)
    raw_data_type = create_xml_property(str, "rawdatatype", is_element=False)


class AdornedImageMetadataCustomProperties(XmlStructure):
    def __init__(self, scope: str = None, properties: List[AdornedImageMetadataCustomProperty] = None):
        self.scope = scope
        self.properties = properties

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "CustomProperties"

    scope = create_xml_property(str, "scope", is_element=False)
    properties = create_xml_property(List[AdornedImageMetadataCustomProperty], "", private_name="_properties")


class AdornedImageMetadataCustomSection(XmlStructure):
    def __init__(self, scope: str = None, elements: str = None):
        self.scope = scope
        self.elements = elements

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "CustomSection"

    scope = create_xml_property(str, "scope", is_element=False)
    elements = create_custom_xml_property(str, "Elements")

    def serialize(self, parent):
        super().serialize(parent)

        if self.elements:
            dummy_root = etree.fromstring(f"<DummyRoot>{self.elements}</DummyRoot>")
            element = parent[-1]  # We need to extend the last added element
            element.extend(list(dummy_root))

    @classmethod
    def deserialize(cls, element):
        deserialized = super().deserialize(element)

        children = ""
        for child in element:
            strip_element(child)
            children += etree.tostring(child, encoding="unicode")
        deserialized.elements = None if children == "" else children

        return deserialized


class AdornedImageMetadataStagePosition(StagePosition, XmlStructure):
    def __init__(self, x: float = None, y: float = None, z: float = None, a: float = None, b: float = None,
                 r: float = None):
        super().__init__(x, y, z, a, b)
        self.r = r
        self._property_indexers.append(StageIndexer(super().__len__(), "R", AdornedImageMetadataStagePosition.r))
        self._repr_attrs.append(ReprAttr("r"))

    @property
    def r(self):
        return self._r

    @r.setter
    def r(self, value):
        check_property_value(float, value)
        self._r = value

    @classmethod
    def create_from(cls, value) -> 'AdornedImageMetadataStagePosition':
        """
        Creates a new instance of the structure from a collection object.
        """
        instance = cls()

        if isinstance(value, str):
            raise TypeError(f"Cannot create instance of AdornedImageMetadataStagePosition from string.")

        try:
            if len(value) > 6:
                raise IndexError("Cannot create instance of AdornedImageMetadataStagePosition "
                                 "from collection of more than 6 elements.")
            if len(value) > 0:
                instance.x = value[0]
            if len(value) > 1:
                instance.y = value[1]
            if len(value) > 2:
                instance.z = value[2]
            if len(value) > 3:
                instance.a = value[3]
            if len(value) > 4:
                instance.b = value[4]
            if len(value) > 5:
                instance.r = value[5]
        except TypeError:
            raise TypeError(f"Cannot create instance of AdornedImageMetadataStagePosition from "
                            f"{type(value).__name__}.") from None

        return instance

    @classmethod
    def convert_from(cls, value) -> 'Optional[AdornedImageMetadataStagePosition]':
        if value is None or isinstance(value, AdornedImageMetadataStagePosition):
            return value
        if isinstance(value, (list, tuple)):
            return AdornedImageMetadataStagePosition.create_from(value)
        raise TypeError(f"Cannot convert type {type(value).__name__} to AdornedImageMetadataStagePosition.")

    @classmethod
    def convert_list_from(cls, value) -> 'Optional[List[AdornedImageMetadataStagePosition]]':
        if value is None or isinstance(value, list) and \
                all(isinstance(item, AdornedImageMetadataStagePosition) for item in value):
            return value
        if isinstance(value, (list, tuple)):
            return [AdornedImageMetadataStagePosition.create_from(item) for item in value]
        raise TypeError(f"Cannot convert type {type(value).__name__} to List[AdornedImageMetadataStagePosition].")

    def serialize(self, parent):
        insert_value_to_element(parent, "X", self.x)
        insert_value_to_element(parent, "Y", self.y)
        insert_value_to_element(parent, "Z", self.z)
        insert_value_to_element(parent, "Rotation", self.r)

        if self.a is not None or self.b is not None:
            tilt_element = etree.SubElement(parent, "Tilt")
            insert_value_to_element(tilt_element, "Alpha", self.a)
            insert_value_to_element(tilt_element, "Beta", self.b)

    @classmethod
    def deserialize(cls, element):
        deserialized = AdornedImageMetadataStagePosition()

        deserialized.x = get_value_from_element(element, "X", float)
        deserialized.y = get_value_from_element(element, "Y", float)
        deserialized.z = get_value_from_element(element, "Z", float)
        deserialized.r = get_value_from_element(element, "Rotation", float)

        tilt_element = element.find("Tilt")
        if tilt_element is not None:
            deserialized.a = get_value_from_element(tilt_element, "Alpha", float)
            deserialized.b = get_value_from_element(tilt_element, "Beta", float)

        return deserialized


class AdornedImageMetadataAcquisition(XmlStructure):
    def __init__(self, acquisition_date_time: str = None, acquisition_id: str = None,
                 acquisition_start_date_time: str = None, beam_type: str = None, column_type: str = None,
                 source_type: str = None):
        self.acquisition_date_time = acquisition_date_time
        self.acquisition_id = acquisition_id
        self.acquisition_start_date_time = acquisition_start_date_time
        self.beam_type = beam_type
        self.column_type = column_type
        self.source_type = source_type

    acquisition_start_date_time = create_xml_property(str, "AcquisitionStartDatetime")
    acquisition_date_time = create_xml_property(str, "AcquisitionDatetime")
    acquisition_id = create_xml_property(str, "AcquisitionID")
    beam_type = create_xml_property(str, "BeamType")
    column_type = create_xml_property(str, "ColumnType")
    source_type = create_xml_property(str, "SourceType")


class AdornedImageMetadataBinaryResult(XmlStructure):
    def __init__(self, acquisition_unit: str = None, bits_per_pixel: int = None, black_level: float = None,
                 composition_type: str = None, detector: str = None, detector_index: int = None,
                 digital_brightness: float = None, digital_contrast: float = None, encoding: str = None,
                 filter_frame_count: int = None, filter_type: str = None, gamma: float = None,
                 intensity_offset: float = None, intensity_scale: float = None, intensity_scale_unit: UnitLike = None,
                 pixel_value_maximum: float = None, pixel_value_minimum: float = None, pixel_value_mean: float = None,
                 pixel_value_standard_deviation: float = None, recursive_filter_coefficient: float = None,
                 reference_transformation: AdornedImageMetadataReferenceTransformation = None, sharpness: float = None,
                 sharpness_algorithm: str = None, sigma: float = None, white_level: float = None,
                 acquisition_area: RectangleLike = None, image_size: PointLike = None, offset: PointLike = None,
                 pixel_size: PointLike = None, pixel_size_x_unit: UnitLike = None, pixel_size_y_unit: UnitLike = None):
        self.acquisition_unit = acquisition_unit
        self.bits_per_pixel = bits_per_pixel
        self.black_level = black_level
        self.composition_type = composition_type
        self.detector = detector
        self.detector_index = detector_index
        self.digital_brightness = digital_brightness
        self.digital_contrast = digital_contrast
        self.encoding = encoding
        self.filter_frame_count = filter_frame_count
        self.filter_type = filter_type
        self.gamma = gamma
        self.intensity_offset = intensity_offset
        self.intensity_scale = intensity_scale
        self.intensity_scale_unit = intensity_scale_unit
        self.pixel_value_maximum = pixel_value_maximum
        self.pixel_value_minimum = pixel_value_minimum
        self.pixel_value_mean = pixel_value_mean
        self.pixel_value_standard_deviation = pixel_value_standard_deviation
        self.recursive_filter_coefficient = recursive_filter_coefficient
        self.reference_transformation = reference_transformation
        self.sharpness = sharpness
        self.sharpness_algorithm = sharpness_algorithm
        self.sigma = sigma
        self.white_level = white_level
        self.acquisition_area = acquisition_area
        self.image_size = image_size
        self.offset = offset
        self.pixel_size = pixel_size
        self.pixel_size_x_unit = pixel_size_x_unit
        self.pixel_size_y_unit = pixel_size_y_unit

    acquisition_unit = create_xml_property(str, "AcquisitionUnit")
    composition_type = create_xml_property(str, "CompositionType")
    image_size = create_xml_property(Point, "ImageSize", auto_convert=True)
    detector = create_xml_property(str, "Detector")
    filter_type = create_xml_property(str, "FilterType")
    recursive_filter_coefficient = create_xml_property(float, "RecursiveFilterCoefficient")
    filter_frame_count = create_xml_property(int, "FilterFrameCount")
    pixel_size = create_custom_xml_property(Point, "PixelSize", auto_convert=True)
    pixel_size_x_unit = create_custom_xml_property(Unit, "PixelSizeXUnit", auto_convert=True)
    pixel_size_y_unit = create_custom_xml_property(Unit, "PixelSizeYUnit", auto_convert=True)
    offset = create_xml_property(Point, "Offset", auto_convert=True)
    intensity_scale = create_custom_xml_property(float, "IntensityScale")
    intensity_scale_unit = create_custom_xml_property(Unit, "IntensityScaleUnit", auto_convert=True)
    intensity_offset = create_xml_property(float, "IntensityOffset")
    black_level = create_xml_property(float, "BlackLevel")
    white_level = create_xml_property(float, "WhiteLevel")
    gamma = create_xml_property(float, "Gamma")
    sigma = create_xml_property(float, "Sigma")
    encoding = create_xml_property(str, "Encoding")
    bits_per_pixel = create_xml_property(int, "BitsPerPixel")
    pixel_value_maximum = create_xml_property(float, "PixelValueMaximum")
    pixel_value_minimum = create_xml_property(float, "PixelValueMinimum")
    pixel_value_mean = create_xml_property(float, "PixelValueMean")
    pixel_value_standard_deviation = create_xml_property(float, "PixelValueStandardDeviation")
    sharpness = create_xml_property(float, "Sharpness")
    sharpness_algorithm = create_xml_property(str, "SharpnessAlgorithm")
    digital_contrast = create_xml_property(float, "DigitalContrast")
    digital_brightness = create_xml_property(float, "DigitalBrightness")
    reference_transformation = create_xml_property(AdornedImageMetadataReferenceTransformation, "ReferenceTransformation")
    acquisition_area = create_xml_property(Rectangle, "AcquisitionArea", auto_convert=True)
    detector_index = create_xml_property(int, "DetectorIndex")

    def serialize(self, parent):
        super().serialize(parent)
        self._serialize_intensity_scale(parent)
        self._serialize_pixel_size(parent)

    def _serialize_intensity_scale(self, parent):
        intensity_scale_element = insert_value_to_element(parent, "IntensityScale", self.intensity_scale,
                                                          OrderingInfo(type(self), "intensity_scale"))
        if self.intensity_scale_unit is not None:
            self.intensity_scale_unit.serialize(intensity_scale_element)

    def _serialize_pixel_size(self, parent):
        if self.pixel_size is not None:
            pixel_size_element = insert_element(parent, "PixelSize", OrderingInfo(type(self), "pixel_size"))
            x_element = insert_value_to_element(pixel_size_element, "X", self.pixel_size.x)
            y_element = insert_value_to_element(pixel_size_element, "Y", self.pixel_size.y)

            if self.pixel_size_x_unit is not None:
                self.pixel_size_x_unit.serialize(x_element)

            if self.pixel_size_y_unit is not None:
                self.pixel_size_y_unit.serialize(y_element)

    @classmethod
    def deserialize(cls, element):
        deserialized = super().deserialize(element)
        cls._deserialize_intensity_scale(element, deserialized)
        cls._deserialize_pixel_size(element, deserialized)
        return deserialized

    @classmethod
    def _deserialize_intensity_scale(cls, element, deserialized):
        intensity_scale_element = element.find("IntensityScale")
        if intensity_scale_element is not None:
            deserialized.intensity_scale = get_value_from_element(intensity_scale_element, ".", float)
            deserialized.intensity_scale_unit = Unit.deserialize(intensity_scale_element)

    @classmethod
    def _deserialize_pixel_size(cls, element, deserialized):
        pixel_size_element = element.find("PixelSize")
        if pixel_size_element is not None:
            x = get_value_from_element(pixel_size_element, "X", float)
            y = get_value_from_element(pixel_size_element, "Y", float)
            deserialized.pixel_size = Point(x, y)

            x_element = pixel_size_element.find("X")
            if x_element is not None:
                deserialized.pixel_size_x_unit = Unit.deserialize(x_element)

            y_element = pixel_size_element.find("Y")
            if y_element is not None:
                deserialized.pixel_size_y_unit = Unit.deserialize(y_element)


class AdornedImageMetadataCore(XmlStructure):
    def __init__(self, application_computer_name: str = None, application_software: str = None,
                 application_software_version: str = None, comment: str = None, file_date_time: str = None,
                 file_name: str = None, guid: str = None, md5_checksum: bytes = None, parent_guid: str = None,
                 private_checksum: bytes = None, user_id: str = None):
        self.application_computer_name = application_computer_name
        self.application_software = application_software
        self.application_software_version = application_software_version
        self.comment = comment
        self.file_date_time = file_date_time
        self.file_name = file_name
        self.guid = guid
        self.md5_checksum = md5_checksum
        self.parent_guid = parent_guid
        self.private_checksum = private_checksum
        self.user_id = user_id

    guid = create_xml_property(str, "Guid")
    parent_guid = create_xml_property(str, "ParentGuid")
    md5_checksum = create_xml_property(bytes, "Md5Checksum")
    private_checksum = create_xml_property(bytes, "PrivateChecksum")
    file_name = create_xml_property(str, "FileName")
    file_date_time = create_xml_property(str, "FileDatetime")
    user_id = create_xml_property(str, "UserID")
    comment = create_xml_property(str, "Comment")
    application_software = create_xml_property(str, "ApplicationSoftware")
    application_software_version = create_xml_property(str, "ApplicationSoftwareVersion")
    application_computer_name = create_xml_property(str, "ApplicationComputerName")


class AdornedImageMetadataScanningDetector(XmlStructure):
    def __init__(self, detector_name: str = None, detector_type: str = None, enabled: bool = None,
                 inserted: bool = None, mix_contribution: float = None, signal: str = None, segments: str = None,
                 gain: float = None, offset: float = None, enhanced_gain: float = None, grid_voltage: float = None,
                 suction_tube_voltage: float = None, front_end_voltage: float = None,
                 converter_electrode_voltage: float = None, scintillator_voltage: float = None,
                 contrast_normalized: float = None, brightness_normalized: float = None,
                 collection_angle_range: Limits = None,
                 custom_properties: List[AdornedImageMetadataCustomProperties] = None,
                 custom_sections: List[AdornedImageMetadataCustomSection] = None):
        self.detector_name = detector_name
        self.detector_type = detector_type
        self.enabled = enabled
        self.inserted = inserted
        self.mix_contribution = mix_contribution
        self.signal = signal
        self.segments = segments
        self.gain = gain
        self.offset = offset
        self.enhanced_gain = enhanced_gain
        self.grid_voltage = grid_voltage
        self.suction_tube_voltage = suction_tube_voltage
        self.front_end_voltage = front_end_voltage
        self.converter_electrode_voltage = converter_electrode_voltage
        self.scintillator_voltage = scintillator_voltage
        self.contrast_normalized = contrast_normalized
        self.brightness_normalized = brightness_normalized
        self.collection_angle_range = collection_angle_range
        self.custom_properties = custom_properties
        self.custom_sections = custom_sections

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "ScanningDetector"

    detector_name = create_xml_property(str, "DetectorName")
    detector_type = create_xml_property(str, "DetectorType")
    inserted = create_xml_property(bool, "Inserted")
    enabled = create_xml_property(bool, "Enabled")
    mix_contribution = create_xml_property(float, "MixContribution")
    signal = create_xml_property(str, "Signal")
    segments = create_xml_property(str, "Segments")
    gain = create_xml_property(float, "Gain")
    offset = create_xml_property(float, "Offset")
    enhanced_gain = create_xml_property(float, "EnhancedGain")
    grid_voltage = create_xml_property(float, "GridVoltage")
    suction_tube_voltage = create_xml_property(float, "SuctionTubeVoltage")
    front_end_voltage = create_xml_property(float, "FrontEndVoltage")
    converter_electrode_voltage = create_xml_property(float, "ConverterElectrodeVoltage")
    scintillator_voltage = create_xml_property(float, "ScintillatorVoltage")
    contrast_normalized = create_xml_property(float, "ContrastNormalized")
    brightness_normalized = create_xml_property(float, "BrightnessNormalized")
    collection_angle_range = create_xml_property(Limits, "CollectionAngleRange")
    custom_properties = create_xml_property(List[AdornedImageMetadataCustomProperties], "CustomPropertyGroup")
    custom_sections = create_xml_property(List[AdornedImageMetadataCustomSection], "CustomSectionGroup")


class AdornedImageMetadataAnalyticalDetector(XmlStructure):
    def __init__(self, detector_name: str = None, detector_type: str = None, enabled: bool = None,
                 inserted: bool = None, mix_contribution: float = None, elevation_angle: float = None,
                 azimuth_angle: float = None, collection_angle: float = None, dispersion: float = None,
                 pulse_process_time: float = None, real_time: float = None, live_time: float = None,
                 input_count_rate: float = None, output_count_rate: float = None,
                 binning: PointLike = None, shutters: List[ValueAndTypeLike] = None, shutter_state: str = None,
                 offset_energy: float = None, electronics_noise: float = None,
                 custom_properties: List[AdornedImageMetadataCustomProperties] = None,
                 custom_sections: List[AdornedImageMetadataCustomSection] = None):
        self.detector_name = detector_name
        self.detector_type = detector_type
        self.enabled = enabled
        self.inserted = inserted
        self.mix_contribution = mix_contribution
        self.elevation_angle = elevation_angle
        self.azimuth_angle = azimuth_angle
        self.collection_angle = collection_angle
        self.dispersion = dispersion
        self.pulse_process_time = pulse_process_time
        self.real_time = real_time
        self.live_time = live_time
        self.input_count_rate = input_count_rate
        self.output_count_rate = output_count_rate
        self.binning = binning
        self.shutters = shutters
        self.shutter_state = shutter_state
        self.offset_energy = offset_energy
        self.electronics_noise = electronics_noise
        self.custom_properties = custom_properties
        self.custom_sections = custom_sections

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "AnalyticalDetector"

    detector_name = create_xml_property(str, "DetectorName")
    detector_type = create_xml_property(str, "DetectorType")
    inserted = create_xml_property(bool, "Inserted")
    enabled = create_xml_property(bool, "Enabled")
    mix_contribution = create_xml_property(float, "MixContribution")
    elevation_angle = create_xml_property(float, "ElevationAngle")
    azimuth_angle = create_xml_property(float, "AzimuthAngle")
    collection_angle = create_xml_property(float, "CollectionAngle")
    dispersion = create_xml_property(float, "Dispersion")
    pulse_process_time = create_xml_property(float, "PulseProcessTime")
    real_time = create_xml_property(float, "RealTime")
    live_time = create_xml_property(float, "LiveTime")
    input_count_rate = create_xml_property(float, "InputCountRate")
    output_count_rate = create_xml_property(float, "OutputCountRate")
    binning = create_xml_property(Point, "Binning", auto_convert=True)
    shutters = create_custom_xml_property(List[ValueAndType], "Shutters", auto_convert=True)
    shutter_state = create_xml_property(str, "ShutterState")
    offset_energy = create_xml_property(float, "OffsetEnergy")
    electronics_noise = create_xml_property(float, "ElectronicsNoise")
    custom_properties = create_xml_property(List[AdornedImageMetadataCustomProperties], "CustomPropertyGroup")
    custom_sections = create_xml_property(List[AdornedImageMetadataCustomSection], "CustomSectionGroup")

    def serialize(self, parent):
        super().serialize(parent)
        element = parent[-1]  # We need to extend the last added element
        ValueAndType.serialize_shutters(element, self.shutters, type(self))

    @classmethod
    def deserialize(cls, element):
        deserialized = super().deserialize(element)
        ValueAndType.deserialize_shutters(element, deserialized)
        return deserialized


class AdornedImageMetadataImagingDetector(XmlStructure):
    def __init__(self, detector_name: str = None, detector_type: str = None, enabled: bool = None,
                 inserted: bool = None, exposure_mode: str = None, gain: float = None,
                 binning: PointLike = None, readout_area: RectangleLike = None, exposure_time: float = None,
                 exposure_time_2: float = None, pre_exposure_time: float = None,
                 shutters: List[ValueAndTypeLike] = None, dark_gain_correction_type: str = None,
                 pre_exposure_pause_time: float = None, scintillator_pixel_size: PointLike = None,
                 post_magnification: float = None, custom_properties: List[AdornedImageMetadataCustomProperties] = None,
                 custom_sections: List[AdornedImageMetadataCustomSection] = None):
        self.detector_name = detector_name
        self.detector_type = detector_type
        self.enabled = enabled
        self.inserted = inserted
        self.exposure_mode = exposure_mode
        self.gain = gain
        self.binning = binning
        self.readout_area = readout_area
        self.exposure_time = exposure_time
        self.exposure_time_2 = exposure_time_2
        self.pre_exposure_time = pre_exposure_time
        self.shutters = shutters
        self.dark_gain_correction_type = dark_gain_correction_type
        self.pre_exposure_pause_time = pre_exposure_pause_time
        self.scintillator_pixel_size = scintillator_pixel_size
        self.post_magnification = post_magnification
        self.custom_properties = custom_properties
        self.custom_sections = custom_sections

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "ImagingDetector"

    detector_name = create_xml_property(str, "DetectorName")
    detector_type = create_xml_property(str, "DetectorType")
    inserted = create_xml_property(bool, "Inserted")
    enabled = create_xml_property(bool, "Enabled")
    exposure_mode = create_xml_property(str, "ExposureMode")
    gain = create_xml_property(float, "Gain")
    binning = create_xml_property(Point, "Binning", auto_convert=True)
    readout_area = create_xml_property(Rectangle, "ReadoutArea", auto_convert=True)
    exposure_time = create_xml_property(float, "ExposureTime")
    exposure_time_2 = create_xml_property(float, "ExposureTime2")
    pre_exposure_time = create_xml_property(float, "PreExposureTime")
    shutters = create_custom_xml_property(List[ValueAndType], "Shutters", auto_convert=True)
    dark_gain_correction_type = create_xml_property(str, "DarkGainCorrectionType")
    pre_exposure_pause_time = create_xml_property(float, "PreExposurePauseTime")
    scintillator_pixel_size = create_xml_property(Point, "ScintillatorPixelSize", auto_convert=True)
    post_magnification = create_xml_property(float, "PostMagnification")
    custom_properties = create_xml_property(List[AdornedImageMetadataCustomProperties], "CustomPropertyGroup")
    custom_sections = create_xml_property(List[AdornedImageMetadataCustomSection], "CustomSectionGroup")

    def serialize(self, parent):
        super().serialize(parent)
        element = parent[-1]  # We need to extend the last added element
        ValueAndType.serialize_shutters(element, self.shutters, type(self))

    @classmethod
    def deserialize(cls, element):
        deserialized = super().deserialize(element)
        ValueAndType.deserialize_shutters(element, deserialized)
        return deserialized


class AdornedImageMetadataEnergyFilterSettings(XmlStructure):
    def __init__(self, acceleration_voltage_offset: float = None, drift_tube_voltage: float = None,
                 energy_selection_slit_width: float = None, energy_shift: float = None,
                 entrance_aperture_diameter: float = None, entrance_aperture_type: str = None,
                 energy_selection_slit_inserted: bool = None):
        self.acceleration_voltage_offset = acceleration_voltage_offset
        self.drift_tube_voltage = drift_tube_voltage
        self.energy_selection_slit_width = energy_selection_slit_width
        self.energy_shift = energy_shift
        self.entrance_aperture_diameter = entrance_aperture_diameter
        self.entrance_aperture_type = entrance_aperture_type
        self.energy_selection_slit_inserted = energy_selection_slit_inserted

    acceleration_voltage_offset = create_xml_property(float, "AccelerationVoltageOffset")
    drift_tube_voltage = create_xml_property(float, "DriftTubeVoltage")
    energy_shift = create_xml_property(float, "EnergyShift")
    energy_selection_slit_width = create_xml_property(float, "EnergySelectionSlitWidth")
    energy_selection_slit_inserted = create_xml_property(bool, "EnergySelectionSlitInserted")
    entrance_aperture_diameter = create_xml_property(float, "EntranceApertureDiameter")
    entrance_aperture_type = create_xml_property(str, "EntranceApertureType")


class AdornedImageMetadataGasInjectionSystemGas(XmlStructure):
    def __init__(self, crucible_temperature: float = None, gas_type: str = None):
        self.crucible_temperature = crucible_temperature
        self.gas_type = gas_type

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "Gas"

    gas_type = create_xml_property(str, "GasType")
    crucible_temperature = create_xml_property(float, "CrucibleTemperature")


class AdornedImageMetadataGasInjectionSystem(XmlStructure):
    def __init__(self, gases: List[AdornedImageMetadataGasInjectionSystemGas] = None, needle_temperature: float = None,
                 gas_flow_on: bool = None, heater_on: bool = None, needle_state: str = None, port_name: str = None,
                 port_number: int = None, custom_properties: List[AdornedImageMetadataCustomProperties] = None,
                 custom_sections: List[AdornedImageMetadataCustomSection] = None):
        self.gases = gases
        self.needle_temperature = needle_temperature
        self.gas_flow_on = gas_flow_on
        self.heater_on = heater_on
        self.needle_state = needle_state
        self.port_name = port_name
        self.port_number = port_number
        self.custom_properties = custom_properties
        self.custom_sections = custom_sections

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "Gis"

    port_number = create_xml_property(int, "PortNumber")
    port_name = create_xml_property(str, "PortName")
    heater_on = create_xml_property(bool, "HeaterOn")
    gas_flow_on = create_xml_property(bool, "GasFlowOn")
    needle_state = create_xml_property(str, "NeedleState")
    needle_temperature = create_xml_property(float, "NeedleTemperature")
    gases = create_xml_property(List[AdornedImageMetadataGasInjectionSystemGas], "Gases")
    custom_properties = create_xml_property(List[AdornedImageMetadataCustomProperties], "CustomPropertyGroup")
    custom_sections = create_xml_property(List[AdornedImageMetadataCustomSection], "CustomSectionGroup")


class AdornedImageMetadataInstrument(XmlStructure):
    def __init__(self, acquisition_server: str = None, acquisition_server_version: str = None,
                 computer_name: str = None, control_software: str = None, control_software_version: str = None,
                 instrument_class: str = None, instrument_id: str = None, instrument_model: str = None,
                 manufacturer: str = None):
        self.acquisition_server = acquisition_server
        self.acquisition_server_version = acquisition_server_version
        self.computer_name = computer_name
        self.control_software = control_software
        self.control_software_version = control_software_version
        self.instrument_class = instrument_class
        self.instrument_id = instrument_id
        self.instrument_model = instrument_model
        self.manufacturer = manufacturer

    acquisition_server = create_xml_property(str, "AcquisitionServer")
    acquisition_server_version = create_xml_property(str, "AcquisitionServerVersion")
    control_software = create_xml_property(str, "ControlSoftware")
    control_software_version = create_xml_property(str, "ControlSoftwareVersion")
    manufacturer = create_xml_property(str, "Manufacturer")
    instrument_class = create_xml_property(str, "InstrumentClass")
    instrument_model = create_xml_property(str, "InstrumentModel")
    instrument_id = create_xml_property(str, "InstrumentID")
    computer_name = create_xml_property(str, "ComputerName")


class AdornedImageMetadataOpticsAperture(XmlStructure):
    def __init__(self, diameter: float = None, index: int = None, mechanism_type: str = None, name: str = None,
                 number: int = None, type: str = None, position_offset: PointLike = None):
        self.diameter = diameter
        self.index = index
        self.mechanism_type = mechanism_type
        self.name = name
        self.number = number
        self.type = type
        self.position_offset = position_offset

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "Aperture"

    number = create_xml_property(int, "Number")
    name = create_xml_property(str, "Name")
    mechanism_type = create_xml_property(str, "MechanismType")
    type = create_xml_property(str, "Type")
    diameter = create_xml_property(float, "Diameter")
    index = create_xml_property(int, "Index")
    position_offset = create_xml_property(Point, "PositionOffset", auto_convert=True)


class AdornedImageMetadataOptics(XmlStructure):
    def __init__(self, acceleration_voltage: float = None, apertures: List[AdornedImageMetadataOpticsAperture] = None,
                 beam_convergence: float = None, beam_current: float = None, beam_current_selected: float = None,
                 beam_diameter: float = None, camera_length: float = None, deceleration_voltage: float = None,
                 defocus: float = None, emission_current: float = None, eucentric_working_distance: float = None,
                 extractor_voltage: float = None, fib_l0_voltage: float = None, fib_l1_voltage: float = None,
                 fib_l2_voltage: float = None, focus: float = None, full_scan_field_of_view: PointLike = None,
                 last_measured_screen_current: float = None, sample_pre_tilt_angle: float = None,
                 scan_field_of_view: PointLike = None, screen_current: float = None, spherical_aberration: float = None,
                 spot_size: float = None, stem_focus: float = None, wehnelt_bias: float = None,
                 working_distance: float = None, cross_over_on: bool = None, diffraction_focus: float = None,
                 eftem_on: bool = None, gun_filament_setting: float = None, gun_lens_setting: float = None,
                 high_magnification_mode: str = None, illumination_intensity_normalized: float = None,
                 illumination_mode: str = None, illumination_on: bool = None, illumination_type: str = None,
                 nominal_magnification: float = None, objective_lens_mode: str = None, operating_mode: str = None,
                 optical_mode: str = None, probe_mode: str = None, projector_mode: str = None,
                 sample_tilt_correction_is_on: bool = None, spot_index: int = None, tem_operating_sub_mode: str = None,
                 beam_shift: PointLike = None, beam_tilt: PointLike = None, c1_lens_intensity: float = None,
                 c2_lens_intensity: float = None, c3_lens_intensity: float = None,
                 condenser_stigmator_raw: PointLike = None, diffraction_lens_intensity: float = None,
                 diffraction_stigmator_raw: PointLike = None, fib_steering: PointLike = None,
                 gun_shift_raw: PointLike = None, gun_stigmator_raw: PointLike = None, gun_tilt_raw: PointLike = None,
                 image_shift: PointLike = None, intermediate_lens_intensity: float = None,
                 lorentz_lens_intensity: float = None, mini_condenser_lens_intensity: float = None,
                 objective_lens_intensity: float = None, objective_stigmator_raw: PointLike = None,
                 projector1_lens_intensity: float = None, projector2_lens_intensity: float = None,
                 stigmator_raw: PointLike = None, beam_modulator: AdornedImageMetadataOpticsBeamModulator = None):
        self.acceleration_voltage = acceleration_voltage
        self.apertures = apertures
        self.beam_convergence = beam_convergence
        self.beam_current = beam_current
        self.beam_current_selected = beam_current_selected
        self.beam_diameter = beam_diameter
        self.camera_length = camera_length
        self.deceleration_voltage = deceleration_voltage
        self.defocus = defocus
        self.emission_current = emission_current
        self.eucentric_working_distance = eucentric_working_distance
        self.extractor_voltage = extractor_voltage
        self.fib_l0_voltage = fib_l0_voltage
        self.fib_l1_voltage = fib_l1_voltage
        self.fib_l2_voltage = fib_l2_voltage
        self.focus = focus
        self.full_scan_field_of_view = full_scan_field_of_view
        self.last_measured_screen_current = last_measured_screen_current
        self.sample_pre_tilt_angle = sample_pre_tilt_angle
        self.scan_field_of_view = scan_field_of_view
        self.screen_current = screen_current
        self.spherical_aberration = spherical_aberration
        self.spot_size = spot_size
        self.stem_focus = stem_focus
        self.wehnelt_bias = wehnelt_bias
        self.working_distance = working_distance
        self.cross_over_on = cross_over_on
        self.diffraction_focus = diffraction_focus
        self.eftem_on = eftem_on
        self.gun_filament_setting = gun_filament_setting
        self.gun_lens_setting = gun_lens_setting
        self.high_magnification_mode = high_magnification_mode
        self.illumination_intensity_normalized = illumination_intensity_normalized
        self.illumination_mode = illumination_mode
        self.illumination_on = illumination_on
        self.illumination_type = illumination_type
        self.nominal_magnification = nominal_magnification
        self.objective_lens_mode = objective_lens_mode
        self.operating_mode = operating_mode
        self.optical_mode = optical_mode
        self.probe_mode = probe_mode
        self.projector_mode = projector_mode
        self.sample_tilt_correction_is_on = sample_tilt_correction_is_on
        self.spot_index = spot_index
        self.tem_operating_sub_mode = tem_operating_sub_mode
        self.beam_shift = beam_shift
        self.beam_tilt = beam_tilt
        self.c1_lens_intensity = c1_lens_intensity
        self.c2_lens_intensity = c2_lens_intensity
        self.c3_lens_intensity = c3_lens_intensity
        self.condenser_stigmator_raw = condenser_stigmator_raw
        self.diffraction_lens_intensity = diffraction_lens_intensity
        self.diffraction_stigmator_raw = diffraction_stigmator_raw
        self.fib_steering = fib_steering
        self.gun_shift_raw = gun_shift_raw
        self.gun_stigmator_raw = gun_stigmator_raw
        self.gun_tilt_raw = gun_tilt_raw
        self.image_shift = image_shift
        self.intermediate_lens_intensity = intermediate_lens_intensity
        self.lorentz_lens_intensity = lorentz_lens_intensity
        self.mini_condenser_lens_intensity = mini_condenser_lens_intensity
        self.objective_lens_intensity = objective_lens_intensity
        self.objective_stigmator_raw = objective_stigmator_raw
        self.projector1_lens_intensity = projector1_lens_intensity
        self.projector2_lens_intensity = projector2_lens_intensity
        self.stigmator_raw = stigmator_raw
        self.beam_modulator = beam_modulator

    apertures = create_xml_property(List[AdornedImageMetadataOpticsAperture], "Apertures")
    gun_lens_setting = create_xml_property(float, "GunLensSetting")
    wehnelt_bias = create_xml_property(float, "WehneltBias")
    extractor_voltage = create_xml_property(float, "ExtractorVoltage")
    gun_shift_raw = create_xml_property(Point, "GunShiftRaw", auto_convert=True)
    gun_tilt_raw = create_xml_property(Point, "GunTiltRaw", auto_convert=True)
    acceleration_voltage = create_xml_property(float, "AccelerationVoltage")
    deceleration_voltage = create_xml_property(float, "DecelerationVoltage")
    spot_index = create_xml_property(int, "SpotIndex")
    c2_lens_intensity = create_xml_property(float, "C2LensIntensity")
    c3_lens_intensity = create_xml_property(float, "C3LensIntensity")
    c1_lens_intensity = create_xml_property(float, "C1LensIntensity")
    objective_lens_intensity = create_xml_property(float, "ObjectiveLensIntensity")
    intermediate_lens_intensity = create_xml_property(float, "IntermediateLensIntensity")
    diffraction_lens_intensity = create_xml_property(float, "DiffractionLensIntensity")
    projector1_lens_intensity = create_xml_property(float, "Projector1LensIntensity")
    projector2_lens_intensity = create_xml_property(float, "Projector2LensIntensity")
    lorentz_lens_intensity = create_xml_property(float, "LorentzLensIntensity")
    mini_condenser_lens_intensity = create_xml_property(float, "MiniCondenserLensIntensity")
    spot_size = create_xml_property(float, "SpotSize")
    emission_current = create_xml_property(float, "EmissionCurrent")
    beam_current = create_xml_property(float, "BeamCurrent")
    beam_current_selected = create_xml_property(float, "BeamCurrentSelected")
    beam_diameter = create_xml_property(float, "BeamDiameter")
    beam_convergence = create_xml_property(float, "BeamConvergence")
    screen_current = create_xml_property(float, "ScreenCurrent")
    last_measured_screen_current = create_xml_property(float, "LastMeasuredScreenCurrent")
    illumination_on = create_xml_property(bool, "IlluminationOn")
    illumination_type = create_xml_property(str, "IlluminationType")
    illumination_intensity_normalized = create_xml_property(float, "IlluminationIntensityNormalized")
    full_scan_field_of_view = create_xml_property(Point, "FullScanFieldOfView", auto_convert=True)
    scan_field_of_view = create_xml_property(Point, "ScanFieldOfView", auto_convert=True)
    working_distance = create_xml_property(float, "WorkingDistance")
    eucentric_working_distance = create_xml_property(float, "EucentricWorkingDistance")
    beam_tilt = create_xml_property(Point, "BeamTilt", auto_convert=True)
    image_shift = create_xml_property(Point, "ImageShift", auto_convert=True)
    beam_shift = create_xml_property(Point, "BeamShift", auto_convert=True)
    sample_tilt_correction_is_on = create_xml_property(bool, "SampleTiltCorrectionOn")
    sample_pre_tilt_angle = create_xml_property(float, "SamplePreTiltAngle")
    stigmator_raw = create_xml_property(Point, "StigmatorRaw", auto_convert=True)
    gun_stigmator_raw = create_xml_property(Point, "GunStigmatorRaw", auto_convert=True)
    condenser_stigmator_raw = create_xml_property(Point, "CondenserStigmatorRaw", auto_convert=True)
    objective_stigmator_raw = create_xml_property(Point, "ObjectiveStigmatorRaw", auto_convert=True)
    diffraction_stigmator_raw = create_xml_property(Point, "DiffractionStigmatorRaw", auto_convert=True)
    spherical_aberration = create_xml_property(float, "SphericalAberration")
    focus = create_xml_property(float, "Focus")
    stem_focus = create_xml_property(float, "STEMFocus")
    defocus = create_xml_property(float, "Defocus")
    nominal_magnification = create_xml_property(float, "NominalMagnification")
    high_magnification_mode = create_xml_property(str, "HighMagnificationMode")
    operating_mode = create_xml_property(str, "OperatingMode")
    tem_operating_sub_mode = create_xml_property(str, "TEMOperatingSubMode")
    optical_mode = create_xml_property(str, "OpticalMode")
    projector_mode = create_xml_property(str, "ProjectorMode")
    eftem_on = create_xml_property(bool, "EFTEMOn")
    objective_lens_mode = create_xml_property(str, "ObjectiveLensMode")
    illumination_mode = create_xml_property(str, "IlluminationMode")
    probe_mode = create_xml_property(str, "ProbeMode")
    camera_length = create_xml_property(float, "CameraLength")
    diffraction_focus = create_xml_property(float, "DiffractionFocus")
    cross_over_on = create_xml_property(bool, "CrossOverOn")
    fib_l1_voltage = create_xml_property(float, "FibL1Voltage")
    fib_l2_voltage = create_xml_property(float, "FibL2Voltage")
    fib_l0_voltage = create_xml_property(float, "FibL0Voltage")
    fib_steering = create_xml_property(Point, "FibSteering", auto_convert=True)
    gun_filament_setting = create_xml_property(float, "GunFilamentSetting")
    beam_modulator = create_xml_property(AdornedImageMetadataOpticsBeamModulator, "BeamModulator")


class AdornedImageMetadataSample(XmlStructure):
    def __init__(self, region_of_interest_id: str = None, sample_description: str = None, sample_guid: str = None,
                 sample_id: str = None, sample_session_id: str = None):
        self.region_of_interest_id = region_of_interest_id
        self.sample_description = sample_description
        self.sample_guid = sample_guid
        self.sample_id = sample_id
        self.sample_session_id = sample_session_id

    sample_guid = create_xml_property(str, "SampleGuid")
    sample_id = create_xml_property(str, "SampleID")
    sample_description = create_xml_property(str, "SampleDescription")
    sample_session_id = create_xml_property(str, "SampleSessionID")
    region_of_interest_id = create_xml_property(str, "RegionOfInterestID")


class AdornedImageMetadataScanSettings(XmlStructure):
    def __init__(self, scan_rotation: float = None, line_integration_count: int = None, line_interlacing: int = None,
                 mains_lock_on: bool = None, scan_size: PointLike = None, acquisition_time: float = None,
                 dwell_time: float = None, frame_time: float = None, line_time: float = None,
                 scan_area: RectangleLike = None):
        self.scan_rotation = scan_rotation
        self.line_integration_count = line_integration_count
        self.line_interlacing = line_interlacing
        self.mains_lock_on = mains_lock_on
        self.scan_size = scan_size
        self.acquisition_time = acquisition_time
        self.dwell_time = dwell_time
        self.frame_time = frame_time
        self.line_time = line_time
        self.scan_area = scan_area

    dwell_time = create_xml_property(float, "DwellTime")
    scan_size = create_custom_xml_property(Point, "ScanSize", auto_convert=True)
    scan_area = create_xml_property(Rectangle, "ScanArea", auto_convert=True)
    mains_lock_on = create_xml_property(bool, "MainsLockOn")
    line_time = create_xml_property(float, "LineTime")
    line_integration_count = create_xml_property(int, "LineIntegrationCount")
    line_interlacing = create_xml_property(int, "LineInterlacing")
    frame_time = create_xml_property(float, "FrameTime")
    acquisition_time = create_xml_property(float, "AcquisitionTime")
    scan_rotation = create_xml_property(float, "ScanRotation")

    def serialize(self, parent):
        super().serialize(parent)
        self._serialize_scan_size(parent)

    def _serialize_scan_size(self, parent):
        if self.scan_size is not None:
            scan_size_element = insert_element(parent, "ScanSize", OrderingInfo(type(self), "scan_size"))
            self.scan_size.serialize_size(scan_size_element)

    @classmethod
    def deserialize(cls, element):
        deserialized = super().deserialize(element)
        cls._deserialize_scan_size(element, deserialized)
        return deserialized

    @classmethod
    def _deserialize_scan_size(cls, element, deserialized):
        scan_size_element = element.find("ScanSize")
        if scan_size_element is not None:
            deserialized.scan_size = Point.deserialize_size(scan_size_element)


class AdornedImageMetadataStageSettings(XmlStructure):
    def __init__(self, holder_temperature: float = None, holder_type: str = None, sample_loader: str = None,
                 stage_position: AdornedImageMetadataStagePositionLike = None):
        self.holder_temperature = holder_temperature
        self.holder_type = holder_type
        self.sample_loader = sample_loader
        self.stage_position = stage_position

    stage_position = create_xml_property(AdornedImageMetadataStagePosition, "StagePosition",
                                         auto_convert=True)
    holder_type = create_xml_property(str, "HolderType")
    holder_temperature = create_xml_property(float, "HolderTemperature")
    sample_loader = create_xml_property(str, "SampleLoader")


class AdornedImageMetadataVacuumProperties(XmlStructure):
    def __init__(self, electron_column_pressure: float = None, electron_source_pressure: float = None,
                 ion_column_pressure: float = None, ion_source_pressure: float = None,
                 projection_chamber_pressure: float = None, sample_pressure: float = None, vacuum_mode: str = None):
        self.electron_column_pressure = electron_column_pressure
        self.electron_source_pressure = electron_source_pressure
        self.ion_column_pressure = ion_column_pressure
        self.ion_source_pressure = ion_source_pressure
        self.projection_chamber_pressure = projection_chamber_pressure
        self.sample_pressure = sample_pressure
        self.vacuum_mode = vacuum_mode

    sample_pressure = create_xml_property(float, "SamplePressure")
    vacuum_mode = create_xml_property(str, "VacuumMode")
    electron_source_pressure = create_xml_property(float, "ElectronSourcePressure")
    ion_source_pressure = create_xml_property(float, "IonSourcePressure")
    electron_column_pressure = create_xml_property(float, "ElectronColumnPressure")
    ion_column_pressure = create_xml_property(float, "IonColumnPressure")
    projection_chamber_pressure = create_xml_property(float, "ProjectionChamberPressure")


class AdornedImageMetadata(shell.AdornedImageMetadata):
    __slots__ = []

    def __init__(self, acquisition: AdornedImageMetadataAcquisition = None,
                 binary_result: AdornedImageMetadataBinaryResult = None, core: AdornedImageMetadataCore = None,
                 scanning_detectors: List[AdornedImageMetadataScanningDetector] = None,
                 analytical_detectors: List[AdornedImageMetadataAnalyticalDetector] = None,
                 imaging_detectors: List[AdornedImageMetadataImagingDetector] = None,
                 energy_filter_settings: AdornedImageMetadataEnergyFilterSettings = None,
                 gas_injection_systems: List[AdornedImageMetadataGasInjectionSystem] = None,
                 instrument: AdornedImageMetadataInstrument = None, optics: AdornedImageMetadataOptics = None,
                 sample: AdornedImageMetadataSample = None, scan_settings: AdornedImageMetadataScanSettings = None,
                 stage_settings: AdornedImageMetadataStageSettings = None,
                 vacuum_properties: AdornedImageMetadataVacuumProperties = None, labels: List[ValueAndTypeLike] = None,
                 custom_properties: List[AdornedImageMetadataCustomProperties] = None,
                 custom_sections: List[AdornedImageMetadataCustomSection] = None):
        super().__init__()

        self._metadata_as_ini = None
        self._lazy_deserialized = False
        self._init_in_progress = True

        try:
            self.acquisition = acquisition
            self.binary_result = binary_result
            self.core = core
            self.scanning_detectors = scanning_detectors
            self.analytical_detectors = analytical_detectors
            self.imaging_detectors = imaging_detectors
            self.energy_filter_settings = energy_filter_settings
            self.gas_injection_systems = gas_injection_systems
            self.instrument = instrument
            self.optics = optics
            self.sample = sample
            self.scan_settings = scan_settings
            self.stage_settings = stage_settings
            self.vacuum_properties = vacuum_properties
            self.labels = labels
            self.custom_properties = custom_properties
            self.custom_sections = custom_sections
        finally:
            self._init_in_progress = False

    def _lazy_deserialization(self):
        """
        This function handles lazy deserialization. Only objects arriving from the server are lazily deserialized
        (_raw_metadata_as_xml is not None).

        Init in progress is used as a way to pause lazy deserialization. While it's true, the property access are
        ignored so the object is not deserialized right away or multiple times.
        """

        if not self._lazy_deserialized and not self._init_in_progress and self._raw_metadata_as_xml is not None:
            self._deserialize(self._raw_metadata_as_xml)

    core = create_xml_property(AdornedImageMetadataCore, "Core", access_callback=_lazy_deserialization)
    labels = create_xml_property(List[ValueAndType], "Labels", auto_convert=True,
                                 access_callback=_lazy_deserialization)
    instrument = create_xml_property(AdornedImageMetadataInstrument, "Instrument",
                                     access_callback=_lazy_deserialization)
    acquisition = create_xml_property(AdornedImageMetadataAcquisition, "Acquisition",
                                      access_callback=_lazy_deserialization)
    optics = create_xml_property(AdornedImageMetadataOptics, "Optics", access_callback=_lazy_deserialization)
    energy_filter_settings = create_xml_property(AdornedImageMetadataEnergyFilterSettings, "EnergyFilterSettings",
                                                 access_callback=_lazy_deserialization)
    stage_settings = create_xml_property(AdornedImageMetadataStageSettings, "StageSettings",
                                         access_callback=_lazy_deserialization)
    scan_settings = create_xml_property(AdornedImageMetadataScanSettings, "ScanSettings",
                                        access_callback=_lazy_deserialization)
    vacuum_properties = create_xml_property(AdornedImageMetadataVacuumProperties, "VacuumProperties",
                                            access_callback=_lazy_deserialization)
    scanning_detectors = create_xml_property(List[AdornedImageMetadataScanningDetector], "Detectors",
                                             "_scanning_detectors", access_callback=_lazy_deserialization)
    analytical_detectors = create_xml_property(List[AdornedImageMetadataAnalyticalDetector], "Detectors",
                                               "_analytical_detectors", access_callback=_lazy_deserialization)
    imaging_detectors = create_xml_property(List[AdornedImageMetadataImagingDetector], "Detectors",
                                            "_imaging_detectors", access_callback=_lazy_deserialization)
    gas_injection_systems = create_xml_property(List[AdornedImageMetadataGasInjectionSystem], "GasInjectionSystems",
                                                access_callback=_lazy_deserialization)
    binary_result = create_xml_property(AdornedImageMetadataBinaryResult, "BinaryResult",
                                        access_callback=_lazy_deserialization)
    sample = create_xml_property(AdornedImageMetadataSample, "Sample", access_callback=_lazy_deserialization)
    custom_properties = create_xml_property(List[AdornedImageMetadataCustomProperties], "CustomPropertyGroup",
                                            access_callback=_lazy_deserialization)
    custom_sections = create_xml_property(List[AdornedImageMetadataCustomSection], "CustomSectionGroup",
                                          access_callback=_lazy_deserialization)

    @property
    def metadata_as_xml(self) -> 'str':
        """
        Provides all available metadata in single XML file.
        """

        return self._serialize()

    @property
    def metadata_as_ini(self) -> 'Optional[str]':
        """
        INI metadata loaded from image. Edit and parsing is not supported.
        """

        return self._metadata_as_ini

    @staticmethod
    def create_from_xml(xml: str) -> 'Optional[AdornedImageMetadata]':
        """
        Creates new metadata structure from an XML string.
        :param xml: Xml metadata.
        :return: Newly created and populated metadata structure. If deserialization fails, returns None.
        """

        metadata = AdornedImageMetadata()
        if metadata._deserialize(xml):
            return metadata
        else:
            return None

    @staticmethod
    def create_from_image_data(xml: str, ini: Optional[str]):
        """
        Creates new metadata structure from metadata encoded to the image.
        :param xml: Xml metadata.
        :param ini: Ini metadata.
        :return: Newly created and populated metadata structure.
        """

        metadata = AdornedImageMetadata()
        metadata._deserialize(xml)
        metadata._metadata_as_ini = ini
        return metadata

    def _get_metadata_custom_properties(self, scope: str) -> List[AdornedImageMetadataCustomProperty]:
        """
        Gets custom property list from the provided metadata object in a given scope.
        """

        custom_propeties_with_scope = [p for p in self.custom_properties if p.scope == scope]
        if not custom_propeties_with_scope:
            return []

        return custom_propeties_with_scope[0].properties

    def get_custom_property(self, property_id: Union[str, Callable[[str], bool]], scope: Optional[str] = "") -> AdornedImageMetadataCustomProperty:
        """
        Gets custom property from the metadata object from a given scope ("" by default).
        The property can be identified by name or by a predicate function.
        """
        if not self.custom_properties:
            raise ValueError("Custom properties are missing.")

        if isinstance(property_id, str):
            predicate = lambda name: name == property_id
        else:
            predicate = property_id

        custom_properties = self._get_metadata_custom_properties(scope)

        for p in custom_properties:
            if predicate(p.name):
                return p

        raise ValueError(f"Custom property '{property_id}' not found in scope '{scope}'.")

    def _deserialize(self, xml: str) -> bool:
        """
        Deserializes this metadata object from a given xml string. Returns true if the deserialization was successful.
        """

        if xml is None:
            raise ValueError("Xml value is None.")

        try:
            self._init_in_progress = True
            deserialize(etree.fromstring(bytes(xml, encoding="utf-8")), None, self)
            return True
        except (etree.ParseError, XmlError):
            Logging.loggers[LogDomain.APPLICATION_CLIENT].log_error(
                "There was an error while deserializing xml metadata.")
            return False
        finally:
            self._init_in_progress = False
            self._lazy_deserialized = True

    def _serialize(self) -> 'str':
        """
        Creates xml from this metadata object. If the metadata are not in the correct format, returns None.

        :return: Metadata xml in a string form.
        """

        # If the object wasn't deserialized before, it should be
        self._lazy_deserialization()

        try:
            # Namespaces are not implemented correctly in xml metadata, this is a hack
            # that ensures that namespaces are not changed.
            nsmap = {
                "nil": "http://schemas.fei.com/Metadata/v1/2013/07",
                "xsi": "http://www.w3.org/2001/XMLSchema-instance"
            }

            root = etree.Element("Metadata", nsmap=nsmap)
            serialize(root, None, self)
            return etree.tostring(root, pretty_print=True, encoding="utf-8", xml_declaration=True).decode("utf-8")
        except XmlError:
            Logging.loggers[LogDomain.APPLICATION_CLIENT].log_error(
                "There was an error while serializing xml metadata.")

    def _serialize_to(self, bytes_builder, serializer):
        # Overrides serialization (this is called when AdornedImageMetadata is sent to the server)
        # Metadata object is serialized and sent to the server in a xml form
        self._raw_metadata_as_xml = self._serialize()
        super()._serialize_to(bytes_builder, serializer)
