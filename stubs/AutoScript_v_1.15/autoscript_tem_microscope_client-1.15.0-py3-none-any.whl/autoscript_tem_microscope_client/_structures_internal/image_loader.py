import PIL.Image as PilImage


def open_pil_image(path: str) -> PilImage:
    """
    Bypasses PIL's image size limit to load larger images.
    """

    max_pixels = PilImage.MAX_IMAGE_PIXELS
    try:
        PilImage.MAX_IMAGE_PIXELS = None
        return PilImage.open(path)
    finally:
        PilImage.MAX_IMAGE_PIXELS = max_pixels
