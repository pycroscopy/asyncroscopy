from typing import List, NamedTuple, Union


class StageIndexer(NamedTuple):
    index: int
    axis_name: str
    property: property


def search_stage_indexers(indexers: List[StageIndexer], index: Union[int, str], class_name: str) -> property:
    if not isinstance(index, (int, str)):
        raise TypeError(f"{class_name} index has to be an integer or a string.") from None

    for property_indexer in indexers:
        if index in (property_indexer.index, property_indexer.axis_name, property_indexer.axis_name.casefold()):
            return property_indexer.property

    raise IndexError(f"{class_name} index is out of allowed range.") from None


class Indexer(NamedTuple):
    index: int
    property: property


def search_indexers(indexers: List[Indexer], index: int, class_name: str) -> property:
    if not isinstance(index, int):
        raise TypeError(f"{class_name} index has to be an integer or a string.") from None

    for property_indexer in indexers:
        if index == property_indexer.index:
            return property_indexer.property

    raise IndexError(f"{class_name} index is out of allowed range.") from None
