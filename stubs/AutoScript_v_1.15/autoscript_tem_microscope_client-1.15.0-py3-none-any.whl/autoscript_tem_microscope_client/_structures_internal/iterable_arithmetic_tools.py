import numpy
from math import isclose


def add(iterable, other):
    try:
        result = type(iterable)()

        if isinstance(other, (int, float, numpy.floating)):
            for i in range(len(iterable)):
                if iterable[i] is not None:
                    result[i] = iterable[i] + other
        else:
            for i in range(len(iterable)):
                if len(other) > i:
                    if iterable[i] is not None and other[i] is not None:
                        result[i] = iterable[i] + other[i]

        return result
    except Exception:
        raise ValueError(f"Cannot add the given {type(other).__name__} to a "
                         f"{type(iterable).__name__}.") from None


def sub(iterable, other):
    try:
        result = type(iterable)()

        if isinstance(other, (int, float, numpy.floating)):
            for i in range(len(iterable)):
                if iterable[i] is not None:
                    result[i] = iterable[i] - other
        else:
            for i in range(len(iterable)):
                if len(other) > i:
                    if iterable[i] is not None and other[i] is not None:
                        result[i] = iterable[i] - other[i]

        return result
    except Exception:
        raise ValueError(f"Cannot subtract the given {type(other).__name__} from a "
                         f"{type(iterable).__name__}.") from None


def rsub(iterable, other):
    try:
        result = type(iterable)()

        if isinstance(other, (int, float, numpy.floating)):
            for i in range(len(iterable)):
                if iterable[i] is not None:
                    result[i] = other - iterable[i]
        else:
            for i in range(len(iterable)):
                if len(other) > i:
                    if iterable[i] is not None and other[i] is not None:
                        result[i] = other[i] - iterable[i]

        return result
    except Exception:
        raise ValueError(f"Cannot subtract a {type(iterable).__name__} "
                         f"from the given {type(other).__name__}.") from None


def mul(iterable, other, allow_dot_product):
    try:
        if isinstance(other, (int, float, numpy.floating)):
            result = type(iterable)()

            for i in range(len(iterable)):
                if iterable[i] is not None:
                    result[i] = iterable[i] * other
        else:
            if not allow_dot_product:
                raise

            result = 0

            for i in range(len(iterable)):
                if iterable[i] is not None and other[i] is not None:
                    result += iterable[i] * other[i]

        return result
    except Exception:
        raise ValueError(f"Cannot multiply the given {type(other).__name__} by a "
                         f"{type(iterable).__name__}.") from None


def truediv(iterable, other):
    try:
        result = type(iterable)()

        for i in range(len(iterable)):
            if iterable[i] is not None:
                result[i] = iterable[i] / other

        return result
    except Exception:
        raise ValueError(f"Cannot divide the given {type(other).__name__} by a "
                         f"{type(iterable).__name__}.") from None


def rtruediv(iterable, other):
    try:
        result = type(iterable)()

        for i in range(len(iterable)):
            if iterable[i] is not None:
                result[i] = other / iterable[i]

        return result
    except Exception:
        raise ValueError(f"Cannot divide a {type(iterable).__name__} "
                         f"by the given {type(other).__name__}.") from None


def floordiv(iterable, other):
    try:
        result = type(iterable)()

        for i in range(len(iterable)):
            if iterable[i] is not None:
                result[i] = iterable[i] // other

        return result
    except Exception:
        raise ValueError(f"Cannot divide the given {type(other).__name__} "
                         f"by a {type(iterable).__name__}.") from None


def rfloordiv(iterable, other):
    try:
        result = type(iterable)()

        for i in range(len(iterable)):
            if iterable[i] is not None:
                result[i] = other // iterable[i]

        return result
    except Exception:
        raise ValueError(f"Cannot divide a {type(iterable).__name__} "
                         f"by the given {type(other).__name__}.") from None


def eq(iterable, other, compare_lengths: bool, tolerance=1e-6):
    try:
        if compare_lengths and len(iterable) != len(other):
            return False

        for i in range(max(len(iterable), len(other))):
            # Both self and other have i-th value
            if len(other) > i and len(iterable) > i:
                if (iterable[i] is not None and other[i] is None) or (iterable[i] is None and other[i] is not None):
                    return False
                if iterable[i] is not None and other[i] is not None and not _are_values_equal(iterable[i], other[i],
                                                                                              tolerance):
                    return False
            else:
                # If self doesn't have the value, other has to be None and vice versa
                if len(iterable) <= i and other[i] is not None:
                    return False
                if len(other) <= i and iterable[i] is not None:
                    return False

        return True
    except Exception:
        return False


def _are_values_equal(value1, value2, tolerance: float):
    if isinstance(value1, (float, int)) and isinstance(value2, (float, int)):
        return isclose(value1, value2, abs_tol=tolerance)

    return value1 == value2
