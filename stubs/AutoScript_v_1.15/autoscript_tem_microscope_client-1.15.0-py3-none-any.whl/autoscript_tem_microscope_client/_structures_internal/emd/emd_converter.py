import os
import subprocess
import sys


def convert_emd_file(input_path: str, output_path: str):
    """
    Converts an emd experiment file to a new format version using the ExperimentConverter application.
    :param input_path: Path to the input file.
    :param output_path: Path to the output file.
    """

    experiment_converter_path = os.path.join(os.path.dirname(__file__), "EmdFileStorage", "ExperimentConverter.exe")
    run_info = subprocess.run([experiment_converter_path, "-i", input_path, "-o", output_path],
                              stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)

    if run_info.returncode != 0:
        raise Exception("Error converting emd file: " + run_info.stderr.decode(sys.getfilesystemencoding()))
