import traceback

from typing import Optional, get_origin, get_args


def check_property_value(property_type, value):
    """
    Validates the value of the property.
    """

    def raise_type_error():
        raise TypeError(f"Given value '{value}' is not instance of type {property_type}.")

    if value is not None:
        if is_list(get_generic_outer_type(property_type)):
            inner_type = get_generic_inner_type(property_type)

            if not(isinstance(value, (list, tuple)) and
                   all(_check_single_property_value(inner_type, item) for item in value)):
                raise_type_error()
        else:
            if not _check_single_property_value(property_type, value):
                raise_type_error()


def _check_single_property_value(property_type, value) -> bool:
    if property_type == float:
        return isinstance(value, (int, float))
    else:
        return isinstance(value, property_type)


def is_primitive_type(checked_type) -> bool:
    """
    Returns true if the given type is one of supported primitive types.
    See definition of union Primitives for more details.
    """

    return checked_type in [int, str, float, bool, bytes]


def is_list(checked_type) -> bool:
    """
    Returns true if the given type is a generic list.
    """

    return checked_type == list


def get_generic_outer_type(generic_type):
    """
    Returns outer type of the generic type, if the type is not generic, returns None.
    """

    return get_origin(generic_type)


def get_generic_inner_type(generic_type):
    """
    Returns the first inner type of the generic type, if the type is not generic or there isn't exactly one inner type,
    returns None.
    """

    args = get_args(generic_type)

    if len(args) == 1:
        return args[0]


def encode_value(value) -> str:
    """
    Encode a primitive value to xml string.
    """

    if isinstance(value, bool):
        encoded_value = str(value).lower()
    elif isinstance(value, bytes):
        encoded_value = bytes.hex(value)
    elif isinstance(value, float):
        encoded_value = f"{value:.9g}"
    else:
        encoded_value = str(value)

    return encoded_value


def decode_value(value: str, value_type):
    """
    Decode a primitive value from xml string.
    """

    if value_type == bool:
        return value == "true"
    elif value_type == bytes:
        return bytes.fromhex(value)
    else:
        return value_type(value)


def get_index_of_element_tag(parent, element_tag: str) -> Optional[int]:
    """
    Returns index of the first child element with a given tag.
    If there is no child elements, returns None.
    """

    index = 0

    for child in parent:
        if child.tag == element_tag:
            return index
        index += 1

    return None


def get_line_number(file_name: str) -> int:
    """
    Returns line number from the trace stack.
    Ignores given file name and a file name of this function.
    Returns 0 as a fallback.
    """

    file_names = [file_name, __file__]
    stack = traceback.extract_stack()
    stack.reverse()

    for stack_line in stack:
        if stack_line.filename not in file_names:
            return stack_line.lineno

    return 0


def strip_element(element):
    """
    Strips element and all its children (removes leading and trailing whitespace characters from text and tail).
    """

    for child in element.iter("*"):
        if child.text is not None:
            child.text = child.text.strip()

        if child.tail is not None:
            child.tail = child.tail.strip()
