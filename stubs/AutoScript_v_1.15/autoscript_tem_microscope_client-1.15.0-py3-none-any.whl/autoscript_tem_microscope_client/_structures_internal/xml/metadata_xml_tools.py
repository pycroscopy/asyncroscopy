import inspect
from typing import NamedTuple, Any, Callable, List, Union
from lxml import etree

from ._metadata_xml_internals import *


class XmlProperty(property):
    def __init__(self, fget, fset, property_type, xml_name: str, line_number: int, is_element: bool = True):
        super().__init__(fget, fset)

        self.property_type = property_type
        self.xml_name = xml_name
        self.line_number = line_number
        self.is_element = is_element


class XmlError(Exception):
    def __init__(self, message):
        super().__init__(message)


class XmlStructure:
    """
    Parent class for all xml serializable/deserializable structures.
    All xml properties are serialized and deserialized automatically.
    Xml ordering is based on property definition line number.
    Other properties have to be serialized/deserialized explicitly
    by overriding serialize and deserialize methods.
    """

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        """
        Returns root xml element name for this structure.
        If the name is None, the structure doesn't have root xml element (structure contents are inserted
        directly to parent).
        """

        return None

    def serialize(self, parent):
        """
        Serializes the structure and appends it into the given parent element.
        """

        serialize(parent, self.get_xml_element_name(), self)

    @classmethod
    def deserialize(cls, element):
        """
        Deserializes the structure from a single xml element.
        """

        instance = cls()
        deserialize(element, cls.get_xml_element_name(), instance)
        return instance


def create_xml_property(property_type, xml_name: str, private_name: Optional[str] = None, is_element: bool = True,
                        auto_convert: bool = False, access_callback: Callable[[Any], None] = None) -> XmlProperty:
    """
    Creates property with additional information for xml serialization/deserialization.
    This property is serialized/deserialized automatically.

    :param property_type: Type of the property.
    :param xml_name: Name of the property in xml. Its also used as an unique property identifier.
        Can be empty: empty value means to insert directly to parent element.
    :param private_name: Private name of the property. Only needed if the xml_name is not unique.
    :param is_element: Whether or not is the property represented by an element, or an attribute.
    :param auto_convert: Whether or not is the property type auto converted from a collection.
    :param access_callback: Callback that is going to be called when the property is accessed in any way.
    """

    line_number = get_line_number(__file__)
    type_is_list = is_list(get_generic_outer_type(property_type))
    list_inner_type = None

    if type_is_list:
        _check_list_type(property_type)
        list_inner_type = get_generic_inner_type(property_type)
        set_property_type_hint = property_type if not auto_convert else List[Union[list_inner_type, tuple, list]]
    else:
        _check_type(property_type)
        set_property_type_hint = property_type if not auto_convert else Union[property_type, tuple, list]

    if not is_element:
        if _is_xml_structure(property_type):
            raise ValueError("Complex type can't be represented by an attribute.")

        if xml_name == "":
            raise ValueError("Attribute can't have an empty xml_name.")

    if private_name is None:
        private_name = "_" + xml_name

    def property_get(self):
        if access_callback is not None:
            access_callback(self)

        if hasattr(self, private_name):
            return getattr(self, private_name)

    def property_set(self, value: set_property_type_hint):
        if auto_convert:
            if type_is_list:
                value = list_inner_type.convert_list_from(value)
            else:
                value = property_type.convert_from(value)

        if access_callback is not None:
            access_callback(self)

        check_property_value(property_type, value)
        setattr(self, private_name, value)

    return XmlProperty(property_get, property_set, property_type, xml_name, line_number, is_element)


def _is_xml_structure(checked_type: type) -> bool:
    return issubclass(checked_type, XmlStructure)


def _check_list_type(list_type):
    """
    Checks if the given list type contains xml structure. If not, TypeError is raised.
    """

    if not(is_list(get_generic_outer_type(list_type))):
        raise TypeError("Only properties of type List are supported.")

    inner_type = get_generic_inner_type(list_type)

    if inner_type is None:
        raise TypeError("Only lists with one generic argument are supported.")

    if not _is_xml_structure(inner_type):
        raise TypeError("The inner generic type isn't a valid xml type.")

    if getattr(inner_type, "get_xml_element_name")() is None:
        raise ValueError(f"Xml element name is not provided for type '{inner_type}'. "
                         f"It must be provided if type is used in a list.")


def _check_type(checked_type):
    """
    Checks if the given type is a primitive type or a xml structure. If not, TypeError is raised.
    """

    if not(is_primitive_type(checked_type) or _is_xml_structure(checked_type)):
        raise TypeError(f"Type {checked_type} is not supported.")


def _add_primitive_value_to_element(element, value, xml_property: XmlProperty):
    """
    Adds value of primitive type to the given element.
    See Primitives union for more information about primitive types.
    """

    encoded_value = encode_value(value)

    if xml_property.is_element:
        if xml_property.xml_name != "":
            etree.SubElement(element, xml_property.xml_name).text = encoded_value
        else:
            element.text = encoded_value
    else:
        element.set(xml_property.xml_name, encoded_value)


def _add_single_value_to_element(element, value, xml_property: XmlProperty):
    """
    Adds a single value to the given element (as an element or an attribute).
    For lists use add_values_to_element.
    """

    _check_type(xml_property.property_type)

    if _is_xml_structure(xml_property.property_type):
        if xml_property.xml_name != "":
            sub_element = etree.SubElement(element, xml_property.xml_name)
        else:
            sub_element = element

        value.serialize(sub_element)
    else:
        _add_primitive_value_to_element(element, value, xml_property)


def _add_values_to_element(element, values, xml_property: XmlProperty):
    """
    Adds list value to the given element.
    For single values use add_value_to_element.
    """

    _check_list_type(xml_property.property_type)

    if xml_property.xml_name != "":
        list_element = element.find(xml_property.xml_name)
        if list_element is None:
            list_element = etree.SubElement(element, xml_property.xml_name)
    else:
        list_element = element

    for value in values:
        if value is not None:
            value.serialize(list_element)


def _add_value_to_element(element, value, xml_property: XmlProperty):
    """
    Adds any value to the given element (handles all supported types).
    """

    if value is not None:
        if is_list(get_generic_outer_type(xml_property.property_type)):
            _add_values_to_element(element, value, xml_property)
        else:
            _add_single_value_to_element(element, value, xml_property)


def _get_primitive_value_from_element(element, xml_property: XmlProperty):
    """
    Returns value of primitive type from the given element.
    See Primitives union for more information about primitive types.
    """

    if xml_property.is_element:
        if xml_property.xml_name != "":
            primitive_element = element.find(xml_property.xml_name)
        else:
            primitive_element = element

        if primitive_element is not None:
            value = primitive_element.text
        else:
            value = None
    else:
        value = element.get(xml_property.xml_name)

    if value is None:
        return None
    else:
        return decode_value(value, xml_property.property_type)


def _get_single_value_from_element(element, xml_property: XmlProperty):
    """
    Returns a single element or attribute value from the given element.
    For lists use get_values_from_element.
    """

    _check_type(xml_property.property_type)

    if _is_xml_structure(xml_property.property_type):
        if xml_property.xml_name != "":
            found_element = element.find(xml_property.xml_name)
        else:
            found_element = element

        if found_element is None:
            return None
        else:
            return xml_property.property_type.deserialize(found_element)
    else:
        return _get_primitive_value_from_element(element, xml_property)


def _get_values_from_element(element, xml_property: XmlProperty):
    """
    Returns list value from the given element.
    For single values use get_value_from_element.
    """

    _check_list_type(xml_property.property_type)

    if xml_property.xml_name != "":
        found_element = element.find(xml_property.xml_name)
    else:
        found_element = element

    if found_element is None:
        return None
    else:
        inner_type = get_generic_inner_type(xml_property.property_type)
        xml_element_name = inner_type.get_xml_element_name()

        return [inner_type.deserialize(child_element) for child_element in found_element.findall(xml_element_name)]


def _get_value_from_element(element, xml_property: XmlProperty):
    """
    Returns any element or attribute value from the given element (handles all supported types).
    """

    if is_list(get_generic_outer_type(xml_property.property_type)):
        return _get_values_from_element(element, xml_property)
    else:
        return _get_single_value_from_element(element, xml_property)


class _XmlPropertyIdentifier(NamedTuple):
    name: str
    instance: XmlProperty


def _get_xml_property_identifiers(structure_type: type):
    """
    Returns list of all xml properties on the given xml type and sorts them by line number.
    """

    members = inspect.getmembers(structure_type, lambda m: isinstance(m, XmlProperty))
    xml_property_identifiers = [_XmlPropertyIdentifier(name, value) for (name, value) in members]
    xml_property_identifiers.sort(key=lambda p: p.instance.line_number)
    return xml_property_identifiers


def serialize(parent, xml_element_name: Optional[str], instance):
    """
    Serializes the instance and appends it into the given parent element.
    Creates root element only if xml_element_name is provided.
    """

    instance_type = type(instance)

    try:
        if xml_element_name is not None:
            root = etree.SubElement(parent, xml_element_name)
        else:
            root = parent

        for xml_property_identifier in _get_xml_property_identifiers(instance_type):
            property_value = getattr(instance, xml_property_identifier.name)
            _add_value_to_element(root, property_value, xml_property_identifier.instance)
    except Exception as ex:
        raise XmlError(f"There was an error in serialization of {instance_type.__name__}.") from ex


def deserialize(element, xml_element_name: Optional[str], instance):
    """
    Deserializes the instance from a single xml element.
    Checks if element name matches if the xml_element_name is provided.
    """

    instance_type = type(instance)

    try:
        if xml_element_name is not None and element.tag != xml_element_name:
            raise ValueError(f"Element name does not match! Given element: {element.tag}, "
                             f"expected element: {xml_element_name}")

        for xml_property_identifier in _get_xml_property_identifiers(instance_type):
            value = _get_value_from_element(element, xml_property_identifier.instance)
            setattr(instance, xml_property_identifier.name, value)
    except Exception as ex:
        raise XmlError(f"There was an error in deserialization of {instance_type.__name__}.") from ex
