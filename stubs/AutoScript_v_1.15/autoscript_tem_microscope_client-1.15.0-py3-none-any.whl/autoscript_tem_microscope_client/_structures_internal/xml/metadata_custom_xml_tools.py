import inspect
from typing import NamedTuple, Callable, List, Union
from lxml import etree

from . import metadata_xml_tools as xml_tools
from ._metadata_xml_internals import *


class CustomXmlProperty(property):
    def __init__(self, fget, fset, xml_name: str, line_number: int):
        super().__init__(fget, fset)

        self.xml_name = xml_name
        self.line_number = line_number


def create_custom_xml_property(property_type, xml_name: str, private_name: Optional[str] = None,
                               auto_convert: bool = False,
                               access_callback: Callable[[xml_tools.XmlStructure], None] = None) -> CustomXmlProperty:
    """
    Creates property with additional information for xml serialization/deserialization.
    This property is NOT serialized/deserialized automatically.

    :param property_type: Type of the property.
    :param xml_name: Name of the property in xml. Its also used as an unique property identifier.
    :param private_name: Private name of the property. Only needed if the xml_name is not unique.
    :param auto_convert: Whether or not is the property type auto converted from a collection.
    :param access_callback: Callback that is going to be called when the property is accessed in any way.
    """

    line_number = get_line_number(__file__)
    type_is_list = is_list(get_generic_outer_type(property_type))
    list_inner_type = None

    if type_is_list:
        list_inner_type = get_generic_inner_type(property_type)
        set_property_type_hint = property_type if not auto_convert else List[Union[list_inner_type, tuple, list]]
    else:
        set_property_type_hint = property_type if not auto_convert else Union[property_type, tuple, list]

    if private_name is None:
        private_name = "_" + xml_name

    def property_get(self):
        if access_callback is not None:
            access_callback(self)

        if hasattr(self, private_name):
            return getattr(self, private_name)

    def property_set(self, value: set_property_type_hint):
        if auto_convert:
            if type_is_list:
                value = list_inner_type.convert_list_from(value)
            else:
                value = property_type.convert_from(value)

        if access_callback is not None:
            access_callback(self)

        check_property_value(property_type, value)
        setattr(self, private_name, value)

    return CustomXmlProperty(property_get, property_set, xml_name, line_number)


class OrderingInfo(NamedTuple):
    structure_type: type
    custom_xml_property_name: str


def _get_xml_names(structure_type: type) -> 'List[str]':
    """
    Returns xml names of all xml and custom xml properties and sorts them by line number.
    """

    members = inspect.getmembers(structure_type, lambda m: isinstance(m, xml_tools.XmlProperty) or
                                 isinstance(m, CustomXmlProperty))
    members.sort(key=lambda p: p[1].line_number)
    return [value.xml_name for (_, value) in members]


def _get_element_index(parent, ordering_info: OrderingInfo) -> int:
    """
    Returns the correct index for the element defined by custom_xml_property.
    The default is 0.
    """

    custom_xml_property = getattr(ordering_info.structure_type, ordering_info.custom_xml_property_name)
    xml_names = _get_xml_names(ordering_info.structure_type)
    name_index = xml_names.index(custom_xml_property.xml_name)
    element_index = None

    if name_index != 0:
        xml_names_trimmed = xml_names[:name_index]
        xml_names_trimmed.reverse()

        for xml_name in xml_names_trimmed:
            element_index = get_index_of_element_tag(parent, xml_name)

            if element_index is not None:
                element_index += 1
                break

    if element_index is None:
        return 0

    return element_index


def insert_element(parent, element_name: str, ordering_info: Optional[OrderingInfo] = None):
    """
    Creates sub element with a given name to the parent. If the ordering info is not none, the function uses
    its information to get element order.
    Returns the inserted element.
    """

    element = etree.Element(element_name)

    if ordering_info is not None:
        element_index = _get_element_index(parent, ordering_info)
        parent.insert(element_index, element)
    else:
        parent.append(element)

    return element


def insert_value_to_element(parent, element_name: Optional[str], value, ordering_info: Optional[OrderingInfo] = None):
    """
    Creates sub element with a primitive value inside. If the element_name is None, inserts the value directly to
    parent. If the value is None, the element is not created.
    If the ordering info is not none, the function uses its information to get element order.
    Returns element in which the value was added.
    """

    if value is not None:
        encoded_value = encode_value(value)

        if element_name is None:
            element = parent
        else:
            element = etree.Element(element_name)

            if ordering_info is not None:
                element_index = _get_element_index(parent, ordering_info)
                parent.insert(element_index, element)
            else:
                parent.append(element)

        element.text = encoded_value
        return element


def insert_attribute_to_element(element, attribute_name: str, value):
    """
    Adds attribute with the given name to the element and assigns the value.
    If the value is None, the attribute is not created.
    """

    if value is not None:
        encoded_value = encode_value(value)
        element.set(attribute_name, encoded_value)


def get_value_from_element(element, path: str, value_type):
    """
    Returns a primitive value from the given element. If the path is not found, returns None.
    """

    found_element = element.find(path)

    if found_element is None:
        return None
    else:
        return decode_value(found_element.text, value_type)


def get_attribute_from_element(element, attribute_name: str, value_type):
    """
    Returns an attribute value from the given element. If the attribute is not found, returns None.
    """

    value = element.get(attribute_name)

    if value is None:
        return None
    else:
        return decode_value(value, value_type)
