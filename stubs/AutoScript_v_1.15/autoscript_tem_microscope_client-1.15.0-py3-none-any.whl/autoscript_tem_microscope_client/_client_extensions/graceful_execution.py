import os
import tempfile
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..tem_microscope.service.autoscript._client import Client


def is_stop_requested(_: 'Client') -> 'bool':
    return os.path.exists(_get_signal_file_path("StopRequest"))


def check_stop_requested(client: 'Client'):
    if client.is_stop_requested:
        _remove_signal_file("StopRequest")
        raise KeyboardInterrupt("The script execution was stopped.")


def is_pause_requested(_: 'Client') -> 'bool':
    return os.path.exists(_get_signal_file_path("PauseRequest"))


def check_pause_requested(client: 'Client'):
    if client.is_pause_requested:

        # Accept pause
        _remove_signal_file("PauseRequest")
        _create_signal_file("PauseAccepted", "Pause")

        # Sleep until resume is requested
        while not os.path.exists(_get_signal_file_path("ResumeRequest")):
            time.sleep(0.1)

        # Accept resume
        _remove_signal_file("ResumeRequest")
        _create_signal_file("ResumeAccepted", "Resume")

        # Delete signal files
        _remove_signal_file("PauseAccepted")
        _remove_signal_file("ResumeAccepted")


def _get_signal_file_path(prefix: str) -> 'str':
    return os.path.join(tempfile.gettempdir(), "AutoScript", prefix + "_" + str(os.getpid()) + ".txt")


def _remove_signal_file(prefix: str):
    try:
        path = _get_signal_file_path(prefix)
        if os.path.exists(path):
            os.remove(path)
    except OSError as error:
        print(f"Warning: Part of the \"{prefix}\" operation failed.\n"
              "Pause/resume or stop requests may behave inconsistently.\n" +
              os.linesep +
              "Details:\n" + str(error))


def _create_signal_file(prefix: str, operation: str):
    try:
        open(_get_signal_file_path(prefix), "w").close()
    except IOError as error:
        print(f"Warning: The \"{operation}\" operation failed and will not work as expected.\n" +
              os.linesep +
              "Details:\n" + str(error))
