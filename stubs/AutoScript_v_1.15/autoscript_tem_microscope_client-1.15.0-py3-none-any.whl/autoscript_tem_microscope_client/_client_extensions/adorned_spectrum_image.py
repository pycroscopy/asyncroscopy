from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..dynamic_objects import AdornedSpectrumImage


def save_spectrum_image(spectrum_image: 'AdornedSpectrumImage', path):
    extension = _get_extension_from_path(path)

    if not extension:
        path += _DEFAULT_SAVE_EXTENSION
    elif extension not in _SUPPORTED_SAVE_EXTENSIONS:
        raise ValueError(f"Spectrum image format '{extension}' is not supported.")

    part_count = spectrum_image._get_number_of_file_parts()

    # Transfer the file from the server to the client in parts
    with open(path, mode='wb') as file:
        for part_index in range(0, part_count):
            eds_file_part = spectrum_image._get_file_part(part_index)
            file.write(eds_file_part)


_SUPPORTED_SAVE_EXTENSIONS = [".emd"]
_DEFAULT_SAVE_EXTENSION = _SUPPORTED_SAVE_EXTENSIONS[0]


def _get_extension_from_path(path: str) -> str:
    return Path(path).suffix.lower()
