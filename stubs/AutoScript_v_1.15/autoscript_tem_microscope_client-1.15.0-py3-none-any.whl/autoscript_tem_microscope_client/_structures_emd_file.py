import os
from typing import List, Optional

from ._structures_adorned_image import AdornedImage
from ._structures_metadata import AdornedImageMetadata
from ._structures_internal.emd.emd_reader import EmdReader
from ._structures_internal.emd.emd_converter import convert_emd_file


class EmdStemFeature:
    def __init__(self, images: List[AdornedImage]) -> None:
        self.__set_images(images)

    @property
    def images(self) -> List[AdornedImage]:
        return self.__images

    @images.setter
    def images(self, images: List[AdornedImage]):
        self.__set_images(images)

    @property
    def detector_name(self):
        return self.__detector_name

    def __set_images(self, images: List[AdornedImage]):
        if not images:
            raise ValueError("Images list cannot be empty.")

        self.__images = images
        self.__detector_name = self.__get_detector_name(self.__images[0])
        self.__validate_detector_name()

    @staticmethod
    def __get_detector_name(image: AdornedImage):

        if image.metadata is None:
            raise ValueError("Image metadata is missing.")

        if not image.metadata.scanning_detectors:
            raise ValueError("Image metadata is missing scanning detectors.")

        scanning_detector = image.metadata.scanning_detectors[0]

        return scanning_detector.detector_name

    def __validate_detector_name(self):
        for image in self.__images:
            if image.metadata is None:
                raise ValueError("Image metadata is missing.")

            if not image.metadata.scanning_detectors:
                raise ValueError("Image metadata is missing scanning detectors.")

            scanning_detector = image.metadata.scanning_detectors[0]

            if scanning_detector.detector_name != self.__detector_name:
                raise ValueError("All images must have the same detector name.")


class EmdFile:
    def __init__(self, path: str, read_only: Optional[bool] = None, create_new: bool = False,):
        self.__emd = EmdReader()
        self.__path = path

        if read_only is None:
            read_only = False

        try:
            if create_new:
                self.__emd.create(path)
            else:
                self.__emd.open(path, read_only)
        except Exception as ex:
            exception_message = str(ex)

            if exception_message.startswith("Invalid detector format"):
                raise Exception("File is not supported, it uses invalid detector formatting.") from None
            elif exception_message == "Error loading experiment file.":
                raise Exception("File is not supported.") from None
            else:
                raise

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    @staticmethod
    def open(path: str, read_only: Optional[bool] = None) -> 'EmdFile':
        """
        Opens an emd experiment file.
        :param path: Path to the emd file.
        :param read_only: Indicates whether the file should be opened in read-only mode.
        :return: Opened emd file.
        """
        if read_only is None:
            read_only = False

        return EmdFile(path, read_only=read_only)

    @staticmethod
    def create(path: str, feature: EmdStemFeature) -> 'EmdFile':
        """
        Creates a new emd experiment file.
        :param path: Path to the emd file.
        :param feature: Stem feature to be added to the emd file.
        :return: Created emd file.
        """
        if not feature:
            raise ValueError("Feature has to be present when creating EMD file.")

        file = EmdFile(path, create_new=True)

        # If the feature append fails, the file is closed and removed
        try:
            file.__append_stem_feature(feature)
            return file
        except Exception:
            file.close()
            os.remove(path)
            raise

    @staticmethod
    def convert(input_path: str, output_path: str):
        """
        Converts an emd experiment file to a new format version.
        :param input_path: Path to the emd file.
        :param output_path: Path to the output emd file.
        """
        convert_emd_file(input_path, output_path)

    def read_all_images(self) -> 'List[AdornedImage]':
        """
        Returns all images from the emd file and converts them to AdornedImage.
        """
        result = []

        try:
            for feature in self.__emd.get_features():
                for series in feature.get_image_series():
                    for frame_index in range(series.frame_count):
                        image = EmdFile.__create_adorned_image(series, frame_index)

                        if image is not None:
                            result.append(image)

            return result
        except MemoryError as memory_error:
            raise MemoryError("Interpreter run out of memory while reading the images.") from memory_error

    def __append_stem_feature(self, stem_feature: EmdStemFeature):
        """
        Creates Stem feature in Emd file.
        """
        feature_id = self.__emd.create_stem_feature()
        detector_id = self.__emd.create_stem_detector(feature_id, stem_feature.detector_name)

        for image in stem_feature.images:
            if image.metadata is None:
                raise ValueError("Image metadata is missing.")

            self.__emd.append_frame_to_stem_detector(feature_id, detector_id, image.data, image.width, image.height, image.metadata.metadata_as_xml)

    @staticmethod
    def __create_adorned_image(series, frame_index):
        """
        Tries to create AdornedImage, if it fails, returns None.
        """
        try:
            frame_data = series.get_frame_data(frame_index)
            frame_metadata = series.get_frame_metadata(frame_index)

            return AdornedImage(frame_data, AdornedImageMetadata.create_from_xml(frame_metadata))
        except ValueError:
            pass

    def close(self):
        """
        Closes the emd file and releases all resources.
        """
        self.__emd.close()
