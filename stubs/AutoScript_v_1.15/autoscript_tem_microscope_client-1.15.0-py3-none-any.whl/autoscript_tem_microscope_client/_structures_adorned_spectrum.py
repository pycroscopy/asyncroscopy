import copy
import numpy

from autoscript_core.common import InvalidOperationException
from . import _structures_shell as shell
from ._structures_metadata import AdornedImageMetadata
from .enumerations import SpectrumEncoding


class AdornedSpectrum(shell.AdornedSpectrum):
    __slots__ = []

    def __init__(self, data: numpy.ndarray = None, metadata: 'AdornedImageMetadata' = None):
        """
        Constructs a new AdornedSpectrum.

        :param data: Data to construct the new AdornedSpectrum from, in a form of numpy.ndarray.
        :param metadata: Metadata to assign to this instance of AdornedSpectrum.
        """

        # Constructs the new AdornedSpectrum from the given data where applicable.
        # This approach is intended for spectra created directly by user. Spectra
        # coming from the AutoScript Server get their members filled in directly
        # during deserialization.

        if metadata is not None:
            metadata = copy.deepcopy(metadata)

        if data is not None:
            if not isinstance(data, numpy.ndarray):
                raise ValueError("Cannot construct AdornedSpectrum because the given data "
                                 "are not of numpy.ndarray type.")

            try:
                encoding = self.__get_encoding(data)
                raw_data = self.__convert_to_raw_data(data)

                super().__init__(raw_data, encoding, metadata)
            except Exception as ex:
                raise ValueError("Cannot construct AdornedSpectrum because the given data "
                                 "are not in a compatible format.", ex)
        else:
            super().__init__(metadata=metadata)

    @staticmethod
    def __convert_to_raw_data(data: numpy.ndarray) -> bytes:
        if data.ndim != 1:
            raise ValueError("Data must have one dimension.")

        return memoryview(data).tobytes()

    @staticmethod
    def __get_encoding(data: numpy.ndarray):
        if data.dtype == numpy.uint8:
            return SpectrumEncoding.U_INT_8
        elif data.dtype == numpy.uint16:
            return SpectrumEncoding.U_INT_16
        elif data.dtype == numpy.uint32:
            return SpectrumEncoding.U_INT_32
        else:
            raise ValueError(f"Unsupported data type '{data.dtype}'. "
                             "Only encodings uint8, uint16, and uint32 are supported.")

    @staticmethod
    def __get_numpy_dtype(encoding: str):
        if encoding == SpectrumEncoding.U_INT_8:
            return numpy.uint8
        elif encoding == SpectrumEncoding.U_INT_16:
            return numpy.uint16
        elif encoding == SpectrumEncoding.U_INT_32:
            return numpy.uint32
        else:
            raise ValueError(f"Unsupported encoding '{encoding}'.")

    def __ensure_not_empty(self):
        if self._raw_data is None:
            raise InvalidOperationException("Adorned spectrum object was not initialized with spectrum data.")

    @property
    def data(self) -> numpy.ndarray:
        """
        Provides access to data in a form of numpy.ndarray.

        :return: Image data in a form of numpy.ndarray.
        """

        self.__ensure_not_empty()
        return numpy.frombuffer(self._raw_data, dtype=self.__get_numpy_dtype(self.encoding))
