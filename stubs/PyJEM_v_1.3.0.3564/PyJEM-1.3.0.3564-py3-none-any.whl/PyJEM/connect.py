# -*- coding: utf-8 -*-
"""
Created on Thu May 18 16:03:10 2023

@author: dmaekawa
"""

import os
import json
import httplib2

from . import filesystem


PYJEM_URI_FILE = "{}/uri.json".format(os.path.dirname(__file__))


class ConnectFormat:
    """
    uri.jsonの1要素の定義
    """
    def __init__(self,name,ip,port):
        self.name=name
        self.ip=ip
        self.port=port
        
    @property
    def url(self):
        scheme = "http"
        return "{}://{}:{}".format(scheme,self.ip,self.port)
   
    def get_url(self, addurl=""):
        "テンプレートとなるURLの作成"
        _ = self.url
        if addurl!="":
            _ = _+addurl
        return _        
    

class ConnectFileManager(filesystem.FileManager):
    """
    uri.jsonをR/Wするクラス
    """
    _cls = None
    def __init__(self):
        super().__init__(PYJEM_URI_FILE)
        self._filedata = super().read()
        if not super().isexist:
            self._filedata = list()
            super().write(self._filedata)
        
    def __new__(cls):
        if cls._cls==None:
            cls._cls = super().__new__(cls,PYJEM_URI_FILE)
        return cls._cls
        
    def update(self,obj:ConnectFormat):
        items = obj.__dict__
        names = [data["name"] for data in self.filedata]
        if items["name"] in names:
            i = names.index(items["name"])
            self._filedata[i] = items
        else:
            self._filedata.append(obj.__dict__)
        super().write(self.filedata)
        
    def get_instance(self,name):
        data = [_ for _ in self.filedata if _["name"]==name]
        if len(data)>0:
            name = data[0]["name"]
            ip = data[0]["ip"]
            port = data[0]["port"]
            return ConnectFormat(name, ip, port)
        return None
        
    @property
    def filedata(self):
        return self._filedata
        
    def check_define(self,name):
        result = False
        raw = self.filedata
        if raw==None:
            return result
        check = [_ for _ in raw if _["name"]==name]
        if len(check)>0:
            result=True
        return result
    

class Connect: #(ConnectFileManager):
    
    # _cls_connect = dict()
    def __init__(self,name):
        self.filemanager = ConnectFileManager()
        # super().__init__()
        self.name = name
            
        # if self.check():
        self._urlformat=self.filemanager.get_instance(name)
        self.connector = Connector()
        
    # def __new__(cls,name):
    #     if name not in cls._cls_connect:
    #         cls._cls_connect[name] = super().__new__(cls)
    #         print(cls._cls_connect)
    #     return cls._cls_connect[name]
    
    def initialize(self,ip,port):
        "uri.jsonに定義が無い場合の処理"
        if not self.check():
            self.setup(ip,port)
    
    def setup(self,ip="",port=""):
        if ip=="":
            ip = self.urlformat.ip
        if port=="":
            port=self.urlformat.port
        self._urlformat = ConnectFormat(self.name, ip, port)
        self.filemanager.update(self.urlformat)
       
    def check(self):
        return self.filemanager.check_define(self.name)
    
    def get(self,addurl=""):
        "Method=GET"
        # if self.check():
        url = self.urlformat.get_url(addurl)
        return self.connector.request(url,"GET")
        
    def post(self,addurl="",body=dict()):
        # if self.check():
        url = self.urlformat.get_url(addurl)
        return self.connector.request(url,"POST",body)

    def put(self,addurl="",body=dict()):
        # if self.check():
        url = self.urlformat.get_url(addurl)
        return self.connector.request(url,"PUT",body)

    @property
    def urlformat(self):
        return self._urlformat
        

class Connector():
    """
    REST通信を行うベースとなるクラス
    - Errorはファイルに出力
    """
    _cls = None
    def __init__(self):
        self.client = httplib2.Http()
        self.header = {'connection':'close'}

    def __new__(cls):
        if cls._cls==None:
            cls._cls = super().__new__(cls)
        return cls._cls
    
    def request(self,url,method,body=None):
        url = self.url_parse(url)
        if method=="GET":
            res,cont = self.client.request(url,method)
        elif method=="POST" or method=="PUT":
            if body!=None:
                body = json.dumps(body)
            res,cont = self.client.request(url,method,body, headers=self.header)
        else:
            res,cont = self.client.request(url,method,body, headers=self.header)
        
        # REST通信の結果のチェック
        HTTPStatus.check(res)
        
        return self.get_content(res,cont)
    
    
    ### sub ###    
    
    def url_parse(self, url):
        "スペースがある場合などの成形"
        return httplib2.urllib.parse.quote(url, safe=":/")
                
    def get_content(self,res,cont):
        "RESTで取得したContentのチェックと成形を行う"
        ctype = res.get('content-type')
        if "application" in ctype:
            encode= "utf-8"
            if "charset=" in ctype:
                encode = ctype.rsplit("charset=")[1]
            if "json" in ctype:
                _ = json.loads(cont.decode(encode))
            if "octet-stream" in ctype:
                _ = cont
        elif "image" in ctype:
            _ = cont
            # # bmpは"x-bmp"となって出てくる
            # ext = ctype.rsplit("/")[1]
            # # 以下で画像保存
        elif "text/plain" in ctype:
            _ = cont
        else:
            _ = json.loads(cont.decode("utf-8"))
        
        return _
    
            
    
    
    

class HTTPStatus:
    """
    https://developer.mozilla.org/ja/docs/Web/HTTP/Status
    REST通信の通信結果を出力
    
    """
    _instance = None
    def __new__(cls):
        if cls._instance == None:
            code = {}
            code.update(cls.set_httpstatus_format(200,"OK"))
            code.update(cls.set_httpstatus_format(201,"Created"))
            code.update(cls.set_httpstatus_format(300,"Multiple Choice"))
            code.update(cls.set_httpstatus_format(400,"Bad Request"))
            code.update(cls.set_httpstatus_format(401,"Unauthorized"))
            code.update(cls.set_httpstatus_format(402,"Payment Required"))
            code.update(cls.set_httpstatus_format(403,"Forbidden"))
            code.update(cls.set_httpstatus_format(404,"Not Found"))
            code.update(cls.set_httpstatus_format(405,"Method Not Allowed"))
            code.update(cls.set_httpstatus_format(500,"Internal Server Error"))
            
            cls._instance = code
        return cls._instance
    
    def set_httpstatus_format(code,text,link=None):
        if link==None:
            link = "https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/{}".format(code)    
        return {
            code:{
                "text":text,
                "link":link
            }}
    
    @classmethod
    def check(cls,response):
        _ = HTTPStatus()
        
        if not type(response) == httplib2.Response:                
            raise 

        if 200 <= response.status and response.status <300:
            return _[response.status]
        else:
            raise Exception("Http status error has occured. Http status= {}, message= {}, link= {}".format(response.status, _[response.status]["text"], _[response.status]["link"]))

