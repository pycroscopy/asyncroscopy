# -*- coding: utf-8 -*-
"""
Created on Wed Dec  8 19:28:38 2021

@author: jeol
"""

class BaseClass:
    def __init__(self, *args, **kw):
        if args != ():
            self._param = args[0]
        elif kw != {}:
            self._param = kw
        else:
            self._param = {}               
    
    
    def __new__(cls, *args, **kw):
        if args != ():
            para = args[0]
        elif kw != {}:
            para = kw
        else:
            para = {}
        return para               
        
    
    def setter(self, data):
        self.param = {k:w for k,w in data.items() if k in self.key}

def get_enum_list(object):
    return [e.value for e in object]





