# -*- coding: utf-8 -*-
"""
PyJEM is a Python package that provides control TEM, capture live image, and so on.
  
How to use the offline package
-----------------------------------

Example:
    In case of the offline TEM3 package.

    >>> from PyJEM.offline import TEM3
    >>> TEM3.connect()
    True

Hot to connect the remote
-----------------------------------
    
Example:
    In case of the detector package.
    
    >>> from PyJEM import detector
    >>> detector.set_ip("***")
    

"""
import os

from .config import get_config, set_record_path
from .connect import ConnectFileManager, ConnectFormat


def __read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()


__version__ = __read("VERSION")
__all__ = ["detector", 
           "detectorext", 
           "femtus_eds", 
           "sightx"]


def get_record_path():
    """
    You can get the root path where the image will be saved.
    * The relevant ones are detector, sightx, and camera .
    """
    return get_config("record_path")

def set_record_path(path):
    """
    You can change the root path to save the image.
    * The relevant ones are detector, sightx, and camera .
    """
    return set_record_path(path)

def custom_ip(ip, name=None):
    """
    This functionchange ip address all package or select package.
    
    Example:
        - Change the all package ip address.
        >>> PyJEM.custom_ip("127.0.0.1")
        
        - Change the select package ip address.
        >>> PyJEM.custom_ip("127.0.0.1", "detector")
    """    
    if name==None:
        names = __all__
    else:
        if name in __all__:
            names = [name]
        else:
            return
        
    fm = ConnectFileManager()
    for name in names:
        print(name)
        table = fm.get_instance(name)
        port = table.port
    
        fm.update(
            ConnectFormat(name,ip,port)
            )
        
        
        
        
    
