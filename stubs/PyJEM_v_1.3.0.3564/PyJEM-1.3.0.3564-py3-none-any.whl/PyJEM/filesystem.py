# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 11:00:59 2022

@author: d.m
"""
import os
import json
import ast
import csv


class FileManager:
    _ins = {}
    def __init__(self, fobj):   
        self.abs = self.conv_sep(fobj)
        self.basename = os.path.basename(self.abs)
        self.filename, self.ext = os.path.splitext(self.basename)
        self.parent = self.conv_sep(os.path.abspath(os.path.join(self.abs, os.pardir)))
        self._isexist = os.path.exists(self.abs)
        self.isdir = os.path.isdir(self.abs)
        self.isfile = os.path.isfile(self.abs)
        if self.ext != "":
            self.dirname = self.parent
        else:
            self.dirname = self.abs
        self.make_dir()
        
    def __new__(cls, file):
        if cls._ins == None:
            cls._ins = {}
        if cls._ins == {}  or file not in cls._ins:
            cls._ins[file] = super().__new__(cls)
        
        return cls._ins[file]        
    def conv_sep(self, path):
        return path.replace(os.sep, "/")
    
    def make_dir(self):
        if not os.path.exists(self.dirname):
            os.makedirs(self.dirname)                
           
    def read(self):
        if not self.isdir and self.isexist :
            if self.ext == ".json":
                _io = FileIO(self.abs)
                return _io.json_read()
            elif self.ext == ".csv":
                _io = FileIO(self.abs)
                return _io.csv_read()

        
    def write(self, data, kind="w"):
        if not self.isdir:
            if self.ext == ".json":
                _io = FileIO(self.abs)
                if kind == "w":
                    self._isexist=True
                    return _io.json_write(data)
                elif kind == "a":
                    self._isexist=True
                    return _io.json_overwrite(data)
            elif self.ext == ".csv":
                _io = FileIO(self.abs)
                self._isexist=True
                return _io.csv_write(data)
            elif self.ext == ".bin":
                _io = FileIO(self.abs)
                self._isexist=True
                return _io.bin_write(data)
    
    @property
    def isexist(self):
        return self._isexist
        
        
            
class FileIO:
    __instance = []
    def __init__(self, file):
        self.file = file
    
    # def __new__(cls, file):
    #     if not len(cls.__instance) == 0 and file not in cls.__instance:
            
    def json_read(self):
        with open(self.file, "r+", encoding=self.encode_rule) as f:
            string = f.read()
            string = string.replace('null', 'None').replace('true', 'True').replace('false', 'False').replace("NaN", "None")
            # data = json.loads(json.dumps(eval(string)))
            data = json.loads(json.dumps(ast.literal_eval(string)))

        return data
        
    def json_write(self,data):    
        with open(self.file, "w+", encoding=self.encode_rule) as f:
            f.seek(0)
            f.write(json.dumps(data, 
                               ensure_ascii=False, 
                               indent=2, 
                               sort_keys=False, 
                               separators=(",",": ")))
            f.truncate()

    def json_overwrite(self, data):
        __dict = self.json_read()
        __dict.update(data)
        self.json_write(__dict)
          
    def csv_write(self, data):
        with open(self.file, 'w', newline='', encoding=self.encode_rule) as f:
            writer = csv.writer(f)
            for d in data:
                writer.writerow(d)
            
    def csv_read(self):
        with open(self.file, "r", encoding=self.encode_rule, errors='ignore') as f:
            reader = csv.reader(f)
            return [i for i in reader]
        
    def bin_write(self, data):
        with open(self.file, "wb") as f:
            f.write(data)
        
    @property
    def encode_rule(self):
        return "utf_8_sig"




