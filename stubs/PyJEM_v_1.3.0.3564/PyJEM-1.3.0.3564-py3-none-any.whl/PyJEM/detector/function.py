# -*- coding: utf-8 -*-
"""

"""
from ..connect import Connect
from .. import _image

name = "detector"
_connector = Connect(name)
_connector.initialize("localhost", 49226)

uri = "/DetectorRESTService/Detector"


# def initialize():
#     """
#     Initialize the package.
    
#     Note:
#         This method is 
#     """
#     _connector.setup(ip="localhost",port=49226)

def set_ip(val:str)->None:
    """
    This function can modify the IP Address which is URI of this package.
    
    Args:
        val (int): ip address.
    """
    _connector.setup(ip=val)
    
def set_port(val:int)->None:
    """
    This function can modify the port number which is URI of this package.
    
    Args:
        val (int): port numnber.
    
    Warning:
        Please do not use it except for JEOL service.
    """
    _connector.setup(port=val)

def get_config()->dict:
    """
    This function returns the package's settings.
    
    Return:
        dict:
            service info.
    
    Example:
        >>> detector.get_config()
        {'name': '---', 'ip': '---', 'port': ---, 'uri': '---'}
    """
    return _connector.urlformat.__dict__


def get_attached_detector()->list:
    """
    Acquisition of "ADF1"s currently available in TEMCenter.

    Return:
        List of available "ADF1"s. 
    """
    url = uri+"/GetAttachedDetector"
    return _connector.get(url)

def assign_channel(detectorName:str, channel=0)->dict:
    """
    Assign the selected detector to a channel.

    Args:
        detectorName (str): "ADF1"
        channel (int): Channel number to assign the detector. (Only multiple channles)
        
    Return:
        dict: Execution result.
    """
    if not channel:
        channel=1
    url = uri+"/{0}/AssignChannel/{1}" .format(detectorName, channel)

    return _connector.get(url)

def get_assignChannels()->dict:
    '''
    Get activate detectors list.
        
    Return: 
        dict: activate detectors dict.
        
    Example: 
        >>> detector.get_assignChannels()
        {
          "0": “BF”,
          "1": “ADF1”,
          "2": “ADF2”,
          "3": “None”,
        }
    '''   
    url = uri+"/GetAssignChannels"
    return _connector.get(url)

def snapshotall()->dict:
    '''
    Acquire all available detectors.
               
    Return: 
        dict: Execution result
        
    Note:
        this function is only STEM mode.
        
    Note:
        To get the acquired image data by this function, please to use snapshotframe() function. 
    '''
    url=uri+"/SnapShotAll"
    return _connector.post(url)

def start_accumulate_image_cache()->dict:
    """
    Turn on the flag to keep the cached image of the Live image. 
        
    Return: 
        dict: Execution result
        
    Example:
        >>> detector.start_accumulate_image_cache()
        {"status":"OK"}
    """
    url=uri+"/StartCreateRawDataCache"
    return _connector.post(url)

def stop_accumulate_image_cache()->dict:
    """
    Turn off the flag to keep the cached image of the Live image 
        
    Return: 
        dict: Execution result
        
    Example:
        >>> detector.stop_accumulate_image_cache()
        {"status":"OK"}
    """
    url=uri+"/StopCreateRawDataCache"
    return _connector.post(url)


class Detector:
    """
    """
    def __init__(self, det):
        self.detector = det
        self.uri = uri+"/{}".format(det)
        
    def livestart(self)->dict:
        """
        Start live.
            
        Return: 
            dict: Execution result
            
        Example:
            >>> det=detector.Detector("ADF1")
            >>> det.livestart()
            {"status":"OK"}
        """
        url=self.uri+"/LiveStart"
        return _connector.post(url)

    def livestop(self)->dict:
        """
        Stop live.
            
        Return:
            dict: Execution result
        """
        url=self.uri+"/LiveStop"
        return _connector.post(url)
        
    def snapshot(self, ext:str, save=False, filename=None, show=False):
        """
        Acquire image about the args "extension". 
        The image is taken with the selected detector and the acquired image array is output or saved.
            
        Args: 
            extention (str):
                "jpg", "bmp", "tiff"
            save (bool):  
                'True' is save capture file.
            filename (str): 
                Name of file to save. It is possible to include an absolute path.
                Only available when 'save' is True.
            show (bool):
                show the Image file.

        Return: 
            if enter argument is only "extention", return value is image data stream (bytes).
            else return value is saved file name.
            
            File stream saved with the selected extension. (If there is 
            an input in an argument other than 'extention', None is returned.)
            
        """  
        url=self.uri+"/Snapshot/"+ext
        img = _connector.get(url)
        ac = _image.AcquireSetting(img)
        return ac.method(ext, save, filename, show)

    def snapshotframe(self, ext:str, save=False, filename=None, show=False):
        """
        This function is output the acquired image array.
        this function does not acquire the new image, to return the image array acquired with the snapshotall() function.        
        
        Args: 
            extention (str): 
                "jpg", "bmp", "tiff"
            save (bool):
                'True' is save capture file.
            filename (str): 
                Name of file to save. It is possible to include an absolute path.
                Only available when 'save' is True.
            show (bool): 
                show the Image file.
                
        Return: 
            if enter argument is only "extention", return value is image data stream (bytes).
            else return value is saved file name (str).

            File stream saved with the selected extension
        
        Note:
            This function does not acquire new image, to return the image array acquired with the snapshotall() function. 
            
        """
        url=self.uri+"/SnapShotFrame/"+ext
        img = _connector.get(url)
        ac = _image.AcquireSetting(img)
        return ac.method(ext, save, filename, show)

    def livesnapshot(self, ext:str, save=False, filename=None, show=False):
        '''
        Take an image with the specified extension. Obtaining images faster than "snapshot".

        Args: 
            extention (str): 
                "jpg", "bmp", "tiff"
            save (bool):  
                'True' is save capture file.
            filename (str): 
                Name of file to save. It is possible to include an absolute path.
                Only available when 'save' is True.
            show (bool): 
                show the Image file.
                
        Return: 
            bytes or str:
            if enter argument is only "extention", return value is image data stream (bytes).
            else return value is saved file name.

            File stream saved with the selected extension
        '''
        url=self.uri+"/LiveSnapShot/"+ext
        img = _connector.get(url)
        ac = _image.AcquireSetting(img)
        return ac.method(ext, save, filename, show)
        
    def snapshot_rawdata(self)->bytes:
        """
        Raw data of the image acquired by the specified detector. the raw data is returned as a byte array.

        Return:
            dict: 
            2 dimensional byte array of acquired image data.
        """        
        url=self.uri+"/CreateRawData"
        return _connector.get(url)
        
    def get_detectorsetting(self)->dict:
        '''
        Obtaining setting information of selected detector.
        
        Return:
            dict: get the selected detector's info.
            
        Example:
            >>> detector.Detector("ADF1").get_detectorsetting()
            {
            "ExposureTimeValue":100,
            "GainIndex":100, ...
            }
        '''
        url=self.uri+"/Setting"
        return _connector.get(url)
        
    def set_detectorsetting(self, body:dict)->dict:
        '''
        Wild card method.

        Args:
            body (dict): "key" is function name you want to use. "value" is to change value.
         
        Return: 
            dict: The value set to TEM.
            
        Example:
            >>> body = {"ExposureTimeValue":100,"GainIndex":8000,"OffsetIndex":8000}
            >>> detector.Detector("ADF1").set_detectorsetting(body)
        '''
        url=self.uri+"/Setting"
        return _connector.post(url,body)

    def set_frameintegration(self, value:int)->dict:
        '''
        Set the accumulation count.
        
        Args:
            value (int): frame integration value. range is 0-255.

        Return:
            dict: 
            The value set to TEM.
            
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"frameIntegration":value}
        return self.set_detectorsetting(body)

    def set_exposuretime_index(self, value:int)->dict:
        '''
        Set the exposure time as index.
        
        Args:
            value (int): exposure time index. range is 0-65535

        Return:
            dict: 
            The value set to TEM.
        
        Example:
            >>> detector.Detector("ADF1").set_exposuretime_index(100)            
            {"ExposureTimeIndex":100}
            
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"ExposureTimeIndex":value}
        return self.set_detectorsetting(body)

    def set_exposuretime_value(self, value:float)->dict:
        '''
        Set the exposure time as usec value.
        
        Args:
            value (float): 0.0-1000.0(μsec) 
                
        Return:
            The value set to TEM.
            
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"ExposureTimeValue":value}
        return self.set_detectorsetting(body)

    def set_gainindex(self, value:int)->dict:
        '''
        Set the gain value as index.
        
        Args:
            value (int): 
                0- 4095
        Return: 
            dict: 
            The value set to TEM.
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"GainIndex":value}
        return self.set_detectorsetting(body)

    def set_offsetindex(self, value:int)->dict:
        '''
        Set the offset value as index.

        Args:
            value (int): 0- 4095

        Return: 
            dict: 
            The value set to TEM.
            
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"OffsetIndex":value}
        return self.set_detectorsetting(body)

    def set_digitalrotation(self, value:float)->dict:
        '''
        Set the digital rotation angle as absolute value.
        
        Args:
            value (float): 0.0-360.0
            
        Return: 
            dict: The value set to TEM.
        '''
        body = {"DigitalRotation":value}
        return self.set_detectorsetting(body)

    def set_scanrotation(self, value:float)->dict:
        '''
        Set the scanRotation angle as absolute value.
        
        Args:
            value (float): 0.0-360.0
            
        Return: 
            dict: The value set to TEM.
        '''
        body = {"ScanRotation":value}
        return self.set_detectorsetting(body)

    def set_scanrotation_step(self, value:float)->dict:
        '''
        Set the minimum variation of scanRotation.

        Args:
            value (float): 0.0-20.0
            
        Return: 
            dict: The value set to TEM.
        '''
        body = {"scanRotationStep":value}
        return self.set_detectorsetting(body)

    def set_imaging_area(self, Width:int, Height:int, X=None, Y=None)->dict:
        '''
        Set the number of pixels of the live image. 
        x and y are the coordinates of the starting pixel of the read image. 
        width and height are the coordinates of the end pixel of the read image.
        If no value is entered for the argument, the value is not changed.

        Args:
            X (int): 0-4096
            Y (int): 0-4096
            Width (int): 0-4096
            Height (int): 0-4096
            
        Return: 
            dict: 
            The value set to TEM.
        '''
        body = {"ImagingArea":{"X":X, "Y":Y, "Width":Width, "Height":Height}}
        return self.set_detectorsetting(body)

    def set_spotposition(self, X:int, Y:int)->dict:
        '''
        Set the beam position when ScanMode is "Spot".
        Sets which part of the scanning range set by ImagingArea is scanned.
        The top left vertex is (0, 0).
        If no value is entered for the argument, the value is not changed.
        
        Args:
            X (int): 0-4096
            Y (int): 0-4096
        Return: 
            dict: 
            The value set to TEM.
        '''
        body = {"SpotPosition":{"X":X, "Y":Y}}
        return self.set_detectorsetting(body)

    def set_areamode_imagingarea(self, Width:int, Height:int, X=None, Y=None)->dict:
        '''
        Set the beam position when ScanMode is "Area".
        Sets which part of the scanning range set by ImagingArea is scanned.
        The top left vertex is (0, 0).
        If no value is entered for the argument, the value is not changed.
        
        Args:
            X (int): 0-4096
            Y (int): 0-4096
            Width (int): 0-4096
            Height (int): 0-4096
            
        Return: 
            dict: 
            The value set to TEM.
        '''
        body = {"AreaModeImagingArea":{"X":X, "Y":Y, "Width":Width, "Height":Height}}
        return self.set_detectorsetting(body)

    def set_scanmode(self, value:int)->dict:
        '''
        Set the scanMode.
        
        Args:
            value (int): 0= Scan, 1= Area, 3= Spot
                
        Return: 
            dict: 
            The value set to TEM.
        '''
        body = {"scanMode":value}
        return self.set_detectorsetting(body)

    def set_binningindex(self, value:int)->dict:
        '''
        Set the Binning value as index.
        
        Args:
            value (int): 0-4
        
        Return: 
            dict: 
            The value set to TEM.
            
        Note: 
            value(Args)'s range sdepends on TEM model

        Note:
            This function corresponds to camera only.
        '''
        body = {"BinningIndex":value}
        return self.set_detectorsetting(body)
        
    def AutoFocus(self)->dict:
        '''
        Start AutoFocus function.

        Return: 
            dict: Execute status 
        
        Example:
            >>> detector.Detector("ADF1").AutoFocus()
            {"status":...}
        '''
        url=self.uri+"/AutoFocus"
        return _connector.post(url)

    def AutoContrastBrightness(self)->dict:
        '''
        Start AutoContrastBrightness function.
        
        Return: 
            dict: Execute status 
        '''
        url=self.uri+"/AutoContrastBrightness"
        return _connector.post(url)

    def AutoStigmator(self)->dict:
        '''
        Start AutoStigmator function.

        Return: 
            dict: Execute status 
        '''
        url=self.uri+"/AutoStigmator"
        return _connector.post(url)

    def AutoOrientation(self)->dict:
        '''
        Start AutoOrientation function.
        
        Return: 
            dict: Execute status 
        '''
        url=self.uri+"/AutoOrientation"
        return _connector.post(url)

    def AutoZ(self)->dict:
        '''
        Start AutoZ function.

        Return: 
            dict: Execute status 
        '''
        url=self.uri+"/AutoZ"
        return _connector.post(url)


    ## 使用する機種によって動かないものがある
    def get_insert_state(self)->dict:
        '''
        Get detector in/out status. 

        Return: 
            dict: Execute status 
        '''   
        url=self.uri+"/GetInserted"
        return _connector.get(url)
        
    def insert(self)->dict:
        '''
        Insert a select detector.

        Return: 
            dict: Execute status 
        '''   
        url=self.uri+"/Insert"
        return _connector.get(url)

    def retract(self)->dict:
        '''
        retract a select detector.

        Return: 
            dict: Execute status 
        '''   
        url=self.uri+"/Retract"
        return _connector.get(url)

    def get_image_cache(self)->bytes:
        '''
        Returns a cached image of a Live image without using SnapShot. 
        Can only be used if the flag to leave the cache is ON 

        Return: 
            bytes: 
            bytes array.
        '''   
        url=self.uri+"/CreateRawDataCache"
        return _connector.get(url)
        


        
# def run(uri, method, body=None, cast=None):        
    
#     @base.overlap
#     @base.request(name, uri, method)
#     def executer(*args, **body):
#         return args[0]

#     @base.overlap
#     @base.request(name, uri, method, cast)
#     def executer_image(**body):
#         return 
    
#     if cast is None:
#         if not body:
#             return executer()
#         else:
#             return executer(**body)
#     else:
#         if not body:
#             return executer_image()
#         else:
#             return executer_image(**body)



