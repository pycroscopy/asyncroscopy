# -*- coding: utf-8 -*-
"""
This package controls the function of the detector.


"""

# from . import function
from .function import *
# from .. import base

