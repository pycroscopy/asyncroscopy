# -*- coding: utf-8 -*-
"""
"""
from ..connect import Connect
from .. import _image


name = "detectorext"
_connector = Connect(name)
_connector.initialize("localhost", 49326)  

uri = "/DetectorRESTService/Detector"

def set_ip(val:str)->None:
    """
    This function can modify the IP Address which is URI of this package.
    
    Args:
        val (int): ip address.
    """
    _connector.setup(ip=val)
    
def set_port(val:str)->None:
    """
    This function can modify the port number which is URI of this package.
    
    Args:
        val (int): port numnber.
    
    Warning:
        Please do not use it except for JEOL service.
    """
    _connector.setup(port=val)

def get_config()->dict:
    """
    This function returns the package's settings.
    
    Return:
        dict:
            service info.
    
    Example:
        >>> detector.get_config()
        {'name': '---', 'ip': '---', 'port': ---, 'uri': '---'}
    """
    return _connector.urlformat.__dict__


def get_attached_detector()->list:
    """
    Acquisition of detector names currently available in TEMCenter.

    Return:
        List of available detector names. 
    """
    url = uri+"/GetAttachedDetector"
    return _connector.get(url)

def assign_channel(detectorName:str, channel=0)->dict:
    """
    Assign the selected detector to a channel.

    Args:
        detectorName (str): Detector name
        channel (int): Channel number to assign the detector. (Only multiple channles)
        
    Return:
        dict: Execution result.
    """
    if not channel:
        channel=1
    url = uri+"/{0}/AssignChannel/{1}" .format(detectorName, channel)

    return _connector.get(url)

def get_assignChannels()->dict:
    '''
    Get activate detectors list.
        
    Return: 
        dict: activate detectors dict.
        
    Example: 
        >>> detector.get_assignChannels()
        {
          "0": “BF”,
          "1": “ADF1”,
          "2": “ADF2”,
          "3": “None”,
        }
    '''   
    url = uri+"/GetAssignChannels"
    return _connector.get(url)

def snapshotall()->dict:
    '''
    Acquire all available detectors.
               
    Return: 
        dict: Execution result
        
    Note:
        this function is only STEM mode.
        
    Note:
        To get the acquired image data by this function, please to use snapshotframe() function. 
    '''
    url=uri+"/SnapShotAll"
    return _connector.post(url)


class Detector:
    """
    """
    def __init__(self, det):
        self.detector = det
        self.uri = uri+"/{}".format(det)
        
    def livestart(self)->dict:
        """
        Start live.
            
        Return: 
            dict: Execution result
            
        Example:
            >>> det=detector.Detector(detector name)
            >>> det.livestart()
            {"status":"OK"}
        """
        url=self.uri+"/LiveStart"
        return _connector.post(url)

    def livestop(self)->dict:
        """
        Stop live.
            
        Return:
            Execution result
        """
        url=self.uri+"/LiveStop"
        return _connector.post(url)
        
    def snapshot(self, ext:str, save=False, filename=None, show=False):
        """
        Acquire image about the args "extension". 
        The image is taken with the selected detector and the acquired image array is output or saved.
            
        Args: 
            extention (str):
                "jpg", "bmp", "tiff"
            save (bool):  
                'True' is save capture file.
            filename (str): 
                Name of file to save. It is possible to include an absolute path.
                Only available when 'save' is True.
            show (bool):
                show the Image file.

        Return: 
            if enter argument is only "extention", return value is image data stream (bytes).
            else return value is saved file name.
            
            File stream saved with the selected extension. (If there is 
            an input in an argument other than 'extention', None is returned.)
        """  
        url=self.uri+"/Snapshot/"+ext
        img = _connector.get(url)
        ac = _image.AcquireSetting(img)
        return ac.method(ext, save, filename, show)

    def snapshotframe(self, ext:str, save=False, filename=None, show=False):
        """
        This function is output the acquired image array.
        this function does not acquire the new image, to return the image array acquired with the snapshotall() function.        
        
        Args: 
            extention (str): 
                "jpg", "bmp", "tiff"
            save (bool):
                'True' is save capture file.
            filename (str): 
                Name of file to save. It is possible to include an absolute path.
                Only available when 'save' is True.
            show (bool): 
                show the Image file.
                
        Return: 
            if enter argument is only "extention", return value is image data stream (bytes).
            else return value is saved file name (str).

            File stream saved with the selected extension

        Note:
            This function does not acquire new image, to return the image array acquired with the snapshotall() function. 
        """
        url=self.uri+"/SnapShotFrame/"+ext
        img = _connector.get(url)
        ac = _image.AcquireSetting(img)
        return ac.method(ext, save, filename, show)

    def livesnapshot(self, ext:str, save=False, filename=None, show=False):
        '''
        Take an image with the specified extension. Obtaining images faster than "snapshot".

        Args: 
            extention (str): 
                "jpg", "bmp", "tiff"
            save (bool):  
                'True' is save capture file.
            filename (str): 
                Name of file to save. It is possible to include an absolute path.
                Only available when 'save' is True.
            show (bool): 
                show the Image file.
                
        Return: 
            bytes or str:
            if enter argument is only "extention", return value is image data stream (bytes).
            else return value is saved file name.

            File stream saved with the selected extension
        '''
        url=self.uri+"/LiveSnapShot/"+ext
        img = _connector.get(url)
        ac = _image.AcquireSetting(img)
        return ac.method(ext, save, filename, show)
        
    def snapshot_rawdata(self)->bytes:
        """
        Raw data of the image acquired by the specified detector. the raw data is returned as a byte array.

        Return:
            dict: 
            2 dimensional byte array of acquired image data.
        """        
        url=self.uri+"/CreateRawData"
        return _connector.get(url)
        
    def get_detectorsetting(self)->dict:
        '''
        Obtaining setting information of selected detector.
        
        Return:
            dict: get the selected detector's info.
            
        Example:
            >>> detector.Detector(detector name).get_detectorsetting()
            {
            "ExposureTimeValue":100,
            "GainIndex":100, ...
            }
        '''
        url=self.uri+"/Setting"
        return _connector.get(url)
        
    def set_detectorsetting(self, body:dict)->dict:
        '''
        Wild card method.

        Args:
            body (dict): "key" is function name you want to use. "value" is to change value.
         
        Return: 
            dict: The value set to TEM.
            
        Example:
            >>> body = {"ExposureTimeValue":100,"GainIndex":8000,"OffsetIndex":8000}
            >>> detector.Detector(detector name).set_detectorsetting(body)
        '''
        url=self.uri+"/Setting"
        return _connector.post(url,body)

    def set_exposuretime_index(self, value:int)->dict:
        '''
        Set the exposure time as index.
        
        Args:
            value (int): exposure time index. range is 0-65535

        Return:
            dict: 
            The value set to TEM.
        
        Example:
            >>> detector.Detector(detector name).set_exposuretime_index(100)            
            {"ExposureTimeIndex":100}
            
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"ExposureTimeIndex":value}
        return self.set_detectorsetting(body)

    def set_exposuretime_value(self, value:float)->dict:
        '''
        Set the exposure time as usec value.
        
        Args:
            value (float): 0.0-1000.0(μsec) 
                
        Return: 
            The value set to TEM.
            
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"ExposureTimeValue":value}
        return self.set_detectorsetting(body)

    def set_gainindex(self, value:int)->dict:
        '''
        Set the gain value as index.
        
        Args:
            value (int):  0- 4095
        Return: 
            dict: 
            The value set to TEM.
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"GainIndex":value}
        return self.set_detectorsetting(body)

    def set_offsetindex(self, value:int)->dict:
        '''
        Set the offset value as index.

        Args:
            value (int): 0- 4095

        Return: 
            dict: 
            The value set to TEM.
            
        Note: 
            value(Args)'s range sdepends on TEM model
        '''
        body = {"OffsetIndex":value}
        return self.set_detectorsetting(body)


    def set_scanrotation(self, value:float)->dict:
        '''
        Set the scanRotation angle as absolute value.
        
        Args:
            value (float): 0.0-360.0
            
        Return: 
            dict: The value set to TEM.
        '''
        body = {"ScanRotation":value}
        return self.set_detectorsetting(body)

    # def set_scanrotation_step(self, value):
    #     '''
    #     Summary:
    #         Set the minimum variation of scanRotation.
    #     Args:
    #         value:
    #             0-20
    #     Return: dict
    #         The value set to TEM.
    #     '''
    #     body = {"scanRotationStep":value}
    #     return self.set_detectorsetting(body)

    def set_imaging_area(self, Width:int, Height:int, X=None, Y=None)->dict:
        '''
        Set the number of pixels of the live image. 
        x and y are the coordinates of the starting pixel of the read image. 
        width and height are the coordinates of the end pixel of the read image.
        If no value is entered for the argument, the value is not changed.

        Args:
            X (int): 0-4096
            Y (int): 0-4096
            Width (int): 0-4096
            Height (int): 0-4096
            
        Return: 
            dict: 
            The value set to TEM.
        '''
        body = {"ImagingArea":{"X":X, "Y":Y, "Width":Width, "Height":Height}}
        return self.set_detectorsetting(body)

    def set_spotposition(self, X:int, Y:int)->dict:
        '''
        Set the beam position when ScanMode is "Spot".
        Sets which part of the scanning range set by ImagingArea is scanned.
        The top left vertex is (0, 0).
        If no value is entered for the argument, the value is not changed.
        
        Args:
            X (int): 0-4096
            Y (int): 0-4096
        Return: 
            dict: 
            The value set to TEM.
        '''
        body = {"SpotPosition":{"X":X, "Y":Y}}
        return self.set_detectorsetting(body)

    def set_areamode_imagingarea(self, Width:int, Height:int, X=None, Y=None)->dict:
        '''
        Set the beam position when ScanMode is "Area".
        Sets which part of the scanning range set by ImagingArea is scanned.
        The top left vertex is (0, 0).
        If no value is entered for the argument, the value is not changed.
        
        Args:
            X (int): 0-4096
            Y (int): 0-4096
            Width (int): 0-4096
            Height (int): 0-4096
            
        Return: 
            dict: 
            The value set to TEM.
        '''
        body = {"AreaModeImagingArea":{"X":X, "Y":Y, "Width":Width, "Height":Height}}
        return self.set_detectorsetting(body)

    def set_scanmode(self, value:int)->dict:
        '''
        Set the scanMode.
        Args:
            value (int): 0= Scan, 1= Area, 3= Spot
                
        Return: 
            dict: 
            The value set to TEM.
        '''
        body = {"scanMode":value}
        return self.set_detectorsetting(body)
    
########  mdp specified ####### 

    def set_syncmode(self, value:int)->dict:
        '''
        Set the Syncmode.

        Args:
            value (int): 0= Power, 1= Inside, 4= External
        Return:
            dict: 
            The value set to TEM.
            
        Note: 
            only available for MDP.
        '''
        body = {"SyncMode":value}
        return self.set_detectorsetting(body)
        
    ## 2023/10/4 IF削除に伴いコメントアウト
    # def set_lookuptable(self, value):
    #     '''
    #     Summary
    #         Set the beam position to scan when using LUTScan mode
    #         Beam position sets the ratio with the image edge as 1.0.
    #         The center is (0.0,0.0).  The edges of the image are (-1.0,-1.0) and (1.0,1.0)
    #         The maximum value is (4,4), The minimum value is (-4,-4)
    #     Args
    #         value: list
    #             ex) [[0.5,0.5],[0.6,0.6]...[1.0,1.0]]
    #     Return: dict
    #         The value set to TEM.
    #     '''
    #     body = {"LUTScanSetting":{"LookUpTable":value}}
    #     return self.set_detectorsetting(body)

    def get_linedata(self, start:int, end:int)->bytes:
        """
        To get the image data of the specified line.

        Args:
            start (int): line number
            end (int): line number

        Return: 
            bytes: 
            One pixel is two bytes. A byte order is little endian.            

        Note:
            This data in the order corresponding to “LUTScanSetting.LookUpTable”.
            "start" value is line number of first data. 
            "end" value is line number of last data. 

        Note: 
            only available for MDP.
        """
        url = self.uri+"/LineData/{}/{}".format(start, end)
        return _connector.get(url)

    def get_selectdata(self, start:int, end:int)->bytes:
        """
        Get the image data of the specified pixels. 
        If “scanMode” is not "4" (LUTScan), this API is the same as get_linedata module. 
        
        Args:
            start (int): index (byte position.)
            end (int): index (byte position.)
            

        Return: 
            bytes:
            One pixel is two bytes. A byte order is little endian.            

        Note:
            This data in the order corresponding to “LUTScanSetting.LookUpTable”.
            "start" value is line number of first data. 
            "end" value is line number of last data. 

        Note: 
            only available for MDP.
        """
        url = self.uri+"/SelectData/{}/{}".format(start, end)
        return _connector.get(url)
        
#     def get_memorymapped_filename(self):
#         """
#         Summary:
#             To get the image shared memory name about selected detector.

#         Args:
#             None:
            
#         Return: string
#             the image shared memory name about selected detector.
#         """
#         return get_memorymapped_filename(self.detector)

#     def get_memorymapped_size(self):
#         """
#         Summary:
#             To get the image shared memory size about selected detector.

#         Args:
#             None:

#         Return: int
#             the image shared memory size about the selected detector.
#         """
#         return get_memorymapped_size(self.detector)


# def get_memorymapped_size(detector=None):
#     """
#     Summary:
#         To get the image shared memory size about selected detector iamge data.        
#     Args:
#         detector: string
#             Enter the name of the detector you want to get.
#             if "detector"(args) is None, it is able to get the all detectors data.       
            
#     Return: int
#         the image shared memory size.
#     """
#     if detector == None:
#         url = uri+"Detector/MemoryMappedByteSize"
#     else:
#         url = uri+"Detector/{}/MemoryMappedByteSize".format(detector)        
#     return _connector.get(url)
    
# def get_memorymapped_filename(detector=None):
#     """
#     Summary:
#         To get the image shared memory name.
        
#     Args:
#         detector: string
#             Enter the name of the detector you want to get.
#             if "detector"(args) is None, it is able to get the all detectors data.            

#     Return: string
#         the image shared memory name.
#     """
#     if detector == None:
#         url = uri+"Detector/MemoryMappedFileName"
#     else:
#         url = uri+"Detector/{}/MemoryMappedFileName".format(detector)
#     return _connector.get(url)


## 2023/10/3 追加
def set_mdp_enable(sw:bool)->None:
    '''
    This API enables beam control with MDP.
        
    Args: 
        sw (bool):
            - False=> Mdp Enable Off.
            - True=> Mdp Enable On.

    '''
    if sw==False:
        url=uri+"/MdpEnableOff"
    elif sw==True:
        url=uri+"/MdpEnableOn"
    else:
        return 
    return _connector.post(url)

def set_LUT_offset(x:float,y:float)->None:
    '''
    This API adds an offset to the image position in LUTSacn. 
    It is assumed to be used for drift correction, etc.

    Args: 
        x (float): offset value.
        y (float): offset value.
    '''
    
    body = {
            "LUTOffset":{
            "X":x,
            "Y":y,
            }
        }

    url=uri+"/LUTOffset"
    return _connector.post(url,body)

def get_LUTscansetting()->dict:
    """
    This is a function to get the LUTScan setting.
        
    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.
        
        LUTScanSetting (dict): 
            - LookUpTable (list): 
                Use only when the shape is “Free”. 
                Set beam positions to scan. 
                The range of these is defined as ±1.0 at the edges of an image size. 
                The center of the image has coordinates (0.0 , 0.0).  
                The edges of it have coordinates ( -1.0 , -1.0 ) and ( 1.0 , 1.0 ). 
                The maximum value for the coordinates is (4,4), and the minimum value is (-4,-4) .
            - PixelResolution (int): 
                Set total number of points to scan on an analytical area. 
                ‘×4’ can be selected when an image size is ‘0.5K’ or less, and ‘×2’ can be selected when it’s size is ‘1K’ or less.
            - Shape (int): 
                Set a kind of shape for LUT scan. LookUpTable will be created by calculating from Shape and Positions except for Free.
                - Free: Not available. (Use “LookUp Table”)
                - Spot: Specify the point (X,Y) .
                - Line: Specify the coordinates of the starting and end points.
                - Area: A starting point is at the upper-left corner of an analytical area, and an end point is at the bottom-right corner of an analytical area.
            - Position (lists): 
                Free: Not available. (Use “LookUp Table”)
            - IgnorePixelCount (int): 
                Create extra points before an analytical area to ignore a camera trigger.
            - BlankingCount (int): 
                Line: Create points for blanking before an analytical area.
                Rectangle: Create points for blanking before the beginning of each row in an analytical area.
                When a shape is Rectangle or Full, a blanking point for one pixel is provided at the end of the horizontal scan. This parameter will be supported in the future.
                
    Example:
        >>> get_LUTscansetting()
        {
        "LUTScanSetting":{
            "LookUpTable": [ [-1,1], [0.5,0.2], [1,1] ],
            "PixelResolution" : 0,
            "Shape":0, 
            "Position":[[-0.29688,-0.82813],[-0.29688,-0.82813],],
            "PositionCount":[512,512], 
            "IgnorePixelCount": 1, 
            "BlankingCount": 1,
            },
        "LookUpTableMaximum":4.0,
        "LookUpTableMinimum":-4.0,
        "LookUpTablePointMaximum":2097151,
        "LUTOffset":{"X":0.0,"Y":0.0},
        }
    """
    url = uri+"/LUTScanSetting"
    return _connector.get(url)

def set_LUTscansetting(body):
    """
    This is a function to set the LUTScan setting.
        
    Args: 
        body (dict): 
            The following describes the keys to be set.

            LUTScanSetting (dict): 
                - LookUpTable (list): 
                    Use only when the shape is “Free”. 
                    Set beam positions to scan. 
                    The range of these is defined as ±1.0 at the edges of an image size. 
                    The center of the image has coordinates (0.0 , 0.0).  
                    The edges of it have coordinates ( -1.0 , -1.0 ) and ( 1.0 , 1.0 ). 
                    The maximum value for the coordinates is (4,4), and the minimum value is (-4,-4) .
                - PixelResolution (int): 
                    Set total number of points to scan on an analytical area. 
                    ‘×4’ can be selected when an image size is ‘0.5K’ or less, and ‘×2’ can be selected when it’s size is ‘1K’ or less.
                - Shape (int): 
                    Set a kind of shape for LUT scan. LookUpTable will be created by calculating from Shape and Positions except for Free.
                    - Free: Not available. (Use “LookUp Table”)
                    - Spot: Specify the point (X,Y) .
                    - Line: Specify the coordinates of the starting and end points.
                    - Area: A starting point is at the upper-left corner of an analytical area, and an end point is at the bottom-right corner of an analytical area.
                - Position (list): 
                    Free: Not available. (Use “LookUp Table”)
                - IgnorePixelCount (int): 
                    Create extra points before an analytical area to ignore a camera trigger.
                - BlankingCount (int): 
                    Line: Create points for blanking before an analytical area.
                    Rectangle: Create points for blanking before the beginning of each row in an analytical area.
                    When a shape is Rectangle or Full, a blanking point for one pixel is provided at the end of the horizontal scan. This parameter will be supported in the future.
        
    Example:
        >>> body = { 
            "LUTScanSetting":{ 
                　"LookUpTable": "[ [-1,1], [0.5,0.2], [1,1] ]",              
                 "PixelResolution" : 0,    
                 "Shape":0,              
                 "Position":[[-1.0, -1.0],[ 1.0, 1.0],],             
                 "IgnorePixelCount": 1,
                 "BlankingCount": 1,
                 },
            }
        >>> set_LUTscansetting(body)

    """
    url = uri+"/LUTScanSetting"
    return _connector.post(url,body)

def get_lookuptable():
    """
    This is a function gets the LookUpTable with binary data.
        
    Return: 
        byte:
        This API will return a byte array (Size(byte) : number of coordinates × 2 (X,Y) × 4 (float) )
                
    """
    url = uri+"/LUTScanSettingLookupTable"
    return _connector.get(url)

def set_lookuptable(body):
    """
    This is a function sets the LookUpTable with binary data.
        
    Args: 
        body (byte array): 
            This API will return a byte array (Size(byte) : number of coordinates × 2 (X,Y) × 4 (float) )
    """

    url = uri+"/LUTScanSetting"
    return _connector.post(url,body)


