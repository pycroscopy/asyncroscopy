# -*- coding: utf-8 -*-
"""
This package is used to control the detector functions of the FEMTUS.

Caution:
    This package supports some functions published by the FEMTUS.
    Therefore, this package cannot be used under the following conditions.

    - The FEMTUS is not configured in the network.
    - The FEMTUS is not running. 
"""

# from . import function
from .function import *



