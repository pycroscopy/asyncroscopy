# -*- coding: utf-8 -*-
"""
Created on Wed Dec  8 19:28:38 2021

@author: jeol
"""

class AcquisitionSettingParam:
    """
    Supported method:
        - set_acquisition_settings
    """
    def __init__(self,ptime,dtime="",mode="",count="",eds_selected="",scansync=""):        
        self.ProcessTime = ptime
        self.DwellTime = dtime
        self.CollectionMode = mode
        self.SweepCount = count
        self.EDSSelected = eds_selected
        self.EnableScanSync = scansync

class AnalyzerParam:
    """
    Supported method : 
        - set_analyzer_settings"""
    def __init__(self,ptime):
        self.ProcessTime = ptime
        
class AutoqualitativeParam:
    """
    Supported method : 
        - execute_autoqualitative_analysis
    """
    def __init__(self,data_id,detector):
        self.TargetDataID = data_id
        self.TargetDetector = detector

class BinaryParam:
    """
    Supported method : 
        - get_spectrum_data
        - get_map_data
        - extract_area_spectrum
    """
    def __init__(self, data_id):
        self.TargetDataID = data_id

class DetectorStatusParam:
    """
    Supported method : 
        - set_detector_status
    """
    def __init__(self,position):
        self.Position = position

class ElementParam:
    def __init__(self, number,line):
        self.ElementalNumber = number
        self.Line = line
        
class MultipleLineParam:
    """
    Supported method : 
        - get_multiple_line_data
    """
    def __init__(self,data_id,start="",end=""):
        self.TargetDataID = data_id
        self.StartLine = start
        self.EndLine = end

class MultipleSpectrumParam:
    """
    Supported method : 
        - get_multiple_spectrum_data
    """
    def __init__(self,data_id,start="",end=""):
        self.TargetDataID = data_id
        self.StartPosition = start
        self.EndPosition = end
        
class NetCountLineParam:
    """
    Supported method : 
        - set_net_count_line_analysis_settings
    """
    def __init__(self,method,datatype):
        self.ProcessingMethod = method
        self.StandardDataType = datatype
        
class NetCountMapParam:
    """
    Supported method : 
        - get_net_count_map_analysis_settings
    """
    def __init__(self,method="",datatype="",width="",height=""):
        self.ProcessingMethod = method
        self.StandardDataType = datatype
        self.PixelWidth = width
        self.PixelHeight = height
        
class QuantitativeSpectrumParam:
    """
    Supported method : 
        - set_quantitative_spectrum_analysis_settings
        - set_net_count_map_analysis_settings
    """
    def __init__(self,method="",datatype="",name="",correctiontype="",absorptioncorrection="",
                 thickness="",density="",fluorescencecorrection="",conversiontype="",oxideCation=""):
        self.ProcessingMethod = method
        self.StandardDataType = datatype
        self.UserCategoryName = name
        self.CorrectionType = correctiontype
        self.EnableAbsorptionCorrection = absorptioncorrection
        self.Thickness = thickness
        self.Density = density
        self.EnableFluorescenceCorrection = fluorescencecorrection
        self.ConversionType = conversiontype
        self.OxideCation = oxideCation
        
class QuantitativeLineParam:
    """
    Supported method : 
        - set_quantitative_line_analysis_settings
    """    
    def __init__(self,method="",datatype="",name="",correctiontype="",
                 conversiontype="",oxidecation="",enablesumpeakremoval=""):
        self.ProcessingMethod = method
        self.StandardDataType = datatype
        self.UserCategoryName = name
        self.CorrectionType = correctiontype
        self.ConversionType = conversiontype
        self.OxideCation = oxidecation
        self.EnableSumPeakRemoval = enablesumpeakremoval
    
class QuantitativeMapParam:
    """
    Supported method : 
        - set_quantitative_map_analysis_settings
    """    
    def __init__(self,method="",datatype="",name="",width="",height="",
                 correctiontype="",conversiontype="",enablesumpeakremoval=""):
        self.ProcessingMethod = method
        self.StandardDataType = datatype
        self.UserCategoryName = name
        self.PixelWidth = width
        self.PixelHeight = height
        self.CorrectionType = correctiontype
        self.ConversionType = conversiontype
        self.EnableSumPeakRemoval = enablesumpeakremoval
    

class SpectrumSettingsParam:
    def __init__(self,method="",datatype="",correctiontype="",conversiontype="",width="",height=""):
        self.ProcessingMethod = method
        self.StandardDataType = datatype
        self.CorrectionType = correctiontype
        self.ConversionType = conversiontype
        self.PixelWidth = width
        self.PixelHeight = height

class SpectrumAnalysisParam:
    """
    Supported method : 
        - execute_quantitative_spectrum_analysis
        - extract_line_spectrum
        - execute_count_line_analysis
        - execute_net_count_line_analysis
        - execute_quantitative_line_analysis
        - create_count_map
        - create_net_count_map
        - create_quantitative_map
    """    
    def __init__(self,data_id, elements, detector=""):
        self.TargetDataID = data_id
        self.Elements = elements
        self.TargetDetector = detector




def _body_check(param:dict):
    return {k:v for k,v in param.items() if v!=""}


# from enum import Enum

# from ..base import BaseClass, get_enum_list

# class AnalyzerKey(Enum):
#     ProcessTime = "ProcessTime"

# class AcquisitionSettingKey(Enum):
#     ProcessTime = "ProcessTime"
#     DwellTime = "DwellTime"
#     CollectionMode = "CollectionMode"
#     SweepCount = "SweepCount"
#     SelectedDetector = "SelectedDetector"
#     EnableScanSync = "EnableScanSync"

# class SpectrumDataKey(Enum):
#     TargetDataID = "TargetDataID"
#     StartPosition = "StartPosition"
#     EndPosition = "EndPosition"
#     StartLine = "StartLine"
#     EndLind = "EndLind"

# class ElementsKey(Enum):
#     ElementalNumber = "ElementalNumber"
#     Line = "Line"

# class AnalysisKey(Enum):
#     Elements = "Elements"
#     TargetDetector = "TargetDetector"
#     TargetDataID = "TargetDataID"

# class SpectrumSettingsKey(Enum):
#     ProcessingMethod = "ProcessingMethod"
#     StandardDataType = "StandardDataType"
#     CorrectionType = "CorrectionType"
#     ConversionType = "ConversionType"
#     PixelWidth = "PixelWidth"
#     PixelHeight = "PixelHeight"

# class DetectorStatusKey(Enum):
#     Position = "Position"

# class SpectrumAnalysisKey(Enum):
#     TargetDataID = "TargetDataID"
#     Elements = "Elements"
#     TargetDetector = "TargetDetector"

# class __FormatTemplate(BaseClass):
#     def __init__(self, obj, *args, **kw):
#         super().__init__(*args, **kw)
#         key = get_enum_list(obj)
#         self.param = {k: w for k, w in self._param.items() if k in key}
#         print(self.param)

# class Analyzer(__FormatTemplate):
#     def __init__(self, *args, **kw):
#         super().__init__(AnalyzerKey, *args, **kw)


# class AcquisitionSettingParam(__FormatTemplate):
#     def __init__(self, *args, **kw):
#         super().__init__(AcquisitionSettingKey, *args, **kw)


# class SpectrumData(__FormatTemplate):
#     def __init__(self, *args, **kw):
#         super().__init__(SpectrumDataKey, *args, **kw)


# class Elements(__FormatTemplate):
#     def __init__(self, *args, **kw):
#         super().__init__(ElementsKey, *args, **kw)


# class Analysis(__FormatTemplate):
#     def __init__(self, *args, **kw):
#         super().__init__(AnalysisKey, *args, **kw)


# class SpectrumSettings(__FormatTemplate):
#     def __init__(self, *args, **kw):
#         super().__init__(SpectrumSettingsKey, *args, **kw)


# class DetectorStatus(__FormatTemplate):
#     def __init__(self, *args, **kw):
#         super().__init__(DetectorStatusKey, *args, **kw)


# class SpectrumAnalysis(__FormatTemplate):
#     def __init__(self, *args, **kw):
#         super().__init__(SpectrumAnalysisKey, *args, **kw)
