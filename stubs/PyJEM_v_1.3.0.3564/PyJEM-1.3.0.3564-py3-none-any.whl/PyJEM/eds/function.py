# -*- coding: utf-8 -*-
'''
'''
# import base
from ..connect import Connect
from . import interface
# from .interface import *

name = 'femtus_eds'
_connector = Connect(name)
_connector.initialize('localhost', 49306)

_uri = '/EDSService/JED'
def set_ip(val):
    """
    This function can modify the IP Address which is URI of this package.
    
    Args:
        val (int): ip address.
    """
    _connector.setup(ip=val)

def set_port(val:int)->None:
    """
    This function can modify the port number which is URI of this package.
    
    Args:
        val (int): port numnber.
    
    Warning:
        Please do not use it except for JEOL service.
    """
    _connector.setup(port=val)

def get_config():
    """
    This function returns the package's settings.
    
    Return:
        dict:
            service info.
    
    Example:
        >>> detector.get_config()
        {'name': '---', 'ip': '---', 'port': ---, 'uri': '---'}
    """
    return _connector.urlformat.__dict__

def check_communication():
    '''
    This interface is for checking the HTTP connection.

    Return: 
        dict: Output in dict type. The explanation of the output keys is as follows.
        - Result (str): 'OK' is success, 'Fail' is failure.            
        - Message (str):  This is a free text from EDS system.

    Example:
        >>> check_communication()
        {
            'Version': '1.0',
            'Result': 'OK'
        }
    '''
    url = _uri+'/CheckCommunication'
    return _connector.get(url)


def get_specification():
    '''
    This interface can get the specfication of EDS system.

    Return:
        dict: Output in dict type. The explanation of the output keys is as follows.
        
        - Version (str): 
            version number of this data structure.

        - ProcessTimeList (list):
             This is the list of ProcessTimeList
             
    Example:
        >>> get_specification()
        {
            ProcessTimeList':[
                ['T1', 'T2', 'T3', 'T4'], 
                ['T1', 'T2', 'T3', 'T4'], 
                ['T1', 'T2', 'T3', 'T4'], 
                ['T1', 'T2', 'T3', 'T4']
            ],
            'Version': '1.0'
        }
    '''
    url = _uri+'/Specification'
    return _connector.get(url)


def get_analyzer_settings():
    '''
    This interface can get the settings of EDS analyzer.

    Return: 
        dict: 
        Output in dict type. The explanation of the output keys is as follows.
        
        - Version (str): 
            version number of this data structure.

        - ProcessTime (list): 
             The kind of process time. 
             The range is in ProcessTimeList of specification
             The length of array is the same as maximum number of detectors.
 
    Example:
        >>> get_analyzer_settings()
        {
            ProcessTime':['T1', 'T1', 'T1', 'T1'],
            'Version': '1.0'
        }
    '''
    url = _uri+'/Analyzer/Settings'
    return _connector.get(url)


def set_analyzer_settings(param):
    '''
    This interface can set the settings of EDS analyzer.

    Args: 
        param (dict):           
            - ProcessTime (list): 
                The kind of process time. 
                The range is in ProcessTimeList of specification
                The length of array is the same as maximum number of detectors.

    Return:
        similar to get_analyzer_settings()
        
    Example:
        >>> body = AnalyzerParam(['T1', 'T1', 'T1', 'T1'])
        >>> set_analyzer_settings(body.__dict__))
        {'ProcessTime' : ['T1', 'T1', 'T1', 'T1']}

    '''
    url = _uri+'/Analyzer/Settings'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_analyzer_status():
    '''
    This interface can get the status of EDS analyzer.

    Return (dict): 
        Output in dict type. The explanation of the output keys is as follows.

        - InputCountRate (list): 
            input count rate. [%]
            The length of array is 4 + 1. 4 is maximum number of detectors. 
            1 is for total count rate. 
            The order is [first detector, second, third, fourth, total ].

        - OutputCountRate (list): 
            output count rate. [%]
            The length of array is 4 + 1. 4 is maximum number of detectors. 
            1 is for total count rate. 
            The order is [first detector, second, third, fourth, total ].
        
        - DeadTime (list): 
            dead time [%]
            The length of array is 4 + 1. 4 is maximum number of detectors. 
            1 is for total dead time. 
            The order is [first detector, second, third, fourth, total ].

    Example:
        >>> get_analyzer_status()
        {
            'InputCountRate' : [21, 21, 21, 21, 21],
            'OutputCountRate' : [21, 21, 21, 21, 21],
            'DeadTime' : [21, 21, 21, 21, 21]
        }
    '''
    url = _uri+'/Analyzer/Status'
    return _connector.get(url)


def get_detector_configuration():
    '''
    This interface can get the configuration of EDS system.

    Return:
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - Version (str): 
            version number of this data structure.

        - Enabled (list) :
            true : Enabled, false : Disabled
            The length of array is 4.
            The index 0 means first detector.
            The index 1 means second detector.
            The index 2 means third detector.
            The index 3 means forth detector.
        
        - Retractable (list):
            true : Retractable, false : Not Retractable
            The length of array is 4.
            The index 0 means first detector.
            The index 1 means second detector.
            The index 2 means third detector.
            The index 3 means forth detector.
        
    Example:
        >>> get_detector_configuration()
        {
            'Enabled' : [True, True, True, True],
            'Retractable' : [True, True, False, False],
            'Version' : '---'
        }
    '''
    url = _uri+'/Detector/Configuration'
    return _connector.get(url)


def get_detector_status():
    '''
    This interface can get the status of EDS detectors.

    Return:
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - Version (str):
            version number of this data structure.
            
        - Position (str):
            The length of array is 4. The order is the same as 'Enabled' of detector configuration
            -1 : Unknown, 0 : Bake, 1 : SampleChange, 2 : Retract, 3 : Insert 

        - MovingPosition (int):
            The length of array is 4. The order is the same as 'Enabled' of detector configuration
            0 : Stopped, 1 : Moving,

        
        - DetectorErrorCode (str):
            The error code of detector hardware.
        
    Example:
        >>> get_detector_status()
        {
            'Position' : [1, 1, 0, 0],
            'MovingPosition' : [1, 1, 0, 0],
            'DetectorErrorCode': 'E01',
            'Version': '---'
        }
    '''
    url = _uri+'/Detector/Status'
    return _connector.get(url)


def set_detector_status(param):
    '''
    This interface can set the status of EDS detectors.

    Args:
        param (dict):
            The following describes the keys to be set.

            - Position (list):
                The length of array is 4. The order is the same as 'Enabled' of detector configuration
                -1 : Unknown, 0 : Bake, 1 : SampleChange, 2 : Retract, 3 : Insert
    
    Example:
        >>> body = DetectorStatusParam(position=[2, 2, 3, 3])
        >>> set_detector_status(body.__dict__)
    '''
    url = _uri+'/Detector/Status'
    param = interface._body_check(param)
    return _connector.post(url, param)


def reset_detector():
    '''
    This interface can reset a harware of detector.
    '''
    url = _uri+'/Detector/Reset'
    return _connector.post(url)


def get_acquisition_settings():
    '''
    This interface can get the settings of EDS acquisition.

    Return:
        dict: 
        Output in dict type. The explanation of the output keys is as follows.

        - Version (str):
            version number of this data structure.
        - ProcessTime (str): 
            The kind of process time. The range is in ProcessTimeList of specification.
            
        - DwellTime (float):
            The DwellTime is the time spent on the sample.
            The unit is [μsec]
            The actual time depends on CollectionMode.

        - CollectionMode (int):
            0 : Endless, 1 : LiveTime, 2 : RealTime, 3 : Sweep
            The time spent on the sample is the same as DwellTime in RealTime mode.
            Otherwise, the effective counting time is the same as DwellTime in LiveTime mode. 
            The time spent on the sample in LiveTime mode become longer than DwellTime in RealTime mode.
            The DwellTime will be ignored in Endless mode. 
            Sweep mode collects data throughout an analytical area for a set number of times.
        
        - SweepCount (int):
            The number of acquiring the data to create an integrated data. 
            This is available in Full/Area/Line mode.

        - EnableScanSync (bool):
            True: Sync, False: Not sync
            If this mode is true, DwellTime is synchronized with pixel clock of scan generator.
            
        - EDSSelected (bool):
            true: Enable to start an acquisition of EDS signals. false: Not enable to do it.
    '''
    url = _uri+'/Acquisition/Settings'
    return _connector.get(url)


def set_acquisition_settings(param):
    '''
    This interface can set the settings of EDS acquisition.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - ProcessTime (str):
                The kind of process time. The range is in ProcessTimeList of specification.

            - DwellTime (float):
                The DwellTime is the time spent on the sample. 
                If EnableScanSync is set as true, this parameter works on the sample per pixel. 
                The unit is [μsec]
                The actual time depends on CollectionMode.
            
            - CollectionMode (int):
                0 : Endless, 1 : LiveTime, 2 : RealTime, 3 : Sweep
                The time spent on the sample is the same as DwellTime in RealTime mode.
                Otherwise, the effective counting time is the same as DwellTime in LiveTime mode. 
                The time spent on the sample in LiveTime mode become longer than DwellTime in RealTime mode.The DwellTime will be ignored in Endless mode.
            
            - SweepCount (int):
                The number of acquiring the data to create an integrated data. 
                This is available in Full/Area/Line mode.
    
            - EnableScanSync (bool):
                true : Sync, false : Not sync
                If this mode is true, The DwellTime is synchronized with pixel clock of scan generator.
    
            - EDSSelected (bool):
                true: Enable to start an acquisition of EDS signals. false: Not enable to do it.

    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.
        similar to get_acquisition_settings()
        
    Example:
        >>> body = AcquisitionSettingParam(ptime=['T1', 'T2', 'T3', 'T4'],count=1)
        >>> set_acquisition_settings(body.__dict__)
        {
            'ProcessTime' : ['T1', 'T2', 'T3', 'T4'],
            'SweepCount' : 1,
        }
    '''
    url = _uri+'/Acquisition/Settings'
    param = interface._body_check(param)
    return _connector.post(url, param)


# def set_acquisition_processtime(val):
#     return set_acquisition_settings(ProcessTime=val)


# def set_acquisition_dwelltime(val):
#     return set_acquisition_settings(DwellTime=val)


# def set_acquisition_collectionmode(val):
#     return set_acquisition_settings(CollectionMode=val)


# def set_acquisition_sweepcount(val):
#     return set_acquisition_settings(SweepCount=val)


# def set_acquisition_SelectedDetector(val):
#     return set_acquisition_settings(SelectedDetector=val)


# def set_acquisition_EnableScanSync(val):
#     return set_acquisition_settings(EnableScanSync=val)


def start_acquisition():
    '''
    This interface start an acquisition of EDS signals.
    If EnableScanSync is true, the scan generator should
    be started after this is called.

    Return:
        Output in dict type. The explanation of the output keys is as follows.

        - Message (str) :
            This is a free text from EDS system.
        - Result (str):
            'OK' : success, 'Fail' : failure
        - DataID (str):
            This is an ID to specify the data that the acquired spectrum will be stored. 

    Example:
        >>> start_acquisition()
        {
            'Result' : 'OK',
            'Message' : 'This is a free text from EDS system.',
            'DataID' : 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
        }
    '''
    url = _uri+'/Acquisition/Start'
    return _connector.post(url)


def stop_acquisition():
    '''
    This interface stop the acquisition of EDS signals.

    Return:
        Output in dict type. The explanation of the output keys is as follows.

        - Message (str) :
            This is a free text from EDS system.
        - Result (str):
            'OK' is success, 'Fail' is failure

    Example:
        >>> stop_acquisition()
        {
            'Message' : 'This is a free text from EDS system.',
            'Result' : 'OK'
        }
    '''
    url = _uri+'/Acquisition/Stop'
    return _connector.post(url)


def get_acquisition_status():
    '''
    This interface can get the status of EDS acquisition.

    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - Version (str):
            version number of this data structure.
            
        - AcquisitionRunning (bool):
            true : Running, false : Stopped
            
        - LiveTime (int): 
            live time [sec]
            The length of array is 4 + 1. 4 is maximum number of detectors. 
            1 is for total dead time. 
            The order is [first detector, second, third, fourth, total ].

        - RealTime (int):
            live time [sec]
            The length of array is 4 + 1. 4 is maximum number of detectors. 
            1 is for total dead time. 
            The order is [first detector, second, third, fourth, total ].

        - SweepCount (int):
            The current number of acquiring the data to create integrated data. 
        
    Example:
        >>> get_acquisition_status()
        {
            'Version': '1.0',
            'AcquisitionRunning' : False,
            'ElapsedLiveTime' : 12,
            'ElapsedRealTime' : 12,
            'SweepCount' : 2
        }
    '''
    url = _uri+'/Acquisition/Status'
    return _connector.get(url)


def get_spectrum_data(param):
    '''
    This interface can get spectrum data that is acquiring or opened.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 

    Return: 
        byte: 
        This is binary data. 
        The intensity of X-ray energy is 4bytes integer. 
        The length of energy is 4096 pixel. 
        A lowest energy is top of data.
        The number of spectrums depends on specified position of line data.
        A byte order is little endian.
           
    '''
    url = _uri+'/Analysis/SpectrumData'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_multiple_spectrum_data(param):
    '''
    This interface can get acquiring spectrum data that specifying the position of line analysis data.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
    
            - StartPosition (int)n:
                This is an index of pixels that is the starting position to get from the line analysis data.
            
            - EndPosition (int):
                This is an index of pixels that is the end position to get from the line analysis data.
        
    Return:
        bytes:
        This is binary data. 
        The spectrum data format is the same as get_spectrum_data(). 
        This data contains multiple spectrum for pixels. 
        The pixel of StartPosition is first of this data.
    '''
    url = _uri+'/Analysis/MultipleSpectrumData'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_multiple_line_data(param):
    '''
    This interface can get acquiring spectrum data that specifying the line position of spectrum imaging data. This is available for opend spectrum data.

    Args: 
        param (dict):
            The following describes the keys to be set.

            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
    
            - StartLine (int):
                This is a start line number of the spectrum imaging data to get.
            
            - EndLine (int):
                This is a start line number of the spectrum imaging data to get.

    Return:
        bytes: 
        This is binary data. 
        The multiple spectrum data format is the same as get_multiple_spectrum_data(). 
        This data contains multiple line. 
        The line of StartLine is first of this data
    '''
    url = _uri+'/Analysis/MultipleLineData'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_map_data(param):
    '''
    This interface can get binary data of the elemental map. This is available for opend map data.

    Args:
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 

    Return: 
        byte:
        This is binary data. The intensity of map is 4bytes floating point. 
        The length of array depends on map size. 
        Top-left pixel is the first of array. A byte order is little endian.
    '''
    url = _uri+'/Analysis/MapData'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_analysis_settings():
    '''
    This interface can get the settings of analysis.

    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - Version (str):
            version number of this data structure.

        - LengthOfSpectrum (int):
            This number is length of spectrum. The unit is [10 ev / ch].

        - UserCategories (str):
            The type is array of string. 
            This is a list of standard data that the user create their own standard data. 
            This string can be used for UserCategoryName for some analysis..

        - DisableElements (list):
            This is the list of disabled element

        - QualitativeSensitivity (str):
            'Low' : low sensitivity, 'Middle' : middle sensitivity, 'High' : high sensitivity
            This is a sensitivity of qualitative analysis.

        - ZAFEnable (bool):
            true : Enable, false : Disable
            This can get that ZAF correction is available or not.

        - PRZEnable (bool):
            true : Enable, false : Disable
            This can get that PRZ correction is available or not.

        - Cliff-LorimerEnable (bool):
            true : Enable, false : Disable
            This can get that Cliff-Lorimer correction is available or not.
        
    Example:
        >>> get_analysis_settings()
        {
            'LengthOfSpectrum' : 4096,
            'UserCategories' : [
                'This is a list of standard data that the user create their own standard data. This string can be used for UserCategoryName for some analysis.'
            ],
            'DisableElements' : [
                ['ElementalNumber', 8],
                ['ElementalNumber', 10]
            ],
            'QualitativeSensitivity' : 'Middle',
            'ZAFEnable' : True,
            'PRZEnable' : True,
            'CliffLorimerEnable' : True
        }
    '''
    url = _uri+'/Analysis/Settings'
    return _connector.get(url)


def get_analysis_status():
    '''
    This interface can get the status of analysis.

    Return:
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - ExecutingAnalysis (bool):
            true : Executing, false : Stopped

        - Version (str):
            version number of this data structure.
        
    Example:
        >>> get_analysis_status()
        {
            'ExecutingAnalysis' : True,
            'Version' : '1.0',
        }
    '''
    url = _uri+'/Analysis/Status'
    return _connector.get(url)


def execute_autoqualitative_analysis(param):
    '''
    This interface execute auto qualitative analysis.
    This interface search the elements by peak of spectrum.
    This return the searched elements.

    Args: 
        param (dict):
            The following describes the keys to be set.

            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
    
            - TargetDetector (int):
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                - 0=Total, 
                - 1=FirstDetector, 
                - 2=SecondDetector, 
                - 3=ThirdDetector, 
                - 4=ForthDetector

    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - Message (str) :
            This is a free text from EDS system.
            
        - Elements (str):
            This is two dimensional array. This is a list of element that contains elemental number,. 
            
        - Result (str):
            'OK' : success, 'Fail' : failure

    Example:
        >>> body = AutoqualitativeParam(data_id='0000-0000-0000-0000',detector=0)
        >>> execute_autoqualitative_analysis(body.__dict__)
        {
            'Message' : 'This is a free text from EDS system.',
            'Elements' :['aaaa-aaaa-aaaa-aaaa', 'bbbb-bbbb-bbbb-bbbb','cccc-cccc-cccc-cccc'],
            'Result': 'OK'
        }
    '''
    url = _uri+'/Analysis/ExecuteAutoQualitativeAnalysis'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_quantitative_spectrum_analysis_settings():
    '''
    This interface can get the settings of quantitative analysis for spectrum.

    Return:
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - ProcessingMethod (int):
            0 : None, 1 : Speed, 2 : Precise
            The kind of processing method. 
            Speed/ Precise are supported.

        - StandardDataType (int):
            0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
            The NORM/ COMMON/ USER are supported.

        - UserCategoryName (str):
            The category name of standard data. 
            If the StandardDataType is USER, this category name is available. 
            
        - CorrectionType (int): 
            0 : None, 1 : ZAF, 2 : PRZ, 3 : Cliff-Lorimer, 4 : ZETA
            ZAF/ PRZ/ Cliff-Lorimer/ ZETA are supported.

        - EnableAbsorptionCorrection (bool):
            true : Enable, false : Disable
            This parameter decide whether the absorption correction is enable or not.
            This is available in Cliff-Lorimer mode.

        - Thickness (int):
            This is a value of thickness. The unit is [nm]
            This is available in Cliff-Lorimer mode and the absorption correction is enabled.

        - Density (int):
            This is a value of density. The unit is [g/cm3]
            This is available in Cliff-Lorimer mode and the absorption correction is enabled.

        - EnableFluorescenceCorrection (bool):
            true : Enable, false : Disable
            This parameter decide whether the fluorescence correction is enable or not.
            This is available in Cliff-Lorimer mode.

        - ConversionType (int):
            0 : None, 1 : Metal, 2 : Oxide, 3 : Compound
            Metal/ Oxide are available

        - OxideCation (int):
            This is a cation number of oxide. 
            This is available in oxide mode as conversion type.
            
    Example:
        >>> get_quantitative_spectrum_analysis_settings()
        {
            'PixelWidth' : 128,
            'PixelHeight' : 128,
            'ProcessingMethod' : 0,
            'StandardDataType' : 0,
            'UserCategoryName' : '',
            'CorrectionType' : 3,
            'ConversionType' : 1,
            'EnableSumPeakRemoval' : True,
        }

    '''
    url = _uri+'/Analysis/QuantitativeSpectrumSettings'
    return _connector.get(url)


def set_quantitative_spectrum_analysis_settings(param):
    '''
    This interface can set the settings of quantitative analysis for spectrum.
    param's type is QuantitativeSpectrumParam

    Args: 
        param (dict):  
            The following describes the keys to be set.

            - ProcessingMethod (int):
                0 : None, 1 : Speed, 2 : Precise
                The kind of processing method. 
                Speed/ Precise are supported.
    
            - StandardDataType (int):
                0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
                The NORM/ COMMON/ USER are supported.
    
            - UserCategoryName (str):
                The category name of standard data. 
                If the StandardDataType is USER, this category name is available. 
                
            - CorrectionType (int): 
                0 : None, 1 : ZAF, 2 : PRZ, 3 : Cliff-Lorimer, 4 : ZETA
                ZAF/ PRZ/ Cliff-Lorimer/ ZETA are supported.
    
            - EnableAbsorptionCorrection (bool):
                true : Enable, false : Disable
                This parameter decide whether the absorption correction is enable or not.
                This is available in Cliff-Lorimer mode.
    
            - Thickness (int):
                This is a value of thickness. The unit is [nm]
                This is available in Cliff-Lorimer mode and the absorption correction is enabled.
    
            - Density (int):
                This is a value of density. The unit is [g/cm3]
                This is available in Cliff-Lorimer mode and the absorption correction is enabled.
    
            - EnableFluorescenceCorrection (bool):
                true : Enable, false : Disable
                This parameter decide whether the fluorescence correction is enable or not.
                This is available in Cliff-Lorimer mode.
    
            - ConversionType (int):
                0 : None, 1 : Metal, 2 : Oxide, 3 : Compound
                Metal/ Oxide are available
    
            - OxideCation (int):
                This is a cation number of oxide. 
                This is available in oxide mode as conversion type.
            
    Return: 
        dict:
        similar to get_quantitative_spectrum_analysis_settings()
    '''
    url = _uri+'/Analysis/QuantitativeSpectrumSettings'
    param = interface._body_check(param)
    return _connector.post(url, param)


def execute_quantitative_spectrum_analysis(param):
    '''
    This interface execute quantitative analysis for spectrum.

    Args:
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
            - Elements (ElementsKey):
                This is two dimensional array. This is a list of element that contains elemental number and Line. 
                The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
                'Default' is selecting default line automatically.
            - TargetDetector int:
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                0=Total, 
                1=FirstDetector, 
                2=SecondDetector, 
                3=ThirdDetector, 
                4=ForthDetector
        
    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.
        
        - Message (str) :
            This is a free text from EDS system.
        - Quantities (str):
            The array of elemental quantity. The unit is Mass%.
        - Result (str):
            'OK' : success, 'Fail' : failure
    '''
    url = _uri+'/Analysis/ExecuteQuantitativeSpectrumAnalysis'
    param = interface._body_check(param)
    return _connector.post(url, param)


# def get_line_data_ids(param):
#     '''
#     Summary:
#         This interface can get line data IDs.

#     Args: dictionary
#         {
#             'TargetDataID' : 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
#         }

#     Return:
#         {
#             'Message' : 'This is a free text from EDS system.',
#             'DataIDs' :['aaaa-aaaa-aaaa-aaaa', 'bbbb-bbbb-bbbb-bbbb',
#                         'cccc-cccc-cccc-cccc'],
#             'Result': 'OK'
#         }
#     '''
#     url = _uri+'/Analysis/LineDataIDs'
#     return _connector.post(url, interface.SpectrumAnalysis(param))


# @base.request(name, '/Analysis/ExtractLineSpectrum', 'POST')
def extract_line_spectrum(param):
    '''
    This interface can create an integrated spectrum that extracted from line analysis data.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
            - Elements (ElementsKey):
                This is two dimensional array. This is a list of element that contains elemental number and Line. 
                The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
                'Default' is selecting default line automatically.
            - TargetDetector int:
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                0=Total, 
                1=FirstDetector, 
                2=SecondDetector, 
                3=ThirdDetector, 
                4=ForthDetector
        
    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - Message (str) :
            This is a free text from EDS system.
        - Quantities (str):
            The array of elemental quantity. The unit is Mass%.
        - Result (str):
            'OK' : success, 'Fail' : failure
    '''
    url = _uri+'/Analysis/ExtractLineSpectrum'
    param = interface._body_check(param)
    return _connector.post(url, param)


def extract_area_spectrum(param):
    '''
    This interface can create an integrated spectrum that extracted from spectrum imaging data.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 

    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.
        
        - Message (str) :
            This is a free text from EDS system.
        - SpectrumDataID (str):
            This is a ID of the spectrm that extraced from original spectrum imaging data.
        - Result (str):
            'OK' : success, 'Fail' : failure
    '''
    url = _uri+'/Analysis/ExtractAreaSpectrum'
    param = interface._body_check(param)
    return _connector.post(url, param)


def execute_count_line_analysis(param):
    '''
    This interface create gross count data of line analysis.

    Args:
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
            - Elements (ElementsKey):
                This is two dimensional array. This is a list of element that contains elemental number and Line. 
                The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
                'Default' is selecting default line automatically.
            - TargetDetector int:
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                0=Total, 
                1=FirstDetector, 
                2=SecondDetector, 
                3=ThirdDetector, 
                4=ForthDetector
        
    Return:
        dict:
        Output in dict type. The explanation of the output keys is as follows.
        
        - Message (str) :
            This is a free text from EDS system.
        - DataIDs (list):
            The array of ID. The length of array is the same as length of element list.
        - Result (str):
            'OK' : success, 'Fail' : failure
    '''
    url = _uri+'/Analysis/CreateCountLine'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_net_count_line_analysis_settings():
    '''
    This interface can get the settings of net count line analysis.

    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.

        - Version (str):
            version number of this data structure.
            
        - ProcessingMethod (int):
            0 : None, 1 : Speed, 2 : Precise
            The kind of processing method. 
            Speed/ Precise are supported.

        - StandardDataType (int):
            0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
            The NORM/ COMMON/ USER are supported.

    Example:
        >>> get_net_count_line_analysis_settings()
        {
            'Version':'1.0',
            'ProcessingMethod' : 0,
            'StandardDataType' : 0,
        }
    '''
    url = _uri+'/Analysis/NetCountLineSettings'
    return _connector.get(url)


def set_net_count_line_analysis_settings(param):
    '''
    This interface can set the settings of net count line analysis.

    Args: 
        param:(dict)
            The following describes the keys to be set.

            - ProcessingMethod (int):
                0 : None, 1 : Speed, 2 : Precise
                The kind of processing method. 
                Speed/ Precise are supported.
    
            - StandardDataType (int):
                0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
                The NORM/ COMMON/ USER are supported.

    Return: 
        dict:
        similar to get_net_count_line_analysis_settings().
    '''
    url = _uri+'/Analysis/NetCountLineSettings'
    param = interface._body_check(param)
    return _connector.post(url, param)


def execute_net_count_line_analysis(param):
    '''
    This interface create net count data of line analysis.

    Args: 
        param (dict):
            The following describes the keys to be set.

            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
            - Elements (ElementsKey):
                This is two dimensional array. This is a list of element that contains elemental number and Line. 
                The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
                'Default' is selecting default line automatically.

            - TargetDetector int:
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                0=Total, 
                1=FirstDetector, 
                2=SecondDetector, 
                3=ThirdDetector, 
                4=ForthDetector
            
    Return: 
        dict:
        - Message (str) :
            This is a free text from EDS system.
        - DataIDs (list):
            The array of ID. The length of array is the same as length of element list.
        - Result (str):
            'OK' : success, 'Fail' : failure
    '''
    url = _uri+'/Analysis/CreateNetCountLine'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_quantitative_line_analysis_settings():
    '''
    This interface can get the settings of quantitative line analysis.

    Return: 
        dict: 
        - ProcessingMethod (int):
            0 : None, 1 : Speed, 2 : Precise
            The kind of processing method. 
            Speed/ Precise are supported.

        - StandardDataType (int):
            0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
            The NORM/ COMMON/ USER are supported.

        - UserCategoryName (str):
            The category name of standard data. 
            If the StandardDataType is USER, this category name is available. 
            
        - CorrectionType (int):
            0 : None, 1 : ZAF, 2 : PRZ, 3 : Cliff-Lorimer, 4 : ZETA
            ZAF/ PRZ/ Cliff-Lorimer/ ZETA are supported.

        - ConversionType (int):
            0 : None, 1 : Metal, 2 : Oxide, 3 : Compound
            Metal/ Oxide are available

        - OxideCation (int):
            This is a cation number of oxide. 
            This is available in oxide mode as conversion type.

        
        - EnableSumPeakRemoval (bool): 
            true : Enable, false : Disable

    Example:
        >>> get_quantitative_line_analysis_settings()
        {
            'ProcessingMethod' : 0,
            'StandardDataType' : 0,
            'UserCategoryName' : '',
            'CorrectionType' : 3,
            'ConversionType' : 1,
            'OxideCation':1,
            'EnableSumPeakRemoval' : True
        }    
    '''
    url = _uri+'/Analysis/QuantitativeLineSettings'
    return _connector.get(url)


def set_quantitative_line_analysis_settings(param):
    '''
    This interface can set the settings of quantitative line analysis.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - ProcessingMethod (int):
                0 : None, 1 : Speed, 2 : Precise
                The kind of processing method. 
                Speed/ Precise are supported.
    
            - StandardDataType (int):
                0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
                The NORM/ COMMON/ USER are supported.
    
            - UserCategoryName (str):
                The category name of standard data. 
                If the StandardDataType is USER, this category name is available. 
                
            - CorrectionType (int):
                0 : None, 1 : ZAF, 2 : PRZ, 3 : Cliff-Lorimer, 4 : ZETA
                ZAF/ PRZ/ Cliff-Lorimer/ ZETA are supported.
    
            - ConversionType (int):
                0 : None, 1 : Metal, 2 : Oxide, 3 : Compound
                Metal/ Oxide are available
    
            - OxideCation (int):
                This is a cation number of oxide. 
                This is available in oxide mode as conversion type.
    
            
            - EnableSumPeakRemoval (bool):
                true : Enable, false : Disable

    Example:
        >>> body = QuantitativeLineParam(method = 0,
                                         datatype = 0,
                                         name="",
                                         correctiontype=3,
                                         conversiontype=1,
                                         oxidecation=1,
                                         enablesumpeakremoval=True).__dict__
        >>> set_quantitative_line_analysis_settings(body)
    Return: 
        dict:
        similar to get_quantitative_line_analysis_settings()
    '''
    url = _uri+'/Analysis/QuantitativeLineSettings'
    param = interface._body_check(param)
    return _connector.post(url, param)


def execute_quantitative_line_analysis(param):
    '''
    This interface create quantitative data of line analysis.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
            - Elements (ElementsKey):
                This is two dimensional array. This is a list of element that contains elemental number and Line. 
                The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
                'Default' is selecting default line automatically.
            - TargetDetector (int):
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                0=Total, 
                1=FirstDetector, 
                2=SecondDetector, 
                3=ThirdDetector, 
                4=ForthDetector
        
    Return: 
        dict:
        - Message (str): 
            This is a free text from EDS system.
        - DataIDs (list):
            The array of ID. The length of array is the same as length of element list.
        - Result (str):
            'OK' : success, 'Fail' : failure

    '''
    url = _uri+'/Analysis/CreateQuantitativeLine'
    param = interface._body_check(param)
    return _connector.post(url, param)


def create_count_map(param):
    '''
    This interface create gross count mapping data.

    Args:
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
            - Elements (ElementsKey):
                This is two dimensional array. This is a list of element that contains elemental number and Line. 
                The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
                'Default' is selecting default line automatically.
            - TargetDetector (int): 
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                0=Total, 
                1=FirstDetector, 
                2=SecondDetector, 
                3=ThirdDetector, 
                4=ForthDetector
            
    Return: 
        dict:
        - Message (str) :
            This is a free text from EDS system.
        - DataIDs (list):
            The array of ID. The length of array is the same as length of element list.
        - Result (str):
            'OK' : success, 'Fail' : failure

    '''
    url = _uri+'/Analysis/CreateCountMap'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_net_count_map_analysis_settings():
    '''
    This interface can get the settings of net count mapping.

    Return: 
        dict:
        - PixelWidth (int):
            The width of output data. The unit is pixel.
            This can be selected from the list [64, 128, 256, 512, 1024, 2048, 4096] and should be less than original size.

        - PixelHeight (int):
            The height of output data. The unit is pixel.
            This can be selected from the list [64, 128, 256, 512, 1024, 2048, 4096] and should be less than original size.

        - ProcessingMethod (int):
            0 : None, 1 : Speed, 2 : Precise
            The kind of processing method. 
            Speed/ Precise are supported.

        - StandardDataType (int):
            0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
            The NORM/ COMMON/ USER are supported.

    Example:
        >>> get_net_count_map_analysis_settings()
        {
            'PixelWidth' : 128,
            'PixelHeight' : 128,
            'ProcessingMethod' : 0,
            'StandardDataType' : 0,
        }
    '''
    url = _uri+'/Analysis/NetCountMapSettings'
    return _connector.get(url)


def set_net_count_map_analysis_settings(param):
    '''
    This interface can set the settings of net count mapping.

    Args:
        param (dict):
            The following describes the keys to be set.
            
            - PixelWidth (int):
                The width of output data. The unit is pixel.
                This can be selected from the list [64, 128, 256, 512, 1024, 2048, 4096] and should be less than original size.
    
            - PixelHeight (int):
                The height of output data. The unit is pixel.
                This can be selected from the list [64, 128, 256, 512, 1024, 2048, 4096] and should be less than original size.
    
            - ProcessingMethod (int):
                0 : None, 1 : Speed, 2 : Precise
                The kind of processing method. 
                Speed/ Precise are supported.
    
            - StandardDataType (int):
                0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
                The NORM/ COMMON/ USER are supported.

    Return: 
        dict:
        simliar to 'get_net_count_map_analysis_settings()'
    '''
    url = _uri+'/Analysis/NetCountMapSettings'
    param = interface._body_check(param)
    return _connector.post(url, param)


def create_net_count_map(param):
    '''
    This interface create net count mapping data.

    Args:
        param (dict):
            The following describes the keys to be set.

            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
            - Elements (ElementsKey):
                This is two dimensional array. This is a list of element that contains elemental number and Line. 
                The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
                'Default' is selecting default line automatically.
            - TargetDetector (int):
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                0=Total, 
                1=FirstDetector, 
                2=SecondDetector, 
                3=ThirdDetector, 
                4=ForthDetector
        
    Return: 
        dict:
        - Message (str) :
            This is a free text from EDS system.
        - DataIDs (list):
            The array of ID. The length of array is the same as length of element list.
        - Result (str):
            'OK' : success, 'Fail' : failure
    '''
    url = _uri+'/Analysis/CreateNetCountMap'
    param = interface._body_check(param)
    return _connector.post(url, param)


def get_quantitative_map_analysis_settings():
    '''
        This interface set the settings of quantitative mapping.

    Return: 
        dict:
        - PixelWidth (int):
            The width of output data. The unit is pixel.
            This can be selected from the list [64, 128, 256, 512, 1024, 2048, 4096] and should be less than original size.

        - PixelHeight (int):
            The height of output data. The unit is pixel.
            This can be selected from the list [64, 128, 256, 512, 1024, 2048, 4096] and should be less than original size.

        - ProcessingMethod (int):
            0 : None, 1 : Speed, 2 : Precise
            The kind of processing method. 
            Speed/ Precise are supported.

        - StandardDataType (int):
            0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
            The NORM/ COMMON/ USER are supported.

        - UserCategoryName (str):
            The category name of standard data. 
            If the StandardDataType is USER, this category name is available. 
            
        - CorrectionType (int):
            0 : None, 1 : ZAF, 2 : PRZ, 3 : Cliff-Lorimer, 4 : ZETA
            ZAF/ PRZ/ Cliff-Lorimer/ ZETA are supported.

        - ConversionType (int):
            0 : None, 1 : Metal, 2 : Oxide, 3 : Compound
            Metal/ Oxide are available

        - EnableSumPeakRemoval (bool):
            true : Enable, false : Disable
            
    Example:
        >>> get_quantitative_map_analysis_settings()
        {
            'PixelWidth' : 128,
            'PixelHeight' : 128,
            'ProcessingMethod' : 0,
            'StandardDataType' : 0,
            'UserCategoryName' : '',
            'CorrectionType' : 3,
            'ConversionType' : 1,
            'EnableSumPeakRemoval' : True,
        }
    '''
    url = _uri+'/Analysis/QuantitativeMapSettings'
    return _connector.get(url)


def set_quantitative_map_analysis_settings(param):
    '''
    This interface set the settings of quantitative mapping.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - PixelWidth (int):
                The width of output data. The unit is pixel.
                This can be selected from the list [64, 128, 256, 512, 1024, 2048, 4096] and should be less than original size.
    
            - PixelHeight (int):
                The height of output data. The unit is pixel.
                This can be selected from the list [64, 128, 256, 512, 1024, 2048, 4096] and should be less than original size.
    
            - ProcessingMethod (int):
                0 : None, 1 : Speed, 2 : Precise
                The kind of processing method. 
                Speed/ Precise are supported.
    
            - StandardDataType (int):
                0 : None, 1 : DEFSPC, 2 : NORM, 3 : COMMON, 4 : USER, 5 : External
                The NORM/ COMMON/ USER are supported.
    
            - UserCategoryName (str):
                The category name of standard data. 
                If the StandardDataType is USER, this category name is available. 
                
            - CorrectionType (int):
                0 : None, 1 : ZAF, 2 : PRZ, 3 : Cliff-Lorimer, 4 : ZETA
                ZAF/ PRZ/ Cliff-Lorimer/ ZETA are supported.
    
            - ConversionType (int): 
                0 : None, 1 : Metal, 2 : Oxide, 3 : Compound
                Metal/ Oxide are available
    
            - EnableSumPeakRemoval (bool):
                true : Enable, false : Disable

    Return: 
        dict:
        * similar to get_quantitative_map_analysis_settings()
    '''
    url = _uri+'/Analysis/QuantitativeMapSettings'
    param = interface._body_check(param)
    return _connector.post(url,param)


def create_quantitative_map(param):
    '''
    This interface create quantitative mapping data.

    Args: 
        param (dict):
            The following describes the keys to be set.
            
            - TargetDataID (str):
                Usually, This ID will be get from returned value from 'StartAcquisition'. 
                    
            - Elements (ElementsKey):
                This is two dimensional array. This is a list of element that contains elemental number and Line. 
                The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
                'Default' is selecting default line automatically.
                    
            - TargetDetector int:
                This parameter select a target detector.
                If 0 is specified, the target data will be a integrated data.
                
                0=Total, 
                1=FirstDetector, 
                2=SecondDetector, 
                3=ThirdDetector, 
                4=ForthDetector
        
    Return: 
        dict:
        Output in dict type. The explanation of the output keys is as follows.
        
        - Message (str) :
            This is a free text from EDS system.
        - DataIDs (list):
            The array of ID. The length of array is the same as length of element list.
        - Result (str):
            'OK' : success, 'Fail' : failure
    '''
    url = _uri+'/Analysis/CreateQuantitativeMap'
    param = interface._body_check(param)
    return _connector.post(url, param)



# def get_map_data_ids(param):
#     '''
#     Summary:
#         This interface can get map data IDs.

#     Args: dict
#         - TargetDataID: (str)
#             Usually, This ID will be get from returned value from 'StartAcquisition'. 
#             ex) 'xxxx-xxxx-xxxx-xxxx'
#         - Elements: (ElementsKey)
#             This is two dimensional array. This is a list of element that contains elemental number and Line. 
#             The list of Line : 'None', 'K', 'L', 'M', 'N', 'O' , 'Default'
#             'Default' is selecting default line automatically.
#             ex) [
#             [ 'ElementalNumber' : 8, 'Line' : 'K'],
#             [ 'ElementalNumber' : 10, 'Line' : 'L']
#             ].
#         - TargetDetector: int
#             This parameter select a target detector.
#             If 0 is specified, the target data will be a integrated data.
            
#             0=Total, 
#             1=FirstDetector, 
#             2=SecondDetector, 
#             3=ThirdDetector, 
#             4=ForthDetector
        
#     Return: dict
#         - Message: (str) 
#             This is a free text from EDS system.
#         - DataIDs: (str)
#             The array of ID. The length of array is the same as length of element list.
#             ex) ['aaaa-aaaa-aaaa-aaaa', 'bbbb-bbbb-bbbb-bbbb', 'cccc-cccc-cccc-cccc']
#         - Result: (str)
#             'OK' : success, 'Fail' : failure
#         (ex.)
#         {
#             'Message' : 'This is a free text from EDS system.',
#             'DataIDs' :['aaaa-aaaa-aaaa-aaaa', 'bbbb-bbbb-bbbb-bbbb','cccc-cccc-cccc-cccc'],
#             'Result': 'OK'
#         }
#     '''
#     url = _uri+'/Analysis/MapDataIDs'
#     return _connector.post(url, interface.SpectrumAnalysis(param))

