# -*- coding: utf-8 -*-
"""
Created on Mon Dec 18 14:03:07 2023

@author: dmaekawa
"""
import os 
from pathlib import Path
# import uuid

from PyJEM.filesystem import FileManager


def check_communication():
    return __getter("check_communication")
       
def create_count_map(body):
    return __make_idlist_by_elements("create_count_map",body)
    
def create_net_count_map(body):
    return __make_idlist_by_elements("create_net_count_map",body)

def create_quantitative_map(body):
    return __make_idlist_by_elements("create_quantitative_map",body)

def execute_autoqualitative_analysis(body):
    return __getter("execute_autoqualitative_analysis")
    
def execute_count_line_analysis(body):
    return __make_idlist_by_elements("execute_count_line_analysis",body)
    
def execute_net_count_line_analysis(body):
    return __make_idlist_by_elements("execute_net_count_line_analysis",body)

def execute_quantitative_line_analysis(body):
    return __make_idlist_by_elements("execute_quantitative_line_analysis",body)

def execute_quantitative_spectrum_analysis(body):
    return __make_idlist_by_elements("execute_quantitative_spectrum_analysis",body)
    
def extract_area_spectrum(body):
    return __getter("extract_area_spectrum")

def extract_line_spectrum(body):
    return __getter("extract_line_spectrum")

def get_acquisition_settings():
    return __getter("get_acquisition_settings")
    
def get_acquisition_status():
    return __getter("get_acquisition_status")

def get_analysis_settings():
    return __getter("get_analysis_settings")
    
def get_analysis_status():
    return __getter("get_analysis_status")

def get_analyzer_settings():
    return __getter("get_analyzer_settings")

def get_analyzer_status():
    return __getter("get_analyzer_status")

def get_config():
    return __getter("get_config")

def get_detector_configuration():
    return __getter("get_detector_configuration")

def get_detector_status():
    return __getter("get_detector_status")

def get_net_count_line_analysis_settings():
    return __getter("get_net_count_line_analysis_settings")

def get_net_count_map_analysis_settings():
    return __getter("get_net_count_map_analysis_settings")

def get_quantitative_line_analysis_settings():
    return __getter("get_quantitative_line_analysis_settings")

def get_quantitative_map_analysis_settings():
    return __getter("get_quantitative_map_analysis_settings")

def get_quantitative_spectrum_analysis_settings():
    return __getter("get_quantitative_spectrum_analysis_settings")

def get_specification():
    return __getter("get_specification")

def reset_detector():
    return __getter("reset_detector")

def set_acquisition_settings(body:dict):
    return __setter("get_acquisition_settings",body)

def set_analyzer_settings(body):
    return body

def set_detector_status(body:dict):
    return __setter("get_detector_status", body)

def set_net_count_line_analysis_settings(body):
    return __getter("set_net_count_line_analysis_settings")

def set_net_count_map_analysis_settings(body):
    return __setter("set_net_count_map_analysis_settings", body)

def set_quantitative_line_analysis_settings(body):
    return __setter("set_quantitative_line_analysis_settings", body)

def set_quantitative_map_analysis_settings(body):
    return __setter("set_quantitative_map_analysis_settings", body)

def set_quantitative_spectrum_analysis_settings(body):
    return __setter("set_quantitative_spectrum_analysis_settings", body)

def start_acquisition():
    return __getter("start_acquisition")

def stop_acquisition():
    return __getter("stop_acquisition")


###### bynary ########
def get_spectrum_data(body:dict):
    data = DummyImage()
    return data.get_spectrum_image()
    
def get_map_data(param):
    data = DummyImage()
    return data.get_map_image()

def get_multiple_line_data(param):
    data = DummyImage()
    return data.get_multi_line()

def get_multiple_spectrum_data(param):
    data = DummyImage()
    return data.get_multi_sepctrum()




##### private ######
def __getter(func):
    _= DummyData()
    return _.get(func)

def __setter(fmt, body):
    data_fmt= __getter(fmt)
    for k,v in data_fmt.items():
        if k in body:
            data_fmt[k]= body[k]
    return data_fmt    

def __make_idlist_by_elements(name, body):
    """
    指定した元素ごとの結果を取得するメソッドのための中間関数
    """
    dummydata = __getter(name)
    ids = body.get("Elements")
    if ids==None:
        dummydata["DataIDs"] = []
        dummydata["Result"] = "Fail"
    else:
        count = len(ids)
        dummydata["DataIDs"] = ["00000000-0000-0000-0000-000000000000"] * count
    return dummydata


class _DummyBase:
    _cls = None
    def __init__(self):
        path = Path(__file__).parents[1]
        self._data_file = os.path.join(path, "resources\eds.json")
        self._spectrum_image_file = os.path.join(path, "resources\eds_spectrum_image.bin")
        self._map_image_file = os.path.join(path, "resources\eds_map_image.bin")
        self._multi_line_file = os.path.join(path, "resources\multi_line.bin")
        self._multiple_spectrum_file = os.path.join(path, "resources\multiple_spectrum.bin")
        
        # dumyデータファイルの管理
        self.data_filemanager = FileManager(self.data_file)
        # self.binary_filemanager = FileManager(self.binary_file)
    
    def __new__(cls):
        "インスタンスはシングルトン"
        if cls._cls==None:
            cls._cls = super().__new__(cls)
        return cls._cls        
        
    def read(self):
        return self.data_filemanager.read()
    
    @property
    def data_file(self):
        return self._data_file
    
    @property
    def spectrum_image_file(self):
        return self._spectrum_image_file
    
    @property
    def map_image_file(self):
        return self._map_image_file
    
    @property
    def multi_line_file(self):
        return self._multi_line_file
    
    @property
    def multiple_spectrum_file(self):
        return self._multiple_spectrum_file
    
class DummyImage(_DummyBase):
       
    def __new__(cls):
        return super().__new__(cls)

    def get_spectrum_image(self):
        "指定した関数の戻り値をダミーデータファイルから返す"
        with open(self.spectrum_image_file, "rb") as f:
            bdata = f.read()
        return bdata
    
    def get_map_image(self):
        with open(self.map_image_file, "rb") as f:
            bdata = f.read()
        return bdata
    
    def get_multi_line(self):
        with open(self._multi_line_file, "rb") as f:
            bdata = f.read()
        return bdata
    
    def get_multiple_spectrum_data(self):
        with open(self.multiple_spectrum_file, "rb") as f:
            bdata = f.read()
        return bdata
        

class DummyData(_DummyBase):
    def __new__(cls):
        return super().__new__(cls)
    
    def get(self,func):
        "指定した関数の戻り値をダミーデータファイルから返す"
        return self.origin_data.get(func,"")
    
    @property
    def origin_data(self):
        return self.read()
    
    
    