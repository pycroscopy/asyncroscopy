# -*- coding: utf-8 -*-
"""
Created on Mon Dec 18 14:02:24 2023

@author: dmaekawa
"""
from . import function
from .function import *

