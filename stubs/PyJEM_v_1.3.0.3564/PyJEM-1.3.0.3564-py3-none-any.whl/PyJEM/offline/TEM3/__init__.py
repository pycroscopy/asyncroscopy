# -*- coding: utf-8 -*-

from .apt3 import *
from .camera3 import *
from .def3 import *
from .detector3 import *
from .eos3 import *
from .feg3 import *
from .filter3 import *
from .gun3 import *
from .ht3 import *
from .lens3 import *
from .mds3 import *
from .scan3 import *
from .stage3 import *
from .vacuum3 import *
from .nitrogen3 import *


__status = False
def connect():
    __status = True
    return __status
    
def get_connect_status():
    return __status





class TEM3Error(Exception):
    pass

