# -*- coding: utf-8 -*-
"""
This package is used to control the detector functions of the SigthX.
s

Caution:
    This package supports some functions published by the SigthX.
    Therefore, this package cann't be used under the following conditions.

    - The SigthX is not configured in the network.
    - The SigthX is not running. 
"""

# from . import function
from .function import *

