"""
AutoScript toolkit component providing computer vision functions.
"""

import numpy
import PIL.ImageDraw as PilDraw
import PIL.Image as PilImage

from typing import Optional, List, Iterable, Sequence
from numbers import Real
from warnings import warn

from autoscript_core.serialization import ReprAttr
from autoscript_tem_microscope_client.enumerations import ImageDataEncoding, RegionCoordinateSystem
from autoscript_tem_microscope_client._structures_adorned_image import convert_pil_image_to_data, normalize_data
from autoscript_tem_microscope_client.structures import Point, Rectangle, AdornedImage, AdornedSpectrum
from autoscript_tem_toolkit.template_matchers import DEFAULT_TEMPLATE_MATCHER, TemplateMatcher

from . import _scale_bar_renderer as scale_bar_renderer
from . import _primitives_renderer as primitives_renderer
from . import _draw_utilities as draw_utilities
from . import user_interface

__all__ = ["FeatureLocation", "locate_feature", "cut_image", "plot_match", "plot_image", "plot_images", "plot_spectrum", "plot_spectra",
           "add_scale_bar", "stretch_histogram", "draw_point", "draw_points", "draw_rectangle", "draw_rectangles", "select_point",
           "select_points", "select_rectangle", "select_rectangles", "average_images"]


class FeatureLocation:
    """
    FeatureLocation contains various information about a feature located in an image.
    """

    def __init__(self, confidence: Optional[Real] = None,
                 center_in_pixels: Optional[draw_utilities.PointLike] = None,
                 center_in_meters: Optional[draw_utilities.PointLike] = None,
                 shift_in_pixels: Optional[draw_utilities.PointLike] = None,
                 shift_in_meters: Optional[draw_utilities.PointLike] = None):
        self._confidence = confidence

        if isinstance(center_in_pixels, (list, tuple)):
            center_in_pixels = Point.create_from(center_in_pixels)
        if isinstance(center_in_meters, (list, tuple)):
            center_in_meters = Point.create_from(center_in_meters)
        if isinstance(shift_in_pixels, (list, tuple)):
            shift_in_pixels = Point.create_from(shift_in_pixels)
        if isinstance(shift_in_meters, (list, tuple)):
            shift_in_meters = Point.create_from(shift_in_meters)

        self._center_in_pixels = center_in_pixels
        self._center_in_meters = center_in_meters
        self._shift_in_pixels = shift_in_pixels
        self._shift_in_meters = shift_in_meters

    @property
    def confidence(self) -> Optional[float]:
        return self._confidence

    @property
    def center_in_pixels(self) -> Optional[Point]:
        return self._center_in_pixels

    @property
    def center_in_meters(self) -> Optional[Point]:
        return self._center_in_meters

    @property
    def shift_in_pixels(self) -> Optional[Point]:
        return self._shift_in_pixels

    @property
    def shift_in_meters(self) -> Optional[Point]:
        return self._shift_in_meters

    def print_all_information(self):
        if self.confidence is not None:
            print(f"Confidence [%]: {self.confidence:.2f}")
        if self.center_in_pixels is not None:
            print(f"Center [px]: ({self.center_in_pixels[0]:.4g}, {self.center_in_pixels[1]:.4g})")
        if self.center_in_meters is not None:
            print(f"Center [m]: ({self.center_in_meters[0]:.4g}, {self.center_in_meters[1]:.4g})")
            print(f"Center [µm]: ({self.center_in_meters[0] * 1e6:.4f}, {self.center_in_meters[1] * 1e6:.4f})")
        if self.shift_in_pixels is not None:
            print(f"Shift [px]: ({self.shift_in_pixels[0]:.4g}, {self.shift_in_pixels[1]:.4g})")
        if self.shift_in_meters is not None:
            print(f"Shift [m]: ({self.shift_in_meters[0]:.4g}, {self.shift_in_meters[1]:.4g})")
            print(f"Shift [µm]: ({self.shift_in_meters[0] * 1e6:.4f}, {self.shift_in_meters[1] * 1e6:.4f})")

    def __repr__(self):
        repr_attrs = (
            ReprAttr("confidence", "%.8g"),
            ReprAttr("center_in_pixels", "%s"),
            ReprAttr("center_in_meters", "%s"),
            ReprAttr("shift_in_pixels", "%s"),
            ReprAttr("shift_in_meters", "%s"))

        return self._generate_repr(repr_attrs)

    def _generate_repr(self, repr_attrs):
        """
        Generates object representation string according to the given representative attribute set.

        :param repr_attrs: Set of representative attributes in a form of ReprAttr object array.
        :return: Object representation string suitable for object __repr__() implementation.
        """

        repr_attr_strings = []
        for repr_attr in repr_attrs:
            attr_value = getattr(self, repr_attr.attr_name)
            if attr_value is not None:
                repr_attr_strings.append(repr_attr.attr_name + "=" + repr_attr.format_string % attr_value)

        repr_string = "%s(%s)" % (type(self).__name__, ', '.join(repr_attr_strings))
        return repr_string


def locate_feature(image: AdornedImage, feature_template: AdornedImage,
                   template_matcher: TemplateMatcher = DEFAULT_TEMPLATE_MATCHER,
                   original_feature_center: draw_utilities.PointLike = None) -> FeatureLocation:
    """
    Locates a feature according to the given template in the given image.

    :param image: Image to be searched for feature.
    :param feature_template: Template of the feature to be located.
    :param template_matcher: Template matcher to be used when matching template against the searched image.
    :param original_feature_center: Center of the original feature location, in pixels. The information is used for
    shift calculation.

    :return: Structure containing various information about feature location. Values in meters are only available
    if the image contains pixel size metadata information.
    """

    # Perform feature template matching using the selected template matcher
    match = template_matcher.match(image, feature_template)

    image_pixel_size = None
    center_in_meters = None
    shift_in_pixels = None
    shift_in_meters = None

    # Get size of a single image pixel in meters if the information are valid and in correct units
    try:
        binary_result = image.metadata.binary_result

        if binary_result.pixel_size_x_unit.name == "m" and binary_result.pixel_size_y_unit.name == "m" and \
                binary_result.pixel_size_x_unit.prefix_power == 1 and binary_result.pixel_size_y_unit.prefix_power == 1:
            image_pixel_size = image.metadata.binary_result.pixel_size
    except AttributeError:
        # Attribute error means that some metadata are not available, ignore this
        pass

    # Calculate center in meters when possible
    if image_pixel_size is not None:
        center_in_meters = Point(match.center.x * image_pixel_size.x, match.center.y * image_pixel_size.y)

    # Calculate shift when possible
    if original_feature_center is not None:
        original_feature_center_in_pixels = (original_feature_center[0], original_feature_center[1])
        shift_in_pixels = Point(match.center.x - original_feature_center_in_pixels[0],
                                match.center.y - original_feature_center_in_pixels[1])

        # Calculate shift in meters when possible
        if image_pixel_size is not None:
            shift_in_meters = Point(shift_in_pixels[0] * image_pixel_size.x, shift_in_pixels[1] * image_pixel_size.y)

    return FeatureLocation(match.score, match.center, center_in_meters, shift_in_pixels, shift_in_meters)


def cut_image(image: draw_utilities.ImageLike,
              top_left: draw_utilities.PointLike = None, bottom_right: draw_utilities.PointLike = None,
              center: draw_utilities.PointLike = None, size: draw_utilities.PointLike = None,
              relative_center: draw_utilities.PointLike = None,
              relative_size: draw_utilities.PointLike = None) -> draw_utilities.ImageLike:
    """
    Cuts out a part of the given image according to the given target area definition.

    Please note that only the following combinations of parameters are valid: top left and bottom right,
    center and size, or relative center and relative size.

    The method can accept AdornedImage or numpy.ndarray as an input image. The output image is in the same format at
    the input.

    :param image: Image to cut a part from.
    :param top_left: Top left point of the cut area, in pixels.
    :param bottom_right: Bottom right point of the cut area, in pixels.
    :param center: Center of the cut area, in pixels.
    :param size: Size of the cut area, in pixels.
    :param relative_center: Center of the cut area, in relative coordinates from 0.0 to 1.0.
    :param relative_size: Size of the cut area, in relative coordinates from 0.0 to 1.0.

    :return: Cut taken out in the same format as the input image.
    """

    if isinstance(image, AdornedImage):
        adorned_image_mode = True
        image_width = image.width
        image_height = image.height
    else:
        adorned_image_mode = False
        image_width = image.shape[1]
        image_height = image.shape[0]

    # Coordinates of the cut result
    # x0, y0 -> top left corner of the cut
    # x1, y1 -> bottom right corner of the cut
    x0 = None
    x1 = None
    y0 = None
    y1 = None

    if top_left is not None and bottom_right is not None:
        x0 = int(top_left[0])
        x1 = int(bottom_right[0])
        y0 = int(top_left[1])
        y1 = int(bottom_right[1])
    elif center is not None and size is not None:
        (x0, y0, x1, y1) = _get_rectangle_points(center, size)
    elif relative_center is not None and relative_size is not None:
        center = (relative_center[0] * image_width, relative_center[1] * image_height)
        size = (relative_size[0] * image_width, relative_size[1] * image_height)

        (x0, y0, x1, y1) = _get_rectangle_points(center, size)

    if x0 is None or x1 is None or y0 is None or y1 is None:
        raise ValueError("Cut area could not be properly identified from the given parameters.")

    if y0 >= y1 or x0 >= x1:
        raise ValueError("Cut area can't have zero size in both dimensions.")

    if x0 < 0 or y0 < 0 or x1 > image_width or y1 > image_height:
        raise ValueError("Cut area must be inside the image.")

    if adorned_image_mode:
        return AdornedImage(image.data[y0:y1, x0:x1], image.metadata)
    else:
        return image[y0:y1, x0:x1]


def _get_rectangle_points(center, size) -> (int, int, int, int):
    x0 = int(center[0] - size[0] / 2)
    y0 = int(center[1] - size[1] / 2)
    x1 = x0 + int(size[0])
    y1 = y0 + int(size[1])

    return x0, y0, x1, y1


def plot_match(image: AdornedImage, template: AdornedImage, match_center: draw_utilities.PointLike):
    warn("The function 'plot_match' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    user_interface.plot_match(image, template, match_center)


def plot_image(image: AdornedImage, label: str = None):
    warn("The function 'plot_image' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    user_interface.plot_image(image, label)


def plot_images(images: Sequence[AdornedImage], labels: Sequence[str] = None):
    warn("The function 'plot_images' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    user_interface.plot_images(images, labels)


def plot_spectrum(spectrum: AdornedSpectrum, label: str = None):
    warn("The function 'plot_spectrum' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    user_interface.plot_spectrum(spectrum, label)


def plot_spectra(spectra: List[AdornedSpectrum], labels: List[str] = None):
    warn("The function 'plot_spectra' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    user_interface.plot_spectra(spectra, labels)


def add_scale_bar(image: AdornedImage) -> AdornedImage:
    """
    Adds a scale bar to the lower right corner of the image.

    :param image: Image to which a scale bar is to be added.
    :return: Image with the scale bar added.
    """

    draw_utilities.check_image_size(image)

    # Make a copy of the given image. We need to use PIL since opencv doesn't support unicode text draw
    pil_image = PilImage.fromarray(image.data)

    # Workaround for PIL's inability to draw text properly to 16-bit images
    # This bug was fixed in Pillow 8.4.0 (Consider I;16 pixel size when drawing text)
    # https://github.com/python-pillow/Pillow/blob/main/CHANGES.rst#840-2021-10-15
    # Update after PIL updated to 9.0.0:
    # PIL can draw text to 16-bit images now, but the color values are wrong, keeping the workaround as is
    if image.bit_depth == 16 and image.encoding == ImageDataEncoding.UNSIGNED:
        # Draw the scale bar on 8-bit image instead
        scale_bar_pil_image = PilImage.new("L", pil_image.size)
        pil_draw = PilDraw.Draw(scale_bar_pil_image)

        # Get colors, but no color can be zero - zero is reserved to mask
        mask_color = 0
        colors = draw_utilities.get_colors_from_type(numpy.uint8, non_zero_colors=True)
        scale_bar_renderer.draw_scale_bar(pil_draw, image.width, image.height, image.metadata, colors)

        image_array = numpy.array(pil_image)
        scale_bar_image_array = numpy.array(scale_bar_pil_image)

        # Scale bar image values need to be converted to 16 bit
        scaling_factor = 255
        scale_bar_image_array = scale_bar_image_array * (max(numpy.max(image_array), scaling_factor) / scaling_factor)
        scale_bar_image_array = scale_bar_image_array.astype(image.data.dtype)

        # Create a mask for the scale bar image and set all non-black colors to 100% (0 -> 0%, 255 -> 100%).
        scale_bar_mask_array = numpy.array(scale_bar_image_array)
        scale_bar_mask_array[scale_bar_mask_array != mask_color] = 255

        # Paste the scale bar image into the image by choosing only te pixels where mask has higher value than mask
        image_array[scale_bar_mask_array > mask_color] = scale_bar_image_array[scale_bar_mask_array > mask_color]
    else:
        pil_draw = PilDraw.Draw(pil_image)
        colors = draw_utilities.get_colors_from_image(image)

        scale_bar_renderer.draw_scale_bar(pil_draw, image.width, image.height, image.metadata, colors)
        image_array = convert_pil_image_to_data(pil_image)

        # PIL converts int16 images into int32 without data loss as a workaround for not supporting int16
        # We need to convert it back so that the image format doesn't change
        if image.bit_depth == 16 and image.encoding == ImageDataEncoding.SIGNED:
            image_array = image_array.astype(numpy.int16)

    return AdornedImage(image_array, image.metadata)


def stretch_histogram(image: AdornedImage, outlier_threshold: Optional[Real] = 0.999) -> AdornedImage:
    """
    Normalizes and stretches the histogram of the given grayscale image. Removes outliers if the threshold is provided.

    :param image: Input image.
    :param outlier_threshold: Threshold for outlier filtering. The value must be in (0.5, 1) interval.
        If None, no filtering is used. Default value is 0.999.
    :return: Image with the stretched histogram.
    """

    if image.encoding in (ImageDataEncoding.RGB, ImageDataEncoding.BGR):
        raise ValueError("Only grayscale images are supported.")

    normalized_data = normalize_data(image.data, outlier_threshold)
    stretched_data = normalized_data * (2 ** image.bit_depth - 1)

    if image.encoding == ImageDataEncoding.SIGNED:
        stretched_data = stretched_data - (2 ** image.bit_depth // 2)

    stretched_data = stretched_data.astype(image.data.dtype)

    return AdornedImage(stretched_data, image.metadata)


def draw_point(image: AdornedImage, point: draw_utilities.PointLike) -> AdornedImage:
    """
    Draws a point in the given image.

    :param image: Input image.
    :param point: Point coordinates.
    :return: A new image.
    """

    draw_utilities.check_image_size(image)

    image_copy = numpy.array(image.data)
    colors = draw_utilities.get_colors_from_image(image)
    primitives_renderer.draw_point(image_copy, point, image.width, image.height, colors)

    return AdornedImage(image_copy, image.metadata)


def draw_points(image: AdornedImage, points: Iterable[draw_utilities.PointLike]) -> AdornedImage:
    """
    Draws multiple points in the given image.

    :param image: Input image.
    :param points: Points coordinates.
    :return: A new image.
    """

    draw_utilities.check_image_size(image)

    image_copy = numpy.array(image.data)
    colors = draw_utilities.get_colors_from_image(image)

    for point in points:
        primitives_renderer.draw_point(image_copy, point, image.width, image.height, colors)

    return AdornedImage(image_copy, image.metadata)


def draw_rectangle(image: AdornedImage, rectangle: draw_utilities.RectangleLike) -> AdornedImage:
    """
    Draws a rectangle in the given image.

    :param image: Input image.
    :param rectangle: Rectangle coordinates.
    :return: A new image.
    """

    draw_utilities.check_image_size(image)

    image_copy = numpy.array(image.data)
    colors = draw_utilities.get_colors_from_image(image)
    primitives_renderer.draw_rectangle(image_copy, rectangle, image.width, image.height, colors)

    return AdornedImage(image_copy, image.metadata)


def draw_rectangles(image: AdornedImage, rectangles: Iterable[draw_utilities.RectangleLike]) -> AdornedImage:
    """
    Draws multiple rectangles in the given image.

    :param image: Input image.
    :param rectangles: Rectangles coordinates.
    :return: A new image.
    """

    draw_utilities.check_image_size(image)

    image_copy = numpy.array(image.data)
    colors = draw_utilities.get_colors_from_image(image)

    for rectangle in rectangles:
        primitives_renderer.draw_rectangle(image_copy, rectangle, image.width, image.height, colors)

    return AdornedImage(image_copy, image.metadata)


def select_point(image: AdornedImage) -> Optional[Point]:
    warn("The function 'select_point' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    return user_interface.select_point(image)


def select_points(image: AdornedImage) -> List[Point]:
    warn("The function 'select_points' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    return user_interface.select_points(image)


def select_rectangle(image: AdornedImage,
                     coordinate_system: str = RegionCoordinateSystem.PIXELS) -> Optional[Rectangle]:
    warn("The function 'select_rectangle' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    return user_interface.select_rectangle(image, coordinate_system, )


def select_rectangles(image: AdornedImage, coordinate_system: str = RegionCoordinateSystem.PIXELS) -> List[Rectangle]:
    warn("The function 'select_rectangles' is deprecated and will be removed in version 1.19", DeprecationWarning, stacklevel=2)
    return user_interface.select_rectangles(image, coordinate_system)


def average_images(images: List[AdornedImage]) -> AdornedImage:
    """
    Averages the pixel values of multiple images.

    :param images: List of images to average.
    :return: A new image with the averaged pixel values.
    """

    if len(images) <= 1:
        raise ValueError("At least two images are required.")

    width = images[0].width
    height = images[0].height

    data_type = images[0].data.dtype

    summed = numpy.zeros_like(images[0].data, dtype=numpy.int64)

    for image in images:
        if image.encoding == ImageDataEncoding.BGR or image.encoding == ImageDataEncoding.RGB:
            raise ValueError("Only grayscale images are supported.")

        if image.width != width or image.height != height:
            raise ValueError("Images must have the same dimensions.")

        if image.data.dtype != data_type:
            raise ValueError("Images must have the same encoding and bit depth.")

        summed += image.data

    data = (summed / len(images)).astype(data_type)
    return AdornedImage(data)
