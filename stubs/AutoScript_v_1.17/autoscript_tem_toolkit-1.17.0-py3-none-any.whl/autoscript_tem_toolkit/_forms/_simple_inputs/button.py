from typing import Callable, TypeVar

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QWidget, QPushButton

T = TypeVar('T')


class Button(QWidget):
    def __init__(self, name: str, func: Callable[[], T]):
        super().__init__()
        _button = QPushButton(name)
        _button.clicked.connect(func)
