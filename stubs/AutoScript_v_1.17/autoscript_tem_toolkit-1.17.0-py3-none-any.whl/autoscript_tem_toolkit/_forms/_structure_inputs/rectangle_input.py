from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QDoubleSpinBox, QHBoxLayout
from autoscript_tem_microscope_client._structures_shell import Rectangle
from autoscript_tem_toolkit._forms._simple_inputs.number_inputs import FloatInput
from autoscript_tem_toolkit._forms._text_label import TextLabel


class RectangleInput(QWidget):
    def __init__(self, label_text="Rectangle"):
        super().__init__()
        self._main_layout = QVBoxLayout(self)
        self._main_layout.setContentsMargins(0, 0, 0, 0)

        # Add top label
        self._label = QLabel(label_text)
        self._main_layout.addWidget(self._label)

        # Sub-layout for the inputs (with left margin for indentation)
        inputs_layout = QVBoxLayout()
        inputs_layout.setContentsMargins(20, 0, 0, 0)

        # Create labels and spin boxes
        self._left_label = TextLabel("Left:")
        self._left_label.setFixedWidth(40)

        self._left_spin = QDoubleSpinBox()
        self._left_spin.setRange(0, 10000)

        self._top_label = TextLabel("Top:")
        self._top_label.setFixedWidth(40)
        self._top_spin = QDoubleSpinBox()
        self._top_spin.setRange(0, 10000)

        self._width_label = TextLabel("Width:")
        self._width_label.setFixedWidth(40)
        self._width_spin = QDoubleSpinBox()
        self._width_spin.setRange(0, 10000)

        self._height_label = TextLabel("Height:")
        self._height_label.setFixedWidth(40)
        self._height_spin = QDoubleSpinBox()
        self._height_spin.setRange(0, 10000)

        # Layouts for grouping label + spin
        self._left_layout = self._make_input_row(self._left_label, self._left_spin)
        self._top_layout = self._make_input_row(self._top_label, self._top_spin)
        self._width_layout = self._make_input_row(self._width_label, self._width_spin)
        self._height_layout = self._make_input_row(self._height_label, self._height_spin)

        inputs_layout.addLayout(self._left_layout)
        inputs_layout.addLayout(self._top_layout)
        inputs_layout.addLayout(self._width_layout)
        inputs_layout.addLayout(self._height_layout)

        self._main_layout.addLayout(inputs_layout)

        self.setLayout(self._main_layout)

    @staticmethod
    def _make_input_row(label, spinbox):
        layout = QHBoxLayout()
        layout.addWidget(label)
        layout.addWidget(spinbox)
        return layout

    def get_value(self):
        return Rectangle(self._left_spin.value(), self._top_spin.value(),
                         self._width_spin.value(), self._height_spin.value())