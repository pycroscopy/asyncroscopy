from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout
from autoscript_tem_microscope_client.structures import EelsExposureSettings

from autoscript_tem_toolkit._forms._simple_inputs.number_inputs import FloatInput
from autoscript_tem_toolkit._forms._text_label import TextLabel


class EelsExposureSettingsInput(QWidget):
    def __init__(self, label_text: str  = "EELS exposure settings"):
        super().__init__()
        self._main_layout = QVBoxLayout(self)
        self._main_layout.setContentsMargins(0, 0, 0, 0)

        # Add top label
        self.label = TextLabel(label_text)
        self._main_layout.addWidget(self.label)

        # Sub-layout for the inputs (with left margin for indentation)
        self._inputs_layout = QVBoxLayout()
        self._inputs_layout.setContentsMargins(20, 0, 0, 0)

        self._exposure_time_label = TextLabel("Exposure time (s)")
        self._exposure_time_input = FloatInput("")
        self._exposure_time_layout = QHBoxLayout()
        self._exposure_time_layout.addWidget(self._exposure_time_label)
        self._exposure_time_layout.addWidget(self._exposure_time_input)

        self._drift_label = TextLabel("Drift tube energy offset (eV)")
        self._drift_input = FloatInput("")
        self._drift_layout = QHBoxLayout()
        self._drift_layout.addWidget(self._drift_label)
        self._drift_layout.addWidget(self._drift_input)

        self._inputs_layout.addLayout(self._exposure_time_layout)
        self._inputs_layout.addLayout(self._drift_layout)
        self._main_layout.addLayout(self._inputs_layout)
        self.setLayout(self._main_layout)

    def get_value(self):
        settings = EelsExposureSettings
        settings.exposure_time = self._exposure_time_input.get_value()
        settings.drift_tube_energy_offset = self._exposure_time_input.get_value()

        return settings
