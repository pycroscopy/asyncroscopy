from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QDoubleSpinBox, QHBoxLayout, QComboBox
from autoscript_tem_microscope_client.enumerations import RegionCoordinateSystem

from autoscript_tem_microscope_client.structures import Region

from .rectangle_input import RectangleInput


class RegionInput(QWidget):
    def __init__(self, label_text="Region"):
        super().__init__()
        self._main_layout = QVBoxLayout(self)
        self._main_layout.setContentsMargins(0, 0, 0, 0)

        # Add top label
        self.label = QLabel(label_text)
        self._main_layout.addWidget(self.label)

        # Sub-layout for the inputs (with left margin for indentation)
        self._inputs_layout = QVBoxLayout()
        self._inputs_layout.setContentsMargins(20, 0, 0, 0)

        self.coordinate_input = QComboBox()
        for system in RegionCoordinateSystem.get_all_items():
            self.coordinate_input.addItem(system)

        self.rectangle_input = RectangleInput()

        self._inputs_layout.addWidget(self.coordinate_input)
        self._inputs_layout.addWidget(self.rectangle_input)

        self._main_layout.addLayout(self._inputs_layout)

        self.setMinimumWidth(200)
        self.setLayout(self._main_layout)

    def get_value(self):
        rectangle = self.rectangle_input.get_value()
        return Region(self.coordinate_input.currentText(), rectangle)
