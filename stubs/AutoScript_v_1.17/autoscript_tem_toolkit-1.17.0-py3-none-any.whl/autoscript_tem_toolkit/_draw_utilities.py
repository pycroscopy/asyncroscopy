import math
import numpy
import numpy.typing as numpy_typing
from numbers import Integral

from typing import Union, NamedTuple, Tuple

from autoscript_tem_microscope_client.enumerations import ImageDataEncoding
from autoscript_tem_microscope_client.structures import Point, Rectangle, AdornedImage

Color = Union[Integral, Tuple[Integral, Integral, Integral]]
PointLike = Union[Point, list, Tuple[Integral, Integral]]
RectangleLike = Union[Rectangle, list, Tuple[Integral, Integral, Integral, Integral]]
ImageLike = Union[AdornedImage, numpy.ndarray]


class DrawColors(NamedTuple):
    """
    Pair of colors used for drawing into an image.
    """

    light_color: Color
    dark_color: Color


def get_colors_from_data(data: numpy.ndarray, three_channel_colors: bool = False) -> DrawColors:
    """
    Returns the draw colors deduced from the given image data.
    Note: if the image is empty and only has one color, the colors are deduced from the data type.
    """

    min_color = int(numpy.min(data))
    max_color = int(numpy.max(data))

    if max_color > min_color:
        if three_channel_colors:
            return DrawColors(light_color=_to_three_color_tuple(max_color),
                              dark_color=_to_three_color_tuple(min_color))
        else:
            return DrawColors(light_color=max_color,
                              dark_color=min_color)
    else:
        # Handle cases where the image is empty and only has one color
        type_info = numpy.iinfo(data.dtype)

        if three_channel_colors:
            return DrawColors(light_color=_to_three_color_tuple(type_info.max),
                              dark_color=_to_three_color_tuple(type_info.min))
        else:
            return DrawColors(light_color=type_info.max,
                              dark_color=max(type_info.min, 0))


def get_colors_from_type(numpy_type: numpy_typing.DTypeLike, three_channel_colors: bool = False,
                         non_zero_colors: bool = False) -> DrawColors:
    """
    Returns the draw colors deduced from the given data type.
    """

    type_info = numpy.iinfo(numpy_type)

    light_color = type_info.max
    dark_color = type_info.min + 1 if non_zero_colors and type_info.min == 0 else type_info.min

    if three_channel_colors:
        return DrawColors(light_color=_to_three_color_tuple(light_color),
                          dark_color=_to_three_color_tuple(dark_color))
    else:
        return DrawColors(light_color=light_color,
                          dark_color=dark_color)


def get_colors_from_image(image: AdornedImage) -> DrawColors:
    if image.encoding in (ImageDataEncoding.RGB, ImageDataEncoding.BGR):
        return get_colors_from_type(image.data.dtype, three_channel_colors=True)
    else:
        return get_colors_from_data(image.data)


def _to_three_color_tuple(color):
    return color, color, color


min_image_size = 256


def scale_size(image_size, size):
    """
    Scales the given size based on the image size and the minimum image size.
    """

    return math.ceil(size * image_size / min_image_size)


def scale_sizes(image_size, default_sizes):
    """
    Scales the given sizes based on the image size and the minimum image size.
    """

    return type(default_sizes)(*[scale_size(image_size, default_size) for default_size in default_sizes])


def check_image_size(image: AdornedImage):
    """
    Checks the size of the given image and raises an exception if it is too small.
    """

    if image.width < min_image_size or image.height < min_image_size:
        raise ValueError(f"Minimum size of the image is {min_image_size}x{min_image_size}.")
