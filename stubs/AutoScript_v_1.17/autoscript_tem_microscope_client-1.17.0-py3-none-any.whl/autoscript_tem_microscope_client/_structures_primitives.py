import numpy
from math import isclose
from numbers import Real
from typing import Optional, Union, List

from autoscript_core.serialization import ReprAttr
from ._structures_internal import iterable_arithmetic_tools as iterable_tools
from ._structures_internal.indexer_tools import StageIndexer, search_stage_indexers, Indexer, search_indexers
from ._structures_internal.xml.metadata_custom_xml_tools import OrderingInfo, insert_value_to_element, \
    get_value_from_element, get_attribute_from_element, insert_element, insert_attribute_to_element
from ._structures_internal.xml.metadata_xml_tools import XmlStructure
from . import _structures_shell as shell
from .enumerations import StageAxis


class StagePosition(shell.StagePosition):
    __slots__ = []

    def __init__(self, x: Real = None, y: Real = None, z: Real = None, a: Real = None, b: Real = None):
        super().__init__(x, y, z, a, b)

        self._property_indexers = [
            StageIndexer(0, StageAxis.X, StagePosition.x),
            StageIndexer(1, StageAxis.Y, StagePosition.y),
            StageIndexer(2, StageAxis.Z, StagePosition.z),
            StageIndexer(3, StageAxis.A, StagePosition.a),
            StageIndexer(4, StageAxis.B, StagePosition.b)
        ]

        self._repr_attrs = [ReprAttr("x"), ReprAttr("y"), ReprAttr("z"), ReprAttr("a"), ReprAttr("b")]

    def __repr__(self):
        return self._generate_repr(self._repr_attrs)

    def __len__(self):
        return len(self._property_indexers)

    def __getitem__(self, index: Union[int, str]) -> float:
        """
        Provides coordinate with the given index.

        The method is designed to behave in the same way as standard tuple/list indexer.
        """

        return search_stage_indexers(self._property_indexers, index, self.__class__.__name__).fget(self)

    def __setitem__(self, index: Union[int, str], value: Real):
        """
        Assigns the given value to the coordinate with the given index.

        The method is designed to behave in the same way as standard tuple/list indexer.
        """

        search_stage_indexers(self._property_indexers, index, self.__class__.__name__).fset(self, value)

    def __add__(self, other):
        """
        Adds the given position-like object or scalar value to this position and provides the result.

        :param other: Position-like object (with coordinates accessible by an index) or a scalar value.
        :return: New position created as a result of the addition.
        """

        return iterable_tools.add(self, other)

    def __radd__(self, other):
        """
        Adds the given position-like object or scalar value to this position and provides the result.

        :param other: Position-like object (with coordinates accessible by an index) or a scalar value.
        :return: New position created as a result of the addition.
        """

        return self.__add__(other)

    def __sub__(self, other):
        """
        Subtracts the given position-like object or scalar value from this position and provides the result.

        :param other: Position-like object (with coordinates accessible by an index) or a scalar value.
        :return: New position created as a result of the subtraction.
        """

        return iterable_tools.sub(self, other)

    def __rsub__(self, other):
        """
        Subtracts this position or scalar value from the given position-like object and provides the result.

        :param other: Position-like object (with coordinates accessible by an index) or a scalar value.
        :return: New position created as a result of the subtraction.
        """

        return iterable_tools.rsub(self, other)

    def __mul__(self, other):
        """
        Multiplies this position by the given scalar value and provides the result.

        :param other: Scalar value.
        :return: New position created as a result of the multiplication.
        """

        return iterable_tools.mul(self, other, False)

    def __rmul__(self, other):
        """
        Multiplies this position by the given scalar value and provides the result.

        :param other: Scalar value.
        :return: New position created as a result of the multiplication.
        """

        return self.__mul__(other)

    def __truediv__(self, other):
        """
        Divides this position by the given scalar value and provides the result.

        :param other: Scalar value.
        :return: New position created as a result of the division.
        """

        return iterable_tools.truediv(self, other)

    def __rtruediv__(self, other):
        """
        Divides given scalar value by this position and provides the result.

        :param other: Scalar value.
        :return: New position created as a result of the division.
        """

        return iterable_tools.rtruediv(self, other)

    def __floordiv__(self, other):
        """
        Divides (with floor) this position by the given scalar value and provides the result.

        :param other: Scalar value.
        :return: New position created as a result of the floor division.
        """

        return iterable_tools.floordiv(self, other)

    def __rfloordiv__(self, other):
        """
        Divides (with floor) given scalar value by this position and provides the result.

        :param other: Scalar value.
        :return: New position created as a result of the floor division.
        """

        return iterable_tools.rfloordiv(self, other)

    def __eq__(self, other):
        """
        Compares equality of all existing coordinates. Tests approximate equality with maximum tolerance of 1e-6.

        :param other: Position to compare to.
        :return: True if the positions are equal, otherwise False.
        """

        return iterable_tools.eq(self, other, False)

    @classmethod
    def convert_from(cls, value) -> 'Optional[StagePosition]':
        if value is None or isinstance(value, StagePosition):
            return value
        if isinstance(value, (list, tuple)):
            return StagePosition.create_from(value)
        raise TypeError(f"Cannot convert type {type(value).__name__} to StagePosition.")

    @classmethod
    def convert_list_from(cls, value) -> 'Optional[List[StagePosition]]':
        if value is None or isinstance(value, list) and all(isinstance(item, StagePosition) for item in value):
            return value
        if isinstance(value, (list, tuple)):
            return [StagePosition.create_from(item) for item in value]
        raise TypeError(f"Cannot convert type {type(value).__name__} to List[StagePosition].")


class StageVelocity(shell.StageVelocity):
    __slots__ = []

    def __init__(self, x: Real = None, y: Real = None, z: Real = None, a: Real = None, b: Real = None):
        super().__init__(x, y, z, a, b)

        self._property_indexers = [
            StageIndexer(0, StageAxis.X, StageVelocity.x),
            StageIndexer(1, StageAxis.Y, StageVelocity.y),
            StageIndexer(2, StageAxis.Z, StageVelocity.z),
            StageIndexer(3, StageAxis.A, StageVelocity.a),
            StageIndexer(4, StageAxis.B, StageVelocity.b)
        ]

        self._repr_attrs = [ReprAttr("x"), ReprAttr("y"), ReprAttr("z"), ReprAttr("a"), ReprAttr("b")]

    def __repr__(self):
        return self._generate_repr(self._repr_attrs)

    def __len__(self):
        return len(self._property_indexers)

    def __getitem__(self, index: Union[int, str]) -> float:
        """
        Provides coordinate with the given index.

        The method is designed to behave in the same way as standard tuple/list indexer.
        """

        return search_stage_indexers(self._property_indexers, index, self.__class__.__name__).fget(self)

    def __setitem__(self, index: Union[int, str], value: Real):
        """
        Assigns the given value to the coordinate with the given index.

        The method is designed to behave in the same way as standard tuple/list indexer.
        """

        search_stage_indexers(self._property_indexers, index, self.__class__.__name__).fset(self, value)

    def __add__(self, other):
        """
        Adds the given velocity-like object or scalar value to this velocity and provides the result.

        :param other: Velocity-like object (with coordinates accessible by an index) or a scalar value.
        :return: New velocity created as a result of the addition.
        """

        return iterable_tools.add(self, other)

    def __radd__(self, other):
        """
        Adds the given velocity-like object or scalar value to this velocity and provides the result.

        :param other: Velocity-like object (with coordinates accessible by an index) or a scalar value.
        :return: New velocity created as a result of the addition.
        """

        return self.__add__(other)

    def __sub__(self, other):
        """
        Subtracts the given velocity-like object or scalar value from this velocity and provides the result.

        :param other: Velocity-like object (with coordinates accessible by an index) or a scalar value.
        :return: New velocity created as a result of the subtraction.
        """

        return iterable_tools.sub(self, other)

    def __rsub__(self, other):
        """
        Subtracts this velocity or scalar value from the given velocity-like object and provides the result.

        :param other: Velocity-like object (with coordinates accessible by an index) or a scalar value.
        :return: New velocity created as a result of the subtraction.
        """

        return iterable_tools.rsub(self, other)

    def __mul__(self, other):
        """
        Multiplies this velocity by the given scalar value and provides the result.

        :param other: Scalar value.
        :return: New velocity created as a result of the multiplication.
        """

        return iterable_tools.mul(self, other, False)

    def __rmul__(self, other):
        """
        Multiplies this velocity by the given scalar value and provides the result.

        :param other: Scalar value.
        :return: New velocity created as a result of the multiplication.
        """

        return self.__mul__(other)

    def __truediv__(self, other):
        """
        Divides this velocity by the given scalar value and provides the result.

        :param other: Scalar value.
        :return: New velocity created as a result of the division.
        """

        return iterable_tools.truediv(self, other)

    def __rtruediv__(self, other):
        """
        Divides given scalar value by this velocity and provides the result.

        :param other: Scalar value.
        :return: New velocity created as a result of the division.
        """

        return iterable_tools.rtruediv(self, other)

    def __floordiv__(self, other):
        """
        Divides (with floor) this velocity by the given scalar value and provides the result.

        :param other: Scalar value.
        :return: New velocity created as a result of the floor division.
        """

        return iterable_tools.floordiv(self, other)

    def __rfloordiv__(self, other):
        """
        Divides (with floor) given scalar value by this velocity and provides the result.

        :param other: Scalar value.
        :return: New velocity created as a result of the floor division.
        """

        return iterable_tools.rfloordiv(self, other)

    def __eq__(self, other):
        """
        Compares equality of all existing coordinates. Tests approximate equality with maximum tolerance of 1e-6.

        :param other: velocity to compare to.
        :return: True if the velocities are equal, otherwise False.
        """

        return iterable_tools.eq(self, other, False)

    @classmethod
    def convert_from(cls, value) -> 'Optional[StageVelocity]':
        if value is None or isinstance(value, StageVelocity):
            return value
        if isinstance(value, (list, tuple)):
            return StageVelocity.create_from(value)
        raise TypeError(f"Cannot convert type {type(value).__name__} to StageVelocity.")

    @classmethod
    def convert_list_from(cls, value) -> 'Optional[List[StageVelocity]]':
        if value is None or isinstance(value, list) and all(isinstance(item, StageVelocity) for item in value):
            return value
        if isinstance(value, (list, tuple)):
            return [StageVelocity.create_from(item) for item in value]
        raise TypeError(f"Cannot convert type {type(value).__name__} to List[StageVelocity].")


class Point(shell.Point, XmlStructure):
    __slots__ = []

    def __init__(self, x: 'float' = None, y: 'float' = None):
        super().__init__(x, y)

        self._property_indexers = [
            Indexer(0, Point.x),
            Indexer(1, Point.y)
        ]

    def __len__(self):
        return len(self._property_indexers)

    def __getitem__(self, index: int) -> float:
        """
        Provides coordinate with the given index.

        The method is designed to behave in the same way as standard tuple/list indexer.
        It allows Point to be treated as tuple/list in numpy/scipy and other libraries
        that work with points represented by tuples/lists.
        """

        return search_indexers(self._property_indexers, index, self.__class__.__name__).fget(self)

    def __setitem__(self, index: int, value: Real):
        """
        Assigns a value to the coordinate with the given index.

        The method is designed to behave in the same way as standard tuple/list indexer.
        It allows Point to be treated as tuple/list in numpy/scipy and other libraries
        that work with points represented by tuples/lists.
        """

        search_indexers(self._property_indexers, index, self.__class__.__name__).fset(self, value)

    def __add__(self, other):
        """
        Adds a point-like object or scalar value to this point and provides the result.

        :param other: Point-like object (with coordinates accessible by 0, 1 indices) or a scalar value.
        :return: New point created as a result of the addition.
        """

        return iterable_tools.add(self, other)

    def __radd__(self, other):
        """
        Adds a point-like object or scalar value to this point and provides the result.

        :param other: Point-like object (with coordinates accessible by 0, 1 indices) or a scalar value.
        :return: New point created as a result of the addition.
        """

        return self.__add__(other)

    def __sub__(self, other):
        """
        Subtracts a point-like object or scalar value from this point and provides the result.

        :param other: Point-like object (with coordinates accessible by 0, 1 indices) or a scalar value.
        :return: New point created as a result of the subtraction.
        """

        return iterable_tools.sub(self, other)

    def __rsub__(self, other):
        """
        Subtracts this point from a point-like object or scalar value and provides the result.

        :param other: Point-like object (with coordinates accessible by 0, 1 indices) or a scalar value.
        :return: New point created as a result of the subtraction.
        """

        return iterable_tools.rsub(self, other)

    def __mul__(self, other):
        """
        Multiplies this point with a scalar and returns the result.
        If a point-like object is provided it returns the dot product.

        :param other: Scalar value or point-like object (with coordinates accessible by 0, 1 indices).
        :return: New point created as a result of the multiplication.
        """

        return iterable_tools.mul(self, other, True)

    def __rmul__(self, other):
        """
        Multiplies this point with a scalar and returns the result.
        If a point-like object is provided it returns the dot product.

        :param other: Scalar value or point-like object (with coordinates accessible by 0, 1 indices).
        :return: New point created as a result of the multiplication.
        """

        return self.__mul__(other)

    def __truediv__(self, other):
        """
        Divides this point by a scalar and returns the result.

        :param other: Scalar value.
        :return: New point created as a result of dividing the point by the scalar.
        """

        return iterable_tools.truediv(self, other)

    def __rtruediv__(self, other):
        """
        Divides a scalar by this point and provides the result.

        :param other: Scalar value.
        :return: New point created as a result of dividing the point by the scalar.
        """

        return iterable_tools.rtruediv(self, other)

    def __floordiv__(self, other):
        """
        Divides (with floor) this point by a scalar and returns the result.

        :param other: Scalar value.
        :return: New point created as a result of the floor division.
        """

        return iterable_tools.floordiv(self, other)

    def __rfloordiv__(self, other):
        """
        Divides (with floor) a scalar by this point and provides the result.

        :param other: Scalar value.
        :return: New point created as a result of the floor division.
        """

        return iterable_tools.rfloordiv(self, other)

    def __eq__(self, other):
        """
        Compares equality of two point-like objects. Tests approximate equality with maximum tolerance of 1e-9.

        :param other: Point-like object to compare to.
        :return: True if the points are equal, otherwise False.
        """

        return iterable_tools.eq(self, other, True, tolerance=1e-9)

    def __repr__(self):
        repr_attrs = [ReprAttr("x"), ReprAttr("y")]
        return self._generate_repr(repr_attrs)

    def magnitude(self) -> float:
        """
        Returns the magnitude of the point which is the distance from 0, 0.

        :return: Magnitude as a float.
        """

        try:
            return float(numpy.sqrt(self.x ** 2 + self.y ** 2))
        except Exception:
            raise ValueError("Cannot compute Point distance.") from None

    def angle(self) -> float:
        """
        Returns the angle of the point.

        :return: Radian angle as a float.
        """

        try:
            return float(numpy.arctan2(self.y, self.x))
        except Exception:
            raise ValueError("Cannot compute Point angle.") from None

    def serialize(self, parent):
        insert_value_to_element(parent, "X", self.x)
        insert_value_to_element(parent, "Y", self.y)

    def serialize_size(self, parent):
        insert_value_to_element(parent, "Width", self.x)
        insert_value_to_element(parent, "Height", self.y)

    @classmethod
    def deserialize(cls, element):
        deserialized = Point()
        deserialized.x = get_value_from_element(element, "X", float)
        deserialized.y = get_value_from_element(element, "Y", float)
        return deserialized

    @classmethod
    def deserialize_size(cls, element):
        deserialized = Point()
        deserialized.x = get_value_from_element(element, "Width", float)
        deserialized.y = get_value_from_element(element, "Height", float)
        return deserialized

    @classmethod
    def convert_from(cls, value) -> 'Optional[Point]':
        if value is None or isinstance(value, Point):
            return value
        if isinstance(value, (list, tuple)):
            return Point.create_from(value)
        raise TypeError(f"Cannot convert type {type(value).__name__} to Point.")

    @classmethod
    def convert_list_from(cls, value) -> 'Optional[List[Point]]':
        if value is None or isinstance(value, list) and all(isinstance(item, Point) for item in value):
            return value
        if isinstance(value, (list, tuple)):
            return [Point.create_from(item) for item in value]
        raise TypeError(f"Cannot convert type {type(value).__name__} to List[Point].")


class Rectangle(shell.Rectangle, XmlStructure):
    """
    The structure representing a rectangular shape.
    """
    __slots__ = []

    def __init__(self, left: 'float' = None, top: 'float' = None, width: 'float' = None, height: 'float' = None):
        super().__init__(left, top, width, height)

        self._property_indexers = [
            Indexer(0, Rectangle.left),
            Indexer(1, Rectangle.top),
            Indexer(2, Rectangle.width),
            Indexer(3, Rectangle.height)
        ]

    def __len__(self):
        return len(self._property_indexers)

    def __getitem__(self, index: int) -> float:
        """
        Provides a value with the given index.
        """

        return search_indexers(self._property_indexers, index, self.__class__.__name__).fget(self)

    def __setitem__(self, index: int, value: Real):
        """
        Assigns a value with the given index.
        """

        search_indexers(self._property_indexers, index, self.__class__.__name__).fset(self, value)

    def __add__(self, other):
        """
        Adds a rectangle-like object or scalar value to this rectangle and provides the result.

        :param other: Rectangle-like object (with coordinates accessible by 0, 1, 2, 3 indices) or a scalar value.
        :return: New rectangle created as a result of the addition.
        """

        return iterable_tools.add(self, other)

    def __radd__(self, other):
        """
        Adds a rectangle-like object or scalar value to this rectangle and provides the result.

        :param other: Rectangle-like object (with coordinates accessible by 0, 1, 2, 3 indices) or a scalar value.
        :return: New rectangle created as a result of the addition.
        """

        return self.__add__(other)

    def __sub__(self, other):
        """
        Subtracts a rectangle-like object or scalar value from this rectangle and provides the result.

        :param other: Rectangle-like object (with coordinates accessible by 0, 1, 2, 3 indices) or a scalar value.
        :return: New rectangle created as a result of the subtraction.
        """

        return iterable_tools.sub(self, other)

    def __rsub__(self, other):
        """
        Subtracts this rectangle from a rectangle-like object or scalar value and provides the result.

        :param other: Rectangle-like object (with coordinates accessible by 0, 1, 2, 3 indices) or a scalar value.
        :return: New rectangle created as a result of the subtraction.
        """

        return iterable_tools.rsub(self, other)

    def __mul__(self, other):
        """
        Multiplies this rectangle with a scalar and returns the result.
        If a rectangle-like object is provided it returns the dot product.

        :param other: Scalar value or rectangle-like object (with coordinates accessible by 0, 1, 2, 3 indices).
        :return: New rectangle created as a result of the multiplication.
        """

        return iterable_tools.mul(self, other, False)

    def __rmul__(self, other):
        """
        Multiplies this rectangle with a scalar and returns the result.
        If a rectangle-like object is provided it returns the dot product.

        :param other: Scalar value or rectangle-like object (with coordinates accessible by 0, 1, 2, 3 indices).
        :return: New rectangle created as a result of the multiplication.
        """

        return self.__mul__(other)

    def __truediv__(self, other):
        """
        Divides this rectangle by a scalar and returns the result.

        :param other: Scalar value.
        :return: New rectangle created as a result of dividing the rectangle by the scalar.
        """

        return iterable_tools.truediv(self, other)

    def __rtruediv__(self, other):
        """
        Divides a scalar by this rectangle and provides the result.

        :param other: Scalar value.
        :return: New rectangle created as a result of dividing the rectangle by the scalar.
        """

        return iterable_tools.rtruediv(self, other)

    def __floordiv__(self, other):
        """
        Divides (with floor) this rectangle by a scalar and returns the result.

        :param other: Scalar value.
        :return: New rectangle created as a result of the floor division.
        """

        return iterable_tools.floordiv(self, other)

    def __rfloordiv__(self, other):
        """
        Divides (with floor) a scalar by this rectangle and provides the result.

        :param other: Scalar value.
        :return: New rectangle created as a result of the floor division.
        """

        return iterable_tools.rfloordiv(self, other)

    def __eq__(self, other):
        """
        Compares equality of two rectangle-like objects. Tests approximate equality with maximum tolerance of 1e-9.

        :param other: Rectangle-like object to compare to.
        :return: True if the rectangles are equal, otherwise False.
        """

        return iterable_tools.eq(self, other, True, tolerance=1e-9)

    def __repr__(self):
        repr_attrs = [ReprAttr("left"), ReprAttr("top"), ReprAttr("width"), ReprAttr("height")]
        return self._generate_repr(repr_attrs)

    def serialize(self, parent):
        insert_value_to_element(parent, "X", self.left)
        insert_value_to_element(parent, "Y", self.top)
        insert_value_to_element(parent, "Width", self.width)
        insert_value_to_element(parent, "Height", self.height)

    @classmethod
    def deserialize(cls, element):
        deserialized = Rectangle()
        deserialized.left = get_value_from_element(element, "X", float)
        deserialized.top = get_value_from_element(element, "Y", float)
        deserialized.width = get_value_from_element(element, "Width", float)
        deserialized.height = get_value_from_element(element, "Height", float)
        return deserialized

    @classmethod
    def convert_from(cls, value) -> 'Optional[Rectangle]':
        if value is None or isinstance(value, Rectangle):
            return value
        if isinstance(value, (list, tuple)):
            return Rectangle.create_from(value)
        raise TypeError(f"Cannot convert type {type(value).__name__} to Rectangle.")

    @classmethod
    def convert_list_from(cls, value) -> 'Optional[List[Rectangle]]':
        if value is None or isinstance(value, list) and all(isinstance(item, Rectangle) for item in value):
            return value
        if isinstance(value, (list, tuple)):
            return [Rectangle.create_from(item) for item in value]
        raise TypeError(f"Cannot convert type {type(value).__name__} to List[Rectangle].")


class Unit(shell.Unit):
    """
    A structure representing unit with prefix.
    """
    __slots__ = []

    def __init__(self, name: 'str' = None, prefix_power: 'int' = None):
        super().__init__(name, prefix_power)

        self._property_indexers = [
            Indexer(0, Unit.name),
            Indexer(1, Unit.prefix_power)
        ]

    def __len__(self):
        return len(self._property_indexers)

    def __getitem__(self, index: int):
        """
        Provides a value with the given index.
        """

        return search_indexers(self._property_indexers, index, self.__class__.__name__).fget(self)

    def __setitem__(self, index: int, value):
        """
        Assigns a value with the given index.
        """

        search_indexers(self._property_indexers, index, self.__class__.__name__).fset(self, value)

    def __eq__(self, other):
        """
        Compares equality of two unit-like objects.

        :param other: Unit-like object to compare to.
        :return: True if the units are equal, otherwise False.
        """

        return iterable_tools.eq(self, other, True)

    def __repr__(self):
        repr_attrs = [ReprAttr("name"), ReprAttr("prefix_power")]
        return self._generate_repr(repr_attrs)

    def serialize(self, element):
        """
        Serializes unit into a given xml element.
        """

        if element is not None:
            insert_attribute_to_element(element, "unit", self.name)
            insert_attribute_to_element(element, "unitPrefixPower", self.prefix_power)

    @staticmethod
    def deserialize(element) -> 'Unit':
        """
        Deserializes unit from a given xml element.
        """

        if element is not None:
            name = get_attribute_from_element(element, "unit", str)
            prefix_power = get_attribute_from_element(element, "unitPrefixPower", int)

            if name is not None or prefix_power is not None:
                return Unit(name, prefix_power)

    @classmethod
    def convert_from(cls, value) -> 'Optional[Unit]':
        if value is None or isinstance(value, Unit):
            return value
        if isinstance(value, (list, tuple)):
            return Unit.create_from(value)
        raise TypeError(f"Cannot convert type {type(value).__name__} to Unit.")

    @classmethod
    def convert_list_from(cls, value) -> 'Optional[List[Unit]]':
        if value is None or isinstance(value, list) and all(isinstance(item, Unit) for item in value):
            return value
        if isinstance(value, (list, tuple)):
            return [Unit.create_from(item) for item in value]
        raise TypeError(f"Cannot convert type {type(value).__name__} to List[Unit].")


class Limits(shell.Limits, XmlStructure):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("min"), ReprAttr("max")]
        return self._generate_repr(repr_attrs)

    def is_in(self, value: Real) -> bool:
        """
        Checks if the given value follows the limits. Tests approximate equality with maximum tolerance of 1e-9.

        :param value: Value to be checked.
        :return: True if the value is in the closed interval, otherwise False.
        """

        min_check = self.min is None or isclose(self.min, float(value), abs_tol=1e-9) or self.min < value
        max_check = self.max is None or isclose(self.max, float(value), abs_tol=1e-9) or self.max > value

        return min_check and max_check

    def serialize(self, parent):
        insert_value_to_element(parent, "Begin", self.min)
        insert_value_to_element(parent, "End", self.max)

    @classmethod
    def deserialize(cls, element):
        deserialized = Limits()
        deserialized.min = get_value_from_element(element, "Begin", float)
        deserialized.max = get_value_from_element(element, "End", float)
        return deserialized


class ValueAndType(shell.ValueAndType, XmlStructure):
    """
    A structure representing value with type.
    """
    __slots__ = []

    def __init__(self, value: 'str' = None, type: 'str' = None):
        super().__init__(value, type)

        self._property_indexers = [
            Indexer(0, ValueAndType.value),
            Indexer(1, ValueAndType.type)
        ]

    def __len__(self):
        return len(self._property_indexers)

    def __getitem__(self, index: int) -> str:
        """
        Provides a value with the given index.
        """

        return search_indexers(self._property_indexers, index, self.__class__.__name__).fget(self)

    def __setitem__(self, index: int, value: str):
        """
        Assigns a value with the given index.
        """

        search_indexers(self._property_indexers, index, self.__class__.__name__).fset(self, value)

    def __eq__(self, other):
        """
        Compares equality of two value-and-type-like objects.

        :param other: Value-and-type-like object to compare to.
        :return: True if the objects are equal, otherwise False.
        """

        return iterable_tools.eq(self, other, True)

    def __repr__(self):
        repr_attrs = [ReprAttr("value"), ReprAttr("type")]
        return self._generate_repr(repr_attrs)

    @staticmethod
    def get_xml_element_name() -> 'Optional[str]':
        return "Label"

    def serialize(self, parent):
        super().serialize(parent)
        element = parent[-1]  # We need to extend the last added element
        insert_attribute_to_element(element, "type", self.type)
        insert_attribute_to_element(element, "value", self.value)

    @classmethod
    def deserialize(cls, element):
        deserialized = super().deserialize(element)
        deserialized.type = get_attribute_from_element(element, "type", str)
        deserialized.value = get_attribute_from_element(element, "value", str)
        return deserialized

    @staticmethod
    def serialize_shutters(parent, shutters, structure_type):
        """
        Serializes the given shutter list and appends it into the parent element.
        """

        if shutters is not None:
            shutters_element = insert_element(parent, "Shutters", OrderingInfo(structure_type, "shutters"))

            for shutter in shutters:
                element = insert_element(shutters_element, "Shutter")
                insert_attribute_to_element(element, "type", shutter.type)
                insert_attribute_to_element(element, "position", shutter.value)

    @staticmethod
    def deserialize_shutters(element, deserialized):
        """
        Deserializes the given element into a shutter list.
        """

        shutters_element = element.find("Shutters")

        if shutters_element is not None:
            shutters = []

            for shutter_element in shutters_element.findall("Shutter"):
                shutter = ValueAndType()
                shutter.type = get_attribute_from_element(shutter_element, "type", str)
                shutter.value = get_attribute_from_element(shutter_element, "position", str)
                shutters.append(shutter)

            deserialized.shutters = shutters

    @classmethod
    def convert_from(cls, value) -> 'Optional[ValueAndType]':
        if value is None or isinstance(value, ValueAndType):
            return value
        if isinstance(value, (list, tuple)):
            return ValueAndType.create_from(value)
        raise TypeError(f"Cannot convert type {type(value).__name__} to ValueAndType.")

    @classmethod
    def convert_list_from(cls, value) -> 'Optional[List[ValueAndType]]':
        if value is None or isinstance(value, list) and all(isinstance(item, ValueAndType) for item in value):
            return value
        if isinstance(value, (list, tuple)):
            return [ValueAndType.create_from(item) for item in value]
        raise TypeError(f"Cannot convert type {type(value).__name__} to List[ValueAndType].")


class ImageMatch(shell.ImageMatch):
    __slots__ = []

    def __init__(self, center: 'Union[Point, list, tuple]' = None, score: 'float' = None):
        if isinstance(center, (list, tuple)):
            center = Point.create_from(center)
        super().__init__(center=center, score=score)

    @shell.ImageMatch.center.setter
    def center(self, value: 'Union[Point, list, tuple]'):
        """
        The Point structure containing coordinates of the center of the match in the original image, in pixels.
        """
        if isinstance(value, (list, tuple)):
            value = Point.create_from(value)
        super(self.__class__, self.__class__).center.fset(self, value)

    def __repr__(self):
        repr_attrs = [ReprAttr("center"), ReprAttr("score")]
        return self._generate_repr(repr_attrs)


class CenteringResult(shell.CenteringResult):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("name"), ReprAttr("off_center_distance")]
        return self._generate_repr(repr_attrs)


class CameraImageSize(shell.CameraImageSize):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("size"), ReprAttr("fixed_readout_area")]
        return self._generate_repr(repr_attrs)
