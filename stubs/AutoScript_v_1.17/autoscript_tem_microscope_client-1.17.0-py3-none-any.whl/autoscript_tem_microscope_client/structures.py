from typing import Union, Optional, List, TYPE_CHECKING
from warnings import warn

from autoscript_core.serialization import ReprAttr

from . import _structures_shell as shell
from ._structures_emd_file import EmdFile, EmdStemFeature
from ._structures_adorned_image import AdornedImage
from ._structures_adorned_spectrum import AdornedSpectrum
from ._structures_metadata import *
from ._structures_primitives import StagePosition, StageVelocity, Point, Rectangle, Unit, Limits, \
    ValueAndType, ImageMatch, CenteringResult, CameraImageSize
from ._structures_variant import Variant

if TYPE_CHECKING:
    from ._dynamic_object_proxies import DetectorSegment


__all__ = ["Region", "DriftCompensation", "Rectangle", "StagePosition", "StageVelocity", "CameraLengthData", "MagnificationData", "Limits", 
           "Point", "Aperture", "Unit", "ValueAndType", "ImageMatch", "CameraImageSize", "AdornedImageMetadataReferenceTransformation", 
           "AdornedImageMetadataCustomProperty", "AdornedImageMetadataCustomProperties", "AdornedImageMetadataCustomSection", 
           "AdornedImageMetadataStagePosition", "AdornedImageMetadataAcquisition", "AdornedImageMetadataBinaryResult", "AdornedImageMetadataCore", 
           "AdornedImageMetadataScanningDetector", "AdornedImageMetadataAnalyticalDetector", "AdornedImageMetadataImagingDetector", 
           "AdornedImageMetadataEnergyFilterSettings", "AdornedImageMetadataGasInjectionSystemGas", "AdornedImageMetadataGasInjectionSystem", 
           "AdornedImageMetadataInstrument", "AdornedImageMetadataOpticsAperture", "AdornedImageMetadataOptics", "AdornedImageMetadataSample", 
           "AdornedImageMetadataScanSettings", "AdornedImageMetadataStageSettings", "AdornedImageMetadataVacuumProperties", "AdornedImageMetadata", 
           "AdornedImage", "AdornedSpectrum", "EmdStemFeature", "EmdFile", "RunBeamTiltAutoFocusSettings", "RunBeamTiltAutoFocusResults", 
           "RunStemAutoFocusSettings", "RunStemAutoFocusResults", "RunObjectiveAutoStigmatorSettings", "RunObjectiveAutoStigmatorResults", 
           "RunAutoComaCorrectionSettings", "RunAutoComaCorrectionResults", "CameraAcquisitionSettings", "StemAcquisitionSettings", "StemDataSettings", 
           "MoveToPixelSettings", "EdsAcquisitionSettings", "EdsSpectrumImageSettings", "EdsSpectrumImageSettingsInternal", "EelsExposureSettings", 
           "EelsAcquisitionSettings", "EelsSpectrumImageSettings", "RunOptiStemSettings", "RunOptiStemResults", "RunImageCorrectorSettings", 
           "RunImageCorrectorResults", "RunProbeCorrectorSettings", "RunProbeCorrectorResults", "RunBeamCenteringSettings", "RunBeamCenteringResults", 
           "RunApertureCenteringSettings", "RunApertureCenteringResults", "CenteringResult", "OpticsAlignmentParameter", "Variant", 
           "RunRotationCenterAlignmentSettings", "RunRotationCenterAlignmentResults", "ContinuousScanSettings"]


class Aperture(shell.Aperture):
    """
    The structure representing one aperture
    """
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("name"),
                      ReprAttr("type"),
                      ReprAttr("diameter")]
        return self._generate_repr(repr_attrs)


class CameraLengthData(shell.CameraLengthData):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("label"),
                      ReprAttr("objective_lens_mode"),
                      ReprAttr("nominal"),
                      ReprAttr("calibrated"),
                      ReprAttr("rotation")]
        return self._generate_repr(repr_attrs)


class MagnificationData(shell.MagnificationData):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("label"),
                      ReprAttr("magnification_sub_mode"),
                      ReprAttr("objective_lens_mode"),
                      ReprAttr("nominal"),
                      ReprAttr("calibrated"),
                      ReprAttr("rotation")]
        return self._generate_repr(repr_attrs)


class RunBeamTiltAutoFocusSettings(shell.RunBeamTiltAutoFocusSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("camera_detector"),
                      ReprAttr("size"),
                      ReprAttr("exposure_time"),
                      ReprAttr("focus_method"),
                      ReprAttr("auto_stigmate"),
                      ReprAttr("use_three_image_method"),
                      ReprAttr("maximum_focus_change"),
                      ReprAttr("maximum_iterations"),
                      ReprAttr("maximum_astigmatism_change"),
                      ReprAttr("iterate_to_defocus")]
        return self._generate_repr(repr_attrs)


class RunBeamTiltAutoFocusResults(shell.RunBeamTiltAutoFocusResults):
    __slots__ = []

    def __init__(self, astigmatism: 'float' = 0.0, defocus: 'float' = 0.0, drift: 'Union[Point, list, tuple]' = None):
        if isinstance(drift, (list, tuple)):
            drift = Point.create_from(drift)
        super().__init__(astigmatism=astigmatism, defocus=defocus, drift=drift)

    def __repr__(self):
        repr_attrs = [ReprAttr("astigmatism"),
                      ReprAttr("defocus"),
                      ReprAttr("drift")]
        return self._generate_repr(repr_attrs)


class RunStemAutoFocusSettings(shell.RunStemAutoFocusSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("scanning_detector"),
                      ReprAttr("size"),
                      ReprAttr("dwell_time"),
                      ReprAttr("auto_stigmate"),
                      ReprAttr("accuracy_level"),
                      ReprAttr("reset_beam_blanker_afterwards")]
        return self._generate_repr(repr_attrs)


class RunStemAutoFocusResults(shell.RunStemAutoFocusResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("astigmatism"),
                      ReprAttr("defocus")]
        return self._generate_repr(repr_attrs)


class RunObjectiveAutoStigmatorSettings(shell.RunObjectiveAutoStigmatorSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("camera_detector"),
                      ReprAttr("size"),
                      ReprAttr("exposure_time"),
                      ReprAttr("maximum_iterations"),
                      ReprAttr("maximum_remaining_astigmatism"),
                      ReprAttr("defocus_step"),
                      ReprAttr("maximum_anisotropy"),
                      ReprAttr("maximum_astigmatism_fit_error"),
                      ReprAttr("tile_size"),
                      ReprAttr("is_thon_ring_mask_image_crossed_out_when_fitting_fails")]
        return self._generate_repr(repr_attrs)


class RunObjectiveAutoStigmatorResults(shell.RunObjectiveAutoStigmatorResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("astigmatism"),
                      ReprAttr("astigmatism_orientation"),
                      ReprAttr("astigmatism_fit_error"),
                      ReprAttr("is_reliable")]
        return self._generate_repr(repr_attrs)


class RunAutoComaCorrectionSettings(shell.RunAutoComaCorrectionSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("camera_detector"),
                      ReprAttr("size"),
                      ReprAttr("exposure_time"),
                      ReprAttr("maximum_iterations"),
                      ReprAttr("maximum_remaining_coma_error"),
                      ReprAttr("maximum_remaining_defocus_error"),
                      ReprAttr("maximum_remaining_astigmatism"),
                      ReprAttr("maximum_anisotropy"),
                      ReprAttr("maximum_astigmatism_fit_error"),
                      ReprAttr("maximum_defocus_fit_error"),
                      ReprAttr("tile_size"),
                      ReprAttr("is_thon_ring_mask_image_crossed_out_when_fitting_fails"),
                      ReprAttr("adjust_focus"),
                      ReprAttr("correct_astigmatism")]
        return self._generate_repr(repr_attrs)


class RunAutoComaCorrectionResults(shell.RunAutoComaCorrectionResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("astigmatism"),
                      ReprAttr("astigmatism_orientation"),
                      ReprAttr("threefold_astigmatism"),
                      ReprAttr("threefold_astigmatism_orientation"),
                      ReprAttr("coma"),
                      ReprAttr("coma_orientation"),
                      ReprAttr("defocus"),
                      ReprAttr("tableau_fit_error"),
                      ReprAttr("is_reliable")]
        return self._generate_repr(repr_attrs)


class CameraAcquisitionSettings(shell.CameraAcquisitionSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("camera_detector"),
                      ReprAttr("size"),
                      ReprAttr("exposure_time"),
                      ReprAttr("fixed_readout_area"),
                      ReprAttr("frame_combining"),
                      ReprAttr("electron_counting")]
        return self._generate_repr(repr_attrs)


class MoveToPixelSettings(shell.MoveToPixelSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("image_size"),
                      ReprAttr("fixed_readout_area"),
                      ReprAttr("method"),
                      ReprAttr("use_safe_stage_moves")]
        return self._generate_repr(repr_attrs)


class RunOptiStemResults(shell.RunOptiStemResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("quality")]
        return self._generate_repr(repr_attrs)


class RunOptiStemSettings(shell.RunOptiStemSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("method"),
                      ReprAttr("dwell_time"),
                      ReprAttr("cutoff_in_pixels"),
                      ReprAttr("cutoff_spatial_frequency")]
        return self._generate_repr(repr_attrs)


class EdsAcquisitionSettings(shell.EdsAcquisitionSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("eds_detector"),
                      ReprAttr("dispersion"),
                      ReprAttr("shaping_time"),
                      ReprAttr("exposure_time"),
                      ReprAttr("exposure_time_type"),
                      ReprAttr("detector_segments")]
        return self._generate_repr(repr_attrs)


class EdsSpectrumImageSettings(shell.EdsSpectrumImageSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("eds_detector"),
                      ReprAttr("dispersion"),
                      ReprAttr("shaping_time"),
                      ReprAttr("dwell_time"),
                      ReprAttr("size"),
                      ReprAttr("region"),
                      ReprAttr("scanning_detectors"),
                      ReprAttr("scanning_detector_segments"),
                      ReprAttr("eds_detector_segments"),
                      ReprAttr("save_eds_event_stream")]
        return self._generate_repr(repr_attrs)


class EdsSpectrumImageSettingsInternal(shell.EdsSpectrumImageSettingsInternal):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("number_of_frames"),
                      ReprAttr("drift_compensation"),
                      ReprAttr("save_all_stem_images")]
        return self._generate_repr(repr_attrs)


class Region(shell.Region):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("coordinate_system"),
                      ReprAttr("rectangle")]
        return self._generate_repr(repr_attrs)

    def __init__(self, coordinate_system: 'str' = None, rectangle: 'Union[Rectangle, list, tuple]' = None):
        if isinstance(rectangle, (list, tuple)):
            rectangle = Rectangle.create_from(rectangle)
        super().__init__(coordinate_system=coordinate_system, rectangle=rectangle)

    @shell.Region.rectangle.setter
    def rectangle(self, value: 'Optional[Union[Rectangle, list, tuple]]'):
        """
        A Rectangular region.
        """
        if isinstance(value, (list, tuple)):
            value = Rectangle.create_from(value)
        super(self.__class__, self.__class__).rectangle.fset(self, value)


class StemAcquisitionSettings(shell.StemAcquisitionSettings):
    __slots__ = []

    def __init__(self, dwell_time: 'float' = 0.0, detector_types: 'List[str]' = None, detector_segments: 'List[DetectorSegment]' = None, region: 'Region' = None, size: 'int' = None, auto_beam_blank: 'bool' = None):
        if auto_beam_blank is not None:
            warn("The property 'auto_beam_blank' is deprecated and will be removed in version 1.21", DeprecationWarning, stacklevel=2)
        super(StemAcquisitionSettings, self).__init__(dwell_time, detector_types, detector_segments, region, size, auto_beam_blank)

    def __repr__(self):
        repr_attrs = [ReprAttr("dwell_time"),
                      ReprAttr("detector_types"),
                      ReprAttr("detector_segments"),
                      ReprAttr("region"),
                      ReprAttr("size"),
                      ReprAttr("auto_beam_blank")]
        return self._generate_repr(repr_attrs)


class RunImageCorrectorSettings(shell.RunImageCorrectorSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("phase_contrast_transfer_function_target_g_max_inverse"),
                      ReprAttr("phase_contrast_transfer_function_target_phase_sign")]
        return self._generate_repr(repr_attrs)


class RunImageCorrectorResults(shell.RunImageCorrectorResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("quality")]
        return self._generate_repr(repr_attrs)


class RunProbeCorrectorSettings(shell.RunProbeCorrectorSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("probe_semi_aperture_angle"),
                      ReprAttr("probe_current")]
        return self._generate_repr(repr_attrs)


class RunProbeCorrectorResults(shell.RunProbeCorrectorResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("quality"),
                      ReprAttr("probe_optimum_d50"),
                      ReprAttr("probe_total_d50")]
        return self._generate_repr(repr_attrs)


class RunBeamCenteringSettings(shell.RunBeamCenteringSettings):
    __slots__ = []

    def __init__(self, target_position: 'Union[Point, list, tuple]' = None, maximum_iterations: 'int' = 0,
                 maximum_allowed_distance: 'float' = 0.0, beam_diameter_change_allowed: 'bool' = False,
                 stage_movement_allowed: 'bool' = False, check_only_mode: 'bool' = False):
        target_position = Point.convert_from(target_position)
        super().__init__(target_position=target_position, maximum_iterations=maximum_iterations,
                         maximum_allowed_distance=maximum_allowed_distance,
                         beam_diameter_change_allowed=beam_diameter_change_allowed,
                         stage_movement_allowed=stage_movement_allowed, check_only_mode=check_only_mode)

    @shell.RunBeamCenteringSettings.target_position.setter
    def target_position(self, value: 'Union[Point, list, tuple]'):
        """
        Target position in meters. (0, 0) is the centered position on the optical axis, (1, 1) is top right, (-1,-1) is bottom left.
        """
        value = Point.convert_from(value)
        super(self.__class__, self.__class__).target_position.fset(self, value)

    def __repr__(self):
        repr_attrs = [ReprAttr("maximum_allowed_distance"),
                      ReprAttr("target_position"),
                      ReprAttr("maximum_iterations"),
                      ReprAttr("beam_diameter_change_allowed"),
                      ReprAttr("stage_movement_allowed"),
                      ReprAttr("check_only_mode")]
        return self._generate_repr(repr_attrs)


class RunBeamCenteringResults(shell.RunBeamCenteringResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [
            ReprAttr("quality"),
            ReprAttr("off_center_distance"),
            ReprAttr("message")]
        return self._generate_repr(repr_attrs)


class RunApertureCenteringSettings(shell.RunApertureCenteringSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("aperture_mechanism_type"),
                      ReprAttr("maximum_allowed_distance"),
                      ReprAttr("aperture_names"),
                      ReprAttr("maximum_iterations"),
                      ReprAttr("beam_diameter_change_allowed"),
                      ReprAttr("stage_movement_allowed"),
                      ReprAttr("check_only_mode")]
        return self._generate_repr(repr_attrs)


class RunApertureCenteringResults(shell.RunApertureCenteringResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("quality"),
                      ReprAttr("off_center_distances"),
                      ReprAttr("message")]
        return self._generate_repr(repr_attrs)


class DriftCompensation(shell.DriftCompensation):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("measurement_area")]
        return self._generate_repr(repr_attrs)


class EelsAcquisitionSettings(shell.EelsAcquisitionSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("eels_detector"),
                      ReprAttr("eels_exposure_settings")]
        return self._generate_repr(repr_attrs)


class EelsExposureSettings(shell.EelsExposureSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("exposure_time"),
                      ReprAttr("drift_tube_energy_offset")]
        return self._generate_repr(repr_attrs)


class OpticsAlignmentParameter(shell.OpticsAlignmentParameter):
    __slots__ = []

    def __repr__(self):
        if self.parameter is None:
            return self.element

        return f"{self.element}.{self.parameter}"


class RunRotationCenterAlignmentSettings(shell.RunRotationCenterAlignmentSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("maximum_number_of_iterations")]
        return self._generate_repr(repr_attrs)


class RunRotationCenterAlignmentResults(shell.RunRotationCenterAlignmentResults):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [
            ReprAttr("quality"),
            ReprAttr("message")]
        return self._generate_repr(repr_attrs)


class EelsSpectrumImageSettings(shell.EelsSpectrumImageSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("eels_detector"),
                      ReprAttr("eels_exposure_settings"),
                      ReprAttr("dwell_time"),
                      ReprAttr("size"),
                      ReprAttr("region"),
                      ReprAttr("scanning_detectors"),
                      ReprAttr("scanning_detector_segments")]
        return self._generate_repr(repr_attrs)


class StemDataSettings(shell.StemDataSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("dwell_time"),
                      ReprAttr("detector_types"),
                      ReprAttr("region"),
                      ReprAttr("size")]
        return self._generate_repr(repr_attrs)


class ContinuousScanSettings(shell.ContinuousScanSettings):
    __slots__ = []

    def __repr__(self):
        repr_attrs = [ReprAttr("buffer_size"),
                      ReprAttr("buffer_type"),
                      ReprAttr("synchronization_type")]
        return self._generate_repr(repr_attrs)
