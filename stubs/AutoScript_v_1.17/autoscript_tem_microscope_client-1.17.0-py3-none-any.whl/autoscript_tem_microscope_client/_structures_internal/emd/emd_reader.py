import importlib
import os
import sys
import enum
from typing import List
import numpy as np

from ..._tem_microscope_client_extensions import TemMicroscopeClientExtensions
from ...enumerations import DetectorType


class EmdFeatureType(enum.Enum):
    UNKNOWN = 0
    STEM = 1
    CAMERA = 2
    CROP = 3
    DCFI = 4
    DPC = 5
    DPC_PROCESSING = 6
    EDS = 7
    EELS = 8
    EFTEM = 9
    EXTERNAL_IMAGE = 10
    FFT = 11
    IMAGE_FILTERING = 12
    INTEGRATION_RECTANGLE = 13
    INTENSITY_PROFILE = 14
    MATH = 15
    SI_INTENSITY_PROFILE = 16
    SPECTRUM_PROFILE = 17
    INTEGRATED_1D_SPECTRA = 18


class EmdImageSeries:
    def __init__(self, emd_file_id, emd_feature_id, emd_image_series_id):
        self.__emd_file_id = emd_file_id
        self.__emd_feature_id = emd_feature_id
        self.__emd_image_series_id = emd_image_series_id

    @property
    def frame_count(self) -> int:
        frame_count = EmdReader.get_emd_library().GetImageSeriesFrameCount(
            self.__emd_file_id, self.__emd_feature_id, self.__emd_image_series_id)
        return frame_count

    @property
    def width(self) -> int:
        width = EmdReader.get_emd_library().GetImageSeriesWidth(
            self.__emd_file_id, self.__emd_feature_id, self.__emd_image_series_id)
        return width

    @property
    def height(self) -> int:
        height = EmdReader.get_emd_library().GetImageSeriesHeight(
            self.__emd_file_id, self.__emd_feature_id, self.__emd_image_series_id)
        return height

    @property
    def bit_depth(self) -> int:
        bytes_per_pixel = EmdReader.get_emd_library().GetImageSeriesBytesPerPixel(
            self.__emd_file_id, self.__emd_feature_id, self.__emd_image_series_id)
        return bytes_per_pixel * 8

    @property
    def pixel_format(self) -> str:
        pixel_format = EmdReader.get_emd_library().GetImageSeriesPixelFormat(
            self.__emd_file_id, self.__emd_feature_id, self.__emd_image_series_id)
        return pixel_format

    def get_frame_data(self, frame_index: int) -> np.ndarray:
        data = EmdReader.get_emd_library().GetImageSeriesFrameData(
            self.__emd_file_id, self.__emd_feature_id, self.__emd_image_series_id, frame_index)
        return data

    def get_frame_metadata(self, frame_index: int) -> str:
        metadata_as_xml = EmdReader.get_emd_library().GetImageSeriesFrameMetadata(
            self.__emd_file_id, self.__emd_feature_id, self.__emd_image_series_id, frame_index)
        return metadata_as_xml


class EmdFeature:
    def __init__(self, emd_file_id, emd_feature_id):
        self.__emd_file_id = emd_file_id
        self.__emd_feature_id = emd_feature_id

    @property
    def type(self) -> EmdFeatureType:
        type_as_int = EmdReader.get_emd_library().GetFeatureType(self.__emd_file_id, self.__emd_feature_id)
        return EmdFeatureType(type_as_int)

    def get_image_series(self) -> List[EmdImageSeries]:
        series_ids = EmdReader.get_emd_library().GetImageSeries(self.__emd_file_id, self.__emd_feature_id)
        series = []
        for series_id in series_ids:
            one_series = EmdImageSeries(self.__emd_file_id, self.__emd_feature_id, series_id)
            series.append(one_series)

        return series


class EmdReader:
    _emd_file_storage_library = None

    def __init__(self):
        self.file_path = None
        self.__emd_file_id = 0

    def __del__(self):
        self.close()

    def __repr__(self):
        return f"EmdFile ({self.file_path})"

    @staticmethod
    def get_emd_library():
        if EmdReader._emd_file_storage_library is None:
            sys.path.append(os.path.join(os.path.dirname(__file__), "EmdFileStorage"))

            try:
                EmdReader._emd_file_storage_library = importlib.__import__("EmdFileStorage")
            except ImportError:
                raise ImportError("Could not import EmdFileStorage library. "
                                  "The Python version is probably not compatible with the library.") from None

        return EmdReader._emd_file_storage_library

    def open(self, file_path: str, read_only: bool = False):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File {file_path} does not exist.")

        self.__open_or_create(file_path, read_only)

    def create(self, file_path: str):
        if os.path.exists(file_path):
            raise FileExistsError(f"File {file_path} already exists.")

        directory_path = os.path.dirname(file_path)
        if not os.path.isdir(directory_path):
            raise FileNotFoundError(f"Directory {directory_path} does not exist.")

        self.__open_or_create(file_path)

    def __open_or_create(self, file_path: str, read_only: bool = False):
        self.close()

        application_name = "AutoScript TEM"
        application_version = TemMicroscopeClientExtensions.version_GET(None)

        # EmdReader.get_emd_library().AttachDebugger()
        # EmdReader.get_emd_library().EnableLogging()

        self.__emd_file_id = EmdReader.get_emd_library().CreateEmdFile(file_path, application_name, application_version, read_only)
        self.file_path = file_path


    @property
    def is_open(self) -> bool:
        return self.__emd_file_id != 0

    def close(self):
        if self.is_open:
            EmdReader.get_emd_library().CloseEmdFile(self.__emd_file_id)
            self.__emd_file_id = 0

    def get_features(self) -> List[EmdFeature]:
        self.__check_if_open_or_throw()

        feature_ids = EmdReader.get_emd_library().GetFeatures(self.__emd_file_id)
        features = []
        for feature_id in feature_ids:
            feature = EmdFeature(self.__emd_file_id, feature_id)
            features.append(feature)

        return features

    def create_stem_feature(self) -> int:
        self.__check_if_open_or_throw()

        feature_id = EmdReader.get_emd_library().CreateStemFeature(self.__emd_file_id)
        return feature_id

    def create_stem_detector(self, feature_id, detector_type) -> int:
        self.__check_if_open_or_throw()

        detector_type_id = self.__convert_stem_detector_type_to_id(detector_type)
        detector_id = EmdReader.get_emd_library().CreateStemDetector(self.__emd_file_id, feature_id, detector_type_id)
        return detector_id

    def append_frame_to_stem_detector(self, feature_id, detector_id, data, width, height, metadata):
        self.__check_if_open_or_throw()

        EmdReader.get_emd_library().AppendFrameToStemDetector(self.__emd_file_id, feature_id, detector_id, data, width, height, metadata)

    def __check_if_open_or_throw(self):
        if not self.is_open:
            raise Exception("Emd file is not open.")

    @staticmethod
    def __convert_stem_detector_type_to_id(detector_type: str) -> int:
        detector_name_conversion_table = {
            DetectorType.BF : "BF",
            DetectorType.DF2 : "DF2",
            DetectorType.DF4 : "DF4",
            DetectorType.HAADF : "HAADF",
            DetectorType.BF_S : "BFS",
            DetectorType.DF_S : "DFS"
        }

        if detector_type not in detector_name_conversion_table:
            raise ValueError(f"Detector type {detector_type} is not supported.")

        return EmdReader.__get_stem_detector_dictionary()[detector_name_conversion_table[detector_type]]

    @staticmethod
    def __get_stem_detector_dictionary():
        return EmdReader.get_emd_library().GetStemDetectorDictionary()