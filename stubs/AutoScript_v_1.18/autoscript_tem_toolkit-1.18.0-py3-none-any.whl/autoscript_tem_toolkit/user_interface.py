import numpy
import matplotlib.pyplot as plot
import warnings 

from typing import Optional, List, Sequence

from autoscript_tem_microscope_client import TemMicroscopeClient

from . import _draw_utilities as draw_utilities
from . import _image_selector as image_selector
from . import _plot_utilities as plot_utilities
from autoscript_tem_microscope_client.structures import Point, Rectangle, AdornedImage, AdornedSpectrum, StemAcquisitionSettings, StemDataSettings, CameraAcquisitionSettings, EdsAcquisitionSettings, EdsSpectrumImageSettings
from . import _primitives_renderer as primitives_renderer
from autoscript_tem_microscope_client.enumerations import RegionCoordinateSystem
try:
    from ._forms import forms
except ImportError as e:
    if "DLL load failed" in str(e):
        warnings.warn("Pyside6 is not compatible with old windows 10 versions (<1809) and newer (>3.11) python. Some UI functions will not work. \
               See Python Compatibility page in manual for more details.")
    else:
        raise  # Re-raise if it's a different kind of ImportError

__all__ = ["plot_match", "plot_image", "plot_images", "plot_spectrum", "plot_spectra",
           "select_point", "select_points", "select_rectangle", "select_rectangles",
           "create_stem_acquisition_settings", "create_stem_data_settings", "create_camera_acquisition_settings",
           "create_eds_acquisition_settings", "create_eds_spectrum_image_settings", "show_free_lens_control"]


def plot_match(image: AdornedImage, template: AdornedImage, match_center: draw_utilities.PointLike):
    """
    Displays the searched image and the feature located in it on a pop-up window.

    :param image: Searched image in which a feature was located.
    :param template: Template image used for feature location.
    :param match_center: Point referring to the center of the feature located within the searched image, in pixels.
    """

    # Calculate the match location
    half_template_width = int(template.width / 2)
    half_template_height = int(template.height / 2)
    left = int(match_center[0] - half_template_width)
    top = int(match_center[1] - half_template_height)
    width = template.width
    height = template.height

    # Make a copy of the given image
    image_copy = numpy.array(image.data)

    # Draw a rectangle around the match location
    colors = draw_utilities.get_colors_from_image(image)
    primitives_renderer.draw_rectangle(image_copy, (left, top, width, height), image.width, image.height, colors)

    # Plot both the template image and whole image with match location marked by a rectangle
    plot.subplot(121), plot.imshow(template.data, cmap='gray')
    plot.title('Template image'), plot.xticks([]), plot.yticks([])
    plot.subplot(122), plot.imshow(image_copy, cmap='gray')
    plot.title('Match location'), plot.xticks([]), plot.yticks([])
    plot.tight_layout()
    plot.show()


def plot_image(image: AdornedImage, label: str = None, block: bool = True):
    """
    Opens a pop-up window displaying a plot of the provided image, given as an AdornedImage instance.
    The image is rendered using a grayscale palette.

    :param image: Image to be plotted.
    :param label: Label of the plot. If None, the label is automatically generated.
    :param block: If True (default), blocks execution until window is closed. If False, displays image 
                  non-blocking for continuous updates.
    """

    if image is None or image.data is None:
        raise ValueError("Cannot plot an empty image.")

    plot_images([image], [label], block=block)


def plot_images(images: Sequence[AdornedImage], labels: Sequence[str] = None, block: bool = True):
    """
    Opens a pop-up window displaying a plot of the provided images, given as AdornedImage instances.
    The images are rendered using a grayscale palette.

    :param images: Images to be plotted.
    :param labels: Labels of the plots. If None, the labels are automatically generated.
    :param block: If True (default), blocks execution until window is closed. If False, displays images 
                  non-blocking for continuous updates.
    """

    image_count = len(images) if images is not None else 0
    label_count = len(labels) if labels is not None else 0

    if image_count == 0:
        raise ValueError("No images provided for plotting.")

    if None in images:
        raise ValueError("One or more images are empty.")

    if image_count > 9:
        raise ValueError("Cannot display more than 9 images.")

    if label_count > image_count:
        raise ValueError("Number of provided labels exceeds the number of images.")

    labels_copy = list(labels) if labels is not None else []
    labels_copy += [None] * (image_count - label_count)

    # Calculate grid size
    cols = int(numpy.ceil(numpy.sqrt(image_count)))
    rows = int(numpy.ceil(image_count / cols))

    # Determine window title
    if image_count == 1:
        window_title = labels_copy[0] if labels_copy[0] is not None else plot_utilities.get_image_label(images[0])
    else:
        window_title = f"Image grid ({image_count})"

    # Plot images
    # Get or create the figure, clearing it if it already exists to prevent shrinking issues
    fig = plot.figure(num=window_title, figsize=(12, 8))
    fig.clf()  # Clear the figure to avoid layout issues when reusing
    
    # Create subplots in the cleared figure
    if rows == 1 and cols == 1:
        axes = [fig.add_subplot(1, 1, 1)]
    else:
        axes = []
        for i in range(rows):
            for j in range(cols):
                axes.append(fig.add_subplot(rows, cols, i * cols + j + 1))
    
    axes = numpy.array(axes)

    for index, image in enumerate(images):
        axes[index].imshow(image.data, cmap="gray")
        axes[index].axis("off")
        label = labels_copy[index]

        if label is None:
            label = plot_utilities.get_image_label(image)

        axes[index].set_title(label)

    # Hide unused slots
    for j in range(image_count, len(axes)):
        axes[j].axis("off")

    fig.tight_layout()
    
    # Handle blocking vs non-blocking display
    if block:
        # Traditional blocking mode
        plot.show()
    else:
        # Non-blocking mode for continuous updates
        plot.ion()  # Enable interactive mode
        fig.canvas.draw()  # Force redraw
        fig.canvas.flush_events()  # Process any pending GUI events
        plot.show()
        plot.pause(0.001)  # Small pause to ensure the window is displayed


def plot_spectrum(spectrum: AdornedSpectrum, label: str = None):
    """
    Opens a pop-up window displaying a plot of the provided spectrum, given as an AdornedSpectrum instance.

    :param spectrum: Spectrum to be plotted.
    :param label: Label of the plot. If None, the label is automatically generated.
    """

    if spectrum is None or spectrum.data is None:
        raise ValueError("Cannot plot an empty spectrum.")

    if spectrum.metadata is None:
        raise ValueError("Spectrum must have valid metadata.")

    plot_spectra([spectrum], [label])


def plot_spectra(spectra: List[AdornedSpectrum], labels: List[str] = None):
    """
    Opens a pop-up window displaying a plot where the provided spectra, given as AdornedSpectrum instances, are overlaid in a single figure.

    :param spectra: Spectra to be plotted.
    :param labels: Labels of the plots. If None, the labels are automatically generated.
    """

    spectra_count = len(spectra) if spectra is not None else 0
    label_count = len(labels) if labels is not None else 0

    if spectra_count == 0:
        raise ValueError("No spectra provided for plotting.")

    if None in spectra:
        raise ValueError("One or more spectra are empty.")

    if spectra_count > 10:
        raise ValueError("Cannot display more than 10 spectra.")

    if label_count > spectra_count:
        raise ValueError("Number of provided labels exceeds the number of spectra.")

    labels_copy = list(labels) if labels is not None else []
    labels_copy += [None] * (spectra_count - label_count)

    # Determine window title
    if spectra_count == 1:
        window_title = labels_copy[0] if labels_copy[0] is not None else plot_utilities.get_spectrum_label(spectra[0])
    else:
        window_title = f"Spectra Overlay ({spectra_count})"

    spectra_data = []
    plot.figure(figsize=(10, 6), num=window_title)

    for index, spectrum in enumerate(spectra):
        energies, scaled_spectrum = plot_utilities.get_spectrum_values(spectrum)
        spectra_data.append((energies, scaled_spectrum))

        label = labels_copy[index]

        if label is None:
            label = plot_utilities.get_spectrum_label(spectrum)

        plot.plot(spectra_data[index][0], spectra_data[index][1], label=label)

    plot.xlabel('Energy (eV)', fontsize=10)
    plot.ylabel('Counts', fontsize=10)
    plot.legend()
    plot.grid(True)
    plot.tight_layout()
    plot.show()


def select_point(image: AdornedImage) -> Optional[Point]:
    """
    Select a point of interest (pixel) by clicking on the given image.

    :param image: Input image.
    :return: Selected point, if it was selected. None otherwise.
    """

    selected_points = image_selector.select_points(image, "Select point", True)
    return selected_points[0] if len(selected_points) > 0 else None


def select_points(image: AdornedImage) -> List[Point]:
    """
    Select multiple points of interest (pixels) by clicking on the given image.

    :param image: Input image.
    :return: List of selected points. Empty list if no points were selected.
    """

    return image_selector.select_points(image, "Select points (close the window to finish)", False)


def select_rectangle(image: AdornedImage,
                     coordinate_system: str = RegionCoordinateSystem.PIXELS) -> Optional[Rectangle]:
    """
    Select an area of interest by dragging a rectangle on the given image.

    :param image: Input image.
    :param coordinate_system: Coordinate system to use when selecting the area. Pixels by default.
    :return: Selected area, if it was selected. None otherwise.
    """

    selected_rectangles = image_selector.select_rectangles(image, coordinate_system, "Select rectangle", True)
    return selected_rectangles[0] if len(selected_rectangles) > 0 else None


def select_rectangles(image: AdornedImage, coordinate_system: str = RegionCoordinateSystem.PIXELS) -> List[Rectangle]:
    """
    Select multiple areas of interest by dragging rectangles on the given image.

    :param image: Input image.
    :param coordinate_system: Coordinate system to use when selecting the areas. Pixels by default.
    :return: List of selected areas. Empty list if no areas were selected.
    """

    return image_selector.select_rectangles(image, coordinate_system, "Select rectangles (close the window to finish)",
                                            False)

def create_stem_acquisition_settings(microscope: TemMicroscopeClient) -> StemAcquisitionSettings | None:
    """
    Opens a pop-up window with a form used to create a StemAcquisitionSettings object

    :param microscope: Connected microscope client.
    :return: StemAcquisitionSettings with the selected values or None if cancel is clicked.
    """
    return forms.create_stem_acquisition_settings(microscope)

def create_stem_data_settings(microscope: TemMicroscopeClient) -> StemDataSettings | None:
    """
    Opens a pop-up window with a form used to create a StemDataSettings object

    :param microscope: Connected microscope client.
    :return: StemDataSettings with the selected values or None if cancel is clicked.
    """
    return forms.create_stem_data_settings(microscope)

def create_camera_acquisition_settings(microscope: TemMicroscopeClient) -> CameraAcquisitionSettings | None:
    """
    Opens a pop-up window with a form used to create a CameraAcquisitionSettings object

    :param microscope: Connected microscope client.
    :return: CameraAcquisitionSettings with the selected values or None if cancel is clicked.
    """
    return forms.create_camera_acquisition_settings(microscope)

def create_eds_acquisition_settings(microscope: TemMicroscopeClient) -> EdsAcquisitionSettings | None:
    """
    Opens a pop-up window with a form used to create a EdsAcquisitionSettings object

    :param microscope: Connected microscope client.
    :return: EdsAcquisitionSettings with the selected values or None if cancel is clicked.
    """
    return forms.create_eds_acquisition_settings(microscope)

def create_eds_spectrum_image_settings(microscope: TemMicroscopeClient) -> EdsSpectrumImageSettings | None:
    """
    Opens a pop-up window with a form used to create a EdsSpectrumImageSettings object

    :param microscope: Connected microscope client.
    :return: EdsSpectrumImageSettings with the selected values or None if cancel is clicked.
    """
    return forms.create_eds_spectrum_image_settings(microscope)

def show_free_lens_control(microscope: TemMicroscopeClient):
    """
    Opens a pop-up window used to control lenses in Free Control mode.

    :param microscope: Connected microscope client.
    """
    forms.free_lens_control(microscope)