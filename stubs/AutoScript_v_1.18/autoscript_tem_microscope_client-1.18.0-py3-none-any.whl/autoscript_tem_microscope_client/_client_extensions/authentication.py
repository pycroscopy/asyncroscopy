# Disabling Legacy provider in OpenSSL, otherwise crashes on package import
# (probably due to enthought not packaging the legacy provider). This will only affect the running process.
# https://cryptography.io/en/latest/openssl/#legacy-provider-in-openssl-3-x
import os
os.environ["CRYPTOGRAPHY_OPENSSL_NO_LEGACY"] = "1"

from autoscript_core.logging import Logging, LogDomain
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
import xml.etree.ElementTree as ET
import base64
import os
import sys

PYTHON_CLIENT_ID = 3

SERVER_AUTH_ENABLED = 0x00
SERVER_AUTH_DISABLED = 0x01
SERVER_AUTH_DISABLED_LOCALHOST = 0x02

USER_AUTH_OPCODE_SERVER_STATUS = 0x65
USER_AUTH_OPCODE_REQUEST_NONCE = 0x66
USER_AUTH_OPCODE_VERIFY_SIGNATURE = 0x67
USER_AUTH_RESULT_SUCCESS = 0x01


def authenticate_user(client, host):
    logger = Logging.loggers[LogDomain.APPLICATION_CLIENT]
    logger.log_notification("User attempting authentication with private key")

    authentication_status = client.service.autoscript.client.authenticate(USER_AUTH_OPCODE_SERVER_STATUS, PYTHON_CLIENT_ID)

    # Server authentication is disabled
    if authentication_status == SERVER_AUTH_DISABLED:
        return

    # Server authentication is disabled for localhost
    if authentication_status == SERVER_AUTH_DISABLED_LOCALHOST and (host == "localhost" or host == "127.0.0.1" or host == "::1"):
        return

    session_nonce = client.service.autoscript.client.authenticate(USER_AUTH_OPCODE_REQUEST_NONCE, 0)
    private_key_pem = __load_private_key()
    signature_base64 = __sign_nonce(private_key_pem, session_nonce)

    result_code = client.service.autoscript.client.authenticate(USER_AUTH_OPCODE_VERIFY_SIGNATURE, 0, signature_base64)

    if result_code != USER_AUTH_RESULT_SUCCESS:
        raise Exception(__get_authentication_error_message(result_code))


def __get_authentication_error_message(error_code: int) -> str:
    if error_code == 201:
        return "The provided private key does not match any public key authorized by the AutoScript Server."
    elif error_code == 202:
        return "The provided private key has expired and is no longer valid."
    return "The provided private key is not valid."


def __sign_nonce(private_key_pem: bytes, nonce: int) -> str:
    nonce_bytes = __nonce_to_bytes(nonce)

    if b"-----BEGIN PRIVATE KEY-----" not in private_key_pem:
        raise ValueError("The provided key is not a valid private key.")

    private_key = serialization.load_pem_private_key(private_key_pem, password=None)
    if not isinstance(private_key, rsa.RSAPrivateKey) or private_key.key_size != 2048:
        raise ValueError("The provided key is not a valid private key.")

    if private_key.key_size != 2048:
        raise ValueError("The provided key is not a valid private key.")

    signature = private_key.sign(
        nonce_bytes,
        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
        hashes.SHA256())

    signature_base64 = base64.b64encode(signature).decode("ascii")
    return signature_base64


def __nonce_to_bytes(nonce: int) -> bytes:
    nonce &= 0xFFFFFFFFFFFFFFFF  # Convert to unsigned long
    return nonce.to_bytes(8, "big")


def __load_private_key() -> bytes:
    # 1. Determine the user configuration path based on the OS
    if sys.platform == "win32":
        app_data_dir = os.getenv("LOCALAPPDATA")
        if not app_data_dir:
            raise EnvironmentError("Environment variable LOCALAPPDATA is not set.")
    else:
        # Standard configuration location on Linux/macOS
        app_data_dir = os.path.join(os.path.expanduser("~"), ".config")

    user_configuration_path = os.path.join(app_data_dir, "Thermo Scientific AutoScript TEM", "ClientConfiguration.xml")
    private_key_path = None

    user_configuration_exists = os.path.exists(user_configuration_path)

    # 2. Prefer the path from ClientConfiguration.xml if the file exists
    if user_configuration_exists:
        try:
            tree = ET.parse(user_configuration_path)
            root = tree.getroot()
            node = root.find("ActivePrivateKey")
            if node is None or not node.text or not node.text.strip():
                raise ValueError("Configuration file does not specify a path for the private key.")

            # Path handling: expanduser resolves the tilde (~), expandvars resolves system variables
            raw_path = node.text.strip()
            private_key_path = os.path.expanduser(os.path.expandvars(raw_path))

        except Exception as e:
            raise ValueError(f"Failed to read private key path from configuration file: {e}.")

    # 3. Fallback to the default location in the home directory
    else:
        private_key_path = os.path.join(os.path.expanduser("~"), ".autoscript", "autoscript_tem.key")

    # 4. Check file existence
    if not os.path.exists(private_key_path):
        if not user_configuration_exists:
            raise FileNotFoundError("The AutoScript Server requires user authentication but no private key is configured.")
        raise FileNotFoundError(f"Private key file not found: {private_key_path}.")

    # 5. Open and return the key content
    with open(private_key_path, "rb") as file:
        return file.read()
