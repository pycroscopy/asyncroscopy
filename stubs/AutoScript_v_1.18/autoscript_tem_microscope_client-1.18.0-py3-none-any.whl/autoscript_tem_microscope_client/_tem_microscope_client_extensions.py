from . import _client_extensions

try:
    from autoscript_tem_microscope_client.build_information import INFO_VERSIONLONG
except ModuleNotFoundError:
    INFO_VERSIONLONG = "Unknown"


class TemMicroscopeClientExtensions:
    @staticmethod
    def authenticate_user(client, host):
        return _client_extensions.authentication.authenticate_user(client, host)

    @staticmethod
    def version_GET(client) -> 'str':
        return INFO_VERSIONLONG

    @staticmethod
    def is_stop_requested_GET(client) -> 'bool':
        return _client_extensions.graceful_execution.is_stop_requested(client)

    @staticmethod
    def check_stop_requested(client):
        _client_extensions.graceful_execution.check_stop_requested(client)

    @staticmethod
    def is_pause_requested_GET(client) -> 'bool':
        return _client_extensions.graceful_execution.is_pause_requested(client)

    @staticmethod
    def check_pause_requested(client):
        _client_extensions.graceful_execution.check_pause_requested(client)

    @staticmethod
    def save_spectrum_image(eds_stream, path):
        _client_extensions.adorned_spectrum_image.save_spectrum_image(eds_stream, path)
